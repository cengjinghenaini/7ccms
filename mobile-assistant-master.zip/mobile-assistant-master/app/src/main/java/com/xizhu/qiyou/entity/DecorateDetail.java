package com.xizhu.qiyou.entity;

public class DecorateDetail extends Decorate {

    /**
     * id : 1
     * name :
     * pic :
     * integral :
     * cate_id :
     * type :
     * createtime :
     * is_buy : 是否已购买
     * user : {"integral":"1","contribution":""}
     */

    private String is_buy;
    private User user;

    public String getIs_buy() {
        return is_buy;
    }

    public void setIs_buy(String is_buy) {
        this.is_buy = is_buy;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

}
