package com.xizhu.qiyou.ui.main

import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.entity.Cate
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.widget.EmptyView
import kotlinx.android.synthetic.main.fragment_category.*

class CategoryFragment : BaseFragment() {
    private var adapter: CategoryAdapter? = null

    override fun getRes(): Int {
        return R.layout.fragment_category
    }

    override fun initView() {
        super.initView()
        refresh_layout.setOnRefreshListener {
            getCate()
        }
        empty_view?.setLoadListener {
            getCate()
        }
        recycler.layoutManager = GridLayoutManager(context, 2, GridLayoutManager.VERTICAL, false)
        adapter = CategoryAdapter().apply {
            setOnItemClickListener { _, _, position ->
                val item = getItem(position)
                GameListActivity.start(context, item.id, "", item.name)
            }
            setEmptyView(EmptyView(requireActivity()).setNoData())
        }
        recycler.adapter = adapter
    }

    override fun initData() {
        super.initData()
        getCate()
    }

    private fun getCate() {
        HttpUtil.getInstance().getAppCate("0", object : ResultCallback<MutableList<Cate>>() {
            override fun onSuccess(s: ResultEntity<MutableList<Cate>>) {
                val cateList = s.data
                adapter?.setNewInstance(cateList)
                refresh_layout?.finishRefresh()
                empty_view?.visibility = View.GONE
            }

            override fun onFailure(err: String?, code: Int) {
                refresh_layout?.finishRefresh(false)
                if (empty_view?.visibility == View.VISIBLE) {
                    empty_view?.setLoadFail()
                }
            }
        })
    }
}