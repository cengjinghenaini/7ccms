package com.xizhu.qiyou.entity;

import com.google.gson.annotations.SerializedName;

public class AppScore {


    /**
     * 1 : 0
     * 2 : 0
     * 3 : 0
     * 4 : 0
     * 5 : 0
     * 1.0 : 19
     * 2.0 : 4
     * 3.0 : 4
     * 4.0 : 4
     * 5.0 : 69
     */

    @SerializedName("1")
    private int _$1;
    @SerializedName("2")
    private int _$2;
    @SerializedName("3")
    private int _$3;
    @SerializedName("4")
    private int _$4;
    @SerializedName("5")
    private int _$5;
    @SerializedName("1.0")
    private int _$_10; // FIXME check this code
    @SerializedName("2.0")
    private int _$_20; // FIXME check this code
    @SerializedName("3.0")
    private int _$_30; // FIXME check this code
    @SerializedName("4.0")
    private int _$_40; // FIXME check this code
    @SerializedName("5.0")
    private int _$_50; // FIXME check this code

    public int get_$1() {
        return _$1;
    }

    public void set_$1(int _$1) {
        this._$1 = _$1;
    }

    public int get_$2() {
        return _$2;
    }

    public void set_$2(int _$2) {
        this._$2 = _$2;
    }

    public int get_$3() {
        return _$3;
    }

    public void set_$3(int _$3) {
        this._$3 = _$3;
    }

    public int get_$4() {
        return _$4;
    }

    public void set_$4(int _$4) {
        this._$4 = _$4;
    }

    public int get_$5() {
        return _$5;
    }

    public void set_$5(int _$5) {
        this._$5 = _$5;
    }

    public int get_$_10() {
        return _$_10;
    }

    public void set_$_10(int _$_10) {
        this._$_10 = _$_10;
    }

    public int get_$_20() {
        return _$_20;
    }

    public void set_$_20(int _$_20) {
        this._$_20 = _$_20;
    }

    public int get_$_30() {
        return _$_30;
    }

    public void set_$_30(int _$_30) {
        this._$_30 = _$_30;
    }

    public int get_$_40() {
        return _$_40;
    }

    public void set_$_40(int _$_40) {
        this._$_40 = _$_40;
    }

    public int get_$_50() {
        return _$_50;
    }

    public void set_$_50(int _$_50) {
        this._$_50 = _$_50;
    }
}
