package com.xizhu.qiyou.entity;

/**
 * @ClassName POST_TYPE
 * @Description 发帖页面，帖子查看方式
 * @Author guchu
 * @Date 2021/7/31 10:47
 * @Version 1.0
 */
public enum REVIEW_TYPE {
    TYPE_UNLIMITED, TYPE_RELAY, TYPE_GRADE   //查看无限制  回复查看  积分查看
}
