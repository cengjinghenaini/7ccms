package com.xizhu.qiyou.entity.Events;

public class WXBind {
    private boolean isSuccess;

    public WXBind(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }

    public boolean getSuccess() {
        return isSuccess;
    }

    public void setSuccess(boolean success) {
        isSuccess = success;
    }
}
