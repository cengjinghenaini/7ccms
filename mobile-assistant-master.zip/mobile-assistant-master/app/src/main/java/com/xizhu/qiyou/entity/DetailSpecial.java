package com.xizhu.qiyou.entity;

import java.util.List;

public class DetailSpecial {


    /**
     * id : value
     * pic : value
     * desc : value
     * name : value
     * type : value
     * app_ids : value
     * createtime : value
     * apps : [{"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value","cate_name":"value"}]
     */

    private String id;
    private String pic;
    private String desc;
    private String name;
    private String type;
    private String app_ids;
    private String createtime;
    private List<BaseApp> apps;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getApp_ids() {
        return app_ids;
    }

    public void setApp_ids(String app_ids) {
        this.app_ids = app_ids;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public List<BaseApp> getApps() {
        return apps;
    }

    public void setApps(List<BaseApp> apps) {
        this.apps = apps;
    }

}
