package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class Goods implements Serializable {

    /**
     * id : 1
     * pic :
     * title :
     * integral :
     */

    protected String id;
    protected String pic;
    protected String title;
    protected String integral;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }
}
