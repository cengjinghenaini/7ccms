package com.xizhu.qiyou.widget

import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import net.lucode.hackware.magicindicator.abs.IPagerNavigator
import java.util.*

/**
 * 带指示器ViewPager适配器
 */
class IndicatorViewPagerAdapter(
    fm: FragmentManager?,
    private val commonNavigator: IPagerNavigator?,
    private val block: (position: Int, `object`: Any) -> Unit
) : FragmentStatePagerAdapter(fm!!) {
    private val fragmentList: MutableList<IndicatorFragment> = ArrayList()
    fun setData(indicatorFragmentList: List<IndicatorFragment>?) {
        fragmentList.clear()
        if (indicatorFragmentList != null) {
            fragmentList.addAll(indicatorFragmentList)
        }
        commonNavigator?.notifyDataSetChanged()
        notifyDataSetChanged()
    }

    fun addData(indicatorFragmentList: List<IndicatorFragment>?) {
        if (indicatorFragmentList != null) {
            fragmentList.addAll(indicatorFragmentList)
        }
        commonNavigator?.notifyDataSetChanged()
        notifyDataSetChanged()
    }

    override fun getItemPosition(`object`: Any): Int {
        return POSITION_NONE
    }

    override fun getItem(position: Int): Fragment {
        return fragmentList[position].fragment
    }

    override fun getCount(): Int {
        return fragmentList.size
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {}
    override fun setPrimaryItem(container: ViewGroup, position: Int, `object`: Any) {
        super.setPrimaryItem(container, position, `object`)
        block.invoke(position, `object`)
    }
}