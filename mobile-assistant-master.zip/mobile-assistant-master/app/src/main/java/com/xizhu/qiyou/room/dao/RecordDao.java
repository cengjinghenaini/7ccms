package com.xizhu.qiyou.room.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.xizhu.qiyou.room.entity.SearchRecord;

import java.util.List;

@Dao
public interface RecordDao {
    @Insert
    void insertUser(SearchRecord users);
    // TODO 如果插入的数据在数据库表中已经存在，就会抛出异常

//    @Insert
//    void insertUsers(List<SearchRecord> users);
//
//    @Insert
//    void insertUsers(SearchRecord... users);
//    // 如果 @Insert 方法只接收 1 个参数，则它可以返回 long，这是插入项的新 rowId。如果参数是数组或集合，则应返回 long[] 或 List<Long>。
//
    @Delete
    void delete(SearchRecord user);
    // TODO 如果通过 Entity 来删除数据，传进来的参数需要包含主键

    // TODO 如果通过 Entity 来删除数据，传进来的参数需要包含主键
//    @Delete
//    void deleteUsers(SearchRecord... users);
//    // 虽然通常没有必要，但是您可以让此方法返回一个 int 值，以指示从数据库中删除的行数。
//
//    @Update
//    void updateUser(SearchRecord users);
//    // TODO 如果通过 Entity 来更新数据，传进来的参数需要包含主键，参数会覆盖旧数据，参数中没有值的字段将置为 null
//
//    @Update
//    void updateUsers(SearchRecord... users);
//    // 虽然通常没有必要，但是您可以让此方法返回一个 int 值，以指示数据库中更新的行数
//


    @Query("SELECT * FROM searchRecord")
    List<SearchRecord> loadAll();

    @Query("SELECT * FROM searchRecord WHERE key_word=(:key)")
    SearchRecord findByKeyWord(String key);

    //删全部
    @Query("DELETE FROM searchRecord")
    void deleteAll();

}
