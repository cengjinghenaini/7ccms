package com.xizhu.qiyou.entity.Events;

public class PointXuanShang {
}
