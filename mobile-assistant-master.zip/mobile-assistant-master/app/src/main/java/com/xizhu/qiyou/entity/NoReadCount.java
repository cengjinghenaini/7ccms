package com.xizhu.qiyou.entity;

public class NoReadCount {
    /**
     * count : 0
     */

    private String count;
    private String notice_count;

    public String getNotice_count() {
        return notice_count;
    }

    public void setNotice_count(String notice_count) {
        this.notice_count = notice_count;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
}
