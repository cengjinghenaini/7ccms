package com.xizhu.qiyou.apps;

import android.app.Application;
import android.content.Intent;
import android.os.Environment;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.xizhu.qiyou.entity.DetailGame;
import com.xizhu.qiyou.room.entity.AppEntity;
import com.xizhu.qiyou.util.PhoneUtil;
import com.xizhu.qiyou.util.zip.FileUtils;

import java.io.File;
import java.util.List;

/**
 * @ClassName AppModel
 * @Description 封装app过程中，要进行的各种操作
 * @Author guchu
 * @Date 2021/8/12 22:56
 * @Version 1.0
 */
public class AppModel extends AndroidViewModel {
    public static final String OBB_PATH = Environment.getExternalStorageDirectory() + "/Android/obb";
    private AppRepository mAppRepository;
    private LiveData<List<AppEntity>> mApps;

    public AppModel(@NonNull Application application) {
        super(application);
        mAppRepository = new AppRepository(application);
        mApps = mAppRepository.getAllApps();
    }

    public AppEntity getAppEntityByDownloadUrl(String downloadUrl) {
        return mAppRepository.getAppByDownloadUrl(downloadUrl);
    }

    public AppEntity getAppByWebPackage(String realPackage) {
        return mAppRepository.getAppByWebPackage(realPackage);
    }

    public LiveData<List<AppEntity>> getLiveList() {
        return mApps;
    }

    public void deleteAppEntity(String downloadUrl) {
        AppEntity appEntity = mAppRepository.getAppByDownloadUrl(downloadUrl);
        if (null == appEntity) {
            return;
        }
        mAppRepository.delete(appEntity);
    }

    //在下载或更新前清理本地数据
    private String[] prepare4Download(DetailGame detailGame) {
        String downloadPath = "";
        String unzipPath = "";
        if (detailGame.getDownload_url().endsWith(".apk")) {
            downloadPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath() + "/" + detailGame.getName() + ".apk";
        } else {
            downloadPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath() + "/" + detailGame.getName() + ".zip";
            unzipPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/qiyou/" + new File(downloadPath).getName();
            unzipPath = unzipPath.replace(".zip", "");
        }
        File apkFile = new File(downloadPath);
        if (apkFile.exists()) {
            apkFile.delete();
        }
        File unzipFile = new File(unzipPath);
        if (unzipFile.exists()) {
            unzipFile.delete();
        }
        String[] paths = new String[2];
        paths[0] = downloadPath;
        paths[1] = unzipPath;
        return paths;
    }

    /**
     * 解压缩一样. 不允许暂停. 暂停就进行删除
     *
     * @param detailGame
     * @return
     */
    public AppStatus getStatus(DetailGame detailGame) {
        AppEntity appEntity = mAppRepository.getAppByWebPackage(detailGame.getPackageX());
        String installedVersion = PhoneUtil.getAppVersionName(getApplication(), null == appEntity ? detailGame.getPackageX() : appEntity.getRealPackage());
        boolean needUpdate = false; //前提已经安装
        if (!TextUtils.isEmpty(installedVersion)) {
            needUpdate = PhoneUtil.needUpdate(null == appEntity ? detailGame.getVersion() : appEntity.getRealVersion(), installedVersion);
        }
        if (!TextUtils.isEmpty(installedVersion) && !needUpdate) {
            return AppStatus.INSTALLED;
        }
        if (null == appEntity) {
            if (TextUtils.isEmpty(installedVersion)) {
                return AppStatus.NOT_INSTALLED;
            }
            if (needUpdate) {
                return AppStatus.NOT_UPDATED;
            }
        }
        AppStatus appStatus = getStatus(appEntity);
        return appStatus;
    }

    /**
     * 这里肯定是db中存在的记录，和更新没有什么关系.
     *
     * @param appEntity
     * @return
     */
    public AppStatus getStatus(AppEntity appEntity) {
        if (appEntity.getIsManualPaused() == AppEntity.TYPE_MANUAL_PAUSED) {
            if (appEntity.getDownloadProgress() == 0) {
                return AppStatus.PAUSED_NOT_DOWNLOAD;
            } else if (appEntity.getDownloadProgress() > 0 && appEntity.getDownloadProgress() < 100) {
                //使用FileDownloader框架后，下载的文件名发生变化了
                File downloadFile = new File(appEntity.getDownPath() + ".temp");
                if (!downloadFile.exists()) {
                    return AppStatus.NOT_INSTALLED;
                }
                return AppStatus.PAUSED_DOWNLOADING;
            }
            //getDownloadProgress == 100.
            boolean isZip = appEntity.getDownloadUrl().endsWith(".zip");
            if (!isZip) {
                File apkFile = new File(appEntity.getDownPath());
                if (!apkFile.exists()) {
                    return AppStatus.NOT_INSTALLED;
                }
                return AppStatus.PAUSED_INSTALLED;
            }
            //zip 的状态就多了.
            if (appEntity.getUnzipProgress() < 100) {
                File zipFile = new File(appEntity.getDownPath());
                if (!zipFile.exists()) {
                    return AppStatus.NOT_INSTALLED;
                }
                return AppStatus.PAUSED_UNZIPPING;
            }
            return AppStatus.PAUSED_INSTALLED;
        }
        //自然状态(流水线)
        if (appEntity.getDownloadProgress() >= 0 && appEntity.getDownloadProgress() < 100) {
            if (appEntity.getIsWorking() == AppEntity.TYPE_WORKING) {
                return AppStatus.DOWNLOADING;
            }
            return AppStatus.WAIT_4_DOWNLOAD;
        }
        if (appEntity.getDownloadProgress() == 100 && appEntity.getDownloadUrl().endsWith(".apk")) {
            return AppStatus.WAIT_4_INSTALL;
        }


        if (appEntity.getUnzipProgress() >= 0 && appEntity.getUnzipProgress() < 100) {
            if (appEntity.getIsWorking() == AppEntity.TYPE_WORKING) {
                return AppStatus.UNZIPPING;
            }
            return AppStatus.WAIT_4_UNZIP;
        }
        if (appEntity.getUnzipProgress() == 100 && appEntity.getIsInstalled() != AppEntity.TYPE_INSTALLED) {
            return AppStatus.WAIT_4_INSTALL;
        }
        return AppStatus.INSTALLED;
    }


    //点击下载或者更新状态的按钮(不包括暂停和继续),不是下载等Service队列真正在工作.但是准备工作都已经做完.
    public void startDownload(DetailGame detailGame) {
        AppEntity appEntity = mAppRepository.getAppByWebPackage(detailGame.getPackageX());
        if (null == appEntity) {
            //开始下载
            appEntity = new AppEntity(detailGame);
            String[] paths = prepare4Download(detailGame);
            appEntity.setDownPath(paths[0]);
            appEntity.setUnzipPath(paths[1]);
            appEntity.setQueueTimeInMill(System.currentTimeMillis());
            mAppRepository.insert(appEntity);
        } else {
            //更新
            appEntity.update(detailGame);
            String[] paths = prepare4Download(detailGame);
            appEntity.setDownPath(paths[0]);
            appEntity.setUnzipPath(paths[1]);
            appEntity.setQueueTimeInMill(System.currentTimeMillis());
            mAppRepository.update(appEntity);
        }
        Intent intent = new Intent(getApplication(), DownloadService.class);
        intent.putExtra("bean", appEntity);
        getApplication().startService(intent);
    }

    /**
     * 暂停安装过程，包括下载、解压.
     */
    public void pauseInstallProcess(String downloadUrl) {
        AppEntity appEntity = mAppRepository.getAppByDownloadUrl(downloadUrl);
        appEntity.setQueueTimeInMill(0L);
        appEntity.setIsManualPaused(AppEntity.TYPE_MANUAL_PAUSED);
        mAppRepository.update(appEntity);
        if (appEntity.getDownloadProgress() < 100) {
            Intent intent = new Intent(getApplication(), DownloadService.class);
            intent.putExtra("bean", appEntity);
            intent.putExtra("paused", true);
            getApplication().startService(intent);
            return;
        }
        if (appEntity.getUnzipProgress() < 100) {
            Intent intent = new Intent(getApplication(), UnzipService.class);
            intent.putExtra("bean", appEntity);
            intent.putExtra("paused", true);
            getApplication().startService(intent);
            return;
        }

    }


    /**
     * 继续安装过程
     */
    public void continueInstallProcess(String downloadUrl) {
        AppEntity appEntity = mAppRepository.getAppByDownloadUrl(downloadUrl);
        //1. 已经下载、(解压完毕,如果为zip)，直接进行安装
        boolean needFromStart = true; //重新下载
        if (appEntity.getDownloadUrl().endsWith(".apk") && appEntity.getDownloadProgress() == 100) {
            File apkFile = new File(appEntity.getDownPath());
            if (apkFile.exists()) {
                needFromStart = false;
                AppUtil.install(getApplication(),appEntity);
                return;
            }
        }
        if (appEntity.getDownloadUrl().endsWith(".zip") && appEntity.getUnzipProgress() == 100) {
            File unzipDir = new File(appEntity.getUnzipPath());
            File[] files = unzipDir.listFiles();
            File apkFile = null;
            for (File fItem : files) {
                if (fItem.isFile()) {
                    apkFile = fItem;
                    break;
                }
            }
            if (null != apkFile) {
                needFromStart = false;
                AppUtil.install(getApplication(),appEntity);

            }
        }
        //是zip 尚未解压.
        if (appEntity.getDownloadUrl().endsWith(".zip") && appEntity.getDownloadProgress() == 100 && appEntity.getUnzipProgress() < 100) {
            File dstDir = new File(appEntity.getUnzipPath());
            if (!dstDir.exists()) {
                dstDir.mkdirs();
            } else if (dstDir.listFiles().length > 0) {
                FileUtils.deleteAllInDir(dstDir);
            }
            File downloadFile = new File(appEntity.getDownPath());
            if (downloadFile.exists()) {
                needFromStart = false;
                appEntity.setQueueTimeInMill(System.currentTimeMillis());
                appEntity.setIsWorking(AppEntity.TYPE_IN_QUEUE);
                appEntity.setIsManualPaused(AppEntity.TYPE_NO_PAUSED);
                mAppRepository.update(appEntity);
                Intent intent = new Intent(getApplication(), UnzipService.class);
                intent.putExtra("bean", appEntity);
                getApplication().startService(intent);
            }
        }
        //尚未下载完毕
        if (appEntity.getDownloadProgress() < 100) {
            File downloadFile = new File(appEntity.getDownPath() + ".temp");
            if (downloadFile.exists()) {
                needFromStart = false;
                appEntity.setQueueTimeInMill(System.currentTimeMillis());
                appEntity.setIsWorking(AppEntity.TYPE_IN_QUEUE);
                appEntity.setIsManualPaused(AppEntity.TYPE_NO_PAUSED);
                mAppRepository.update(appEntity);

                Intent intent = new Intent(getApplication(), DownloadService.class);
                intent.putExtra("bean", appEntity);
                getApplication().startService(intent);
            }
        }
        if (needFromStart) {
            appEntity.clear();
            mAppRepository.update(appEntity);
            Intent intent = new Intent(getApplication(), DownloadService.class);
            intent.putExtra("bean", appEntity);
            getApplication().startService(intent);
        }

    }

    public void updateDownloadProgress(String webUrl, int downloadProgress) {
        AppEntity appEntity = mAppRepository.getAppByDownloadUrl(webUrl);
        if (appEntity != null) {
            appEntity.setDownloadProgress(downloadProgress);
            mAppRepository.update(appEntity);
        }

    }

    public void updateUnzipProgress(String webUrl, int unzipProgress) {
        AppEntity appEntity = mAppRepository.getAppByDownloadUrl(webUrl);
        if (appEntity != null) {
            appEntity.setUnzipProgress(unzipProgress);
            mAppRepository.update(appEntity);
        }

    }
}
