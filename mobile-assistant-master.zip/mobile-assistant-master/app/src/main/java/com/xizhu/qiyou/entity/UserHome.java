package com.xizhu.qiyou.entity;

import java.util.List;

public class UserHome {

    /**
     * attention : 0
     * collect : 0
     * fans : 0
     * posts : 0
     * user : {"uid":"1","phone":"18254127300","email":"123@12.com","name":"","wx_name":"","qq":"","head":"","touxian_id":"","touxian":"","sex":"1","is_member":"","age":"","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":"","medals":[],"is_attention":0}
     * gallerys : [{"id":"","uid":"","pic":"","createtime":""}]
     * apps : [{"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value"}]
     * sheets : [{"id":"value","pic":"value","uid":"value","title":"value","zan_count":"value","collect_count":"value","comment_count":"value"}]
     */

    private String attention;
    private String collect;
    private String fans;
    private String posts;
    private User user;
    private List<Gallery> gallerys;
    private List<BaseApp> apps;
    private List<BaseSheet> sheets;
    private Dress dress;

    public Dress getDress() {
        return dress;
    }

    public void setDress(Dress dress) {
        this.dress = dress;
    }
    public String getAttention() {
        return attention;
    }

    public void setAttention(String attention) {
        this.attention = attention;
    }

    public String getCollect() {
        return collect;
    }

    public void setCollect(String collect) {
        this.collect = collect;
    }

    public String getFans() {
        return fans;
    }

    public void setFans(String fans) {
        this.fans = fans;
    }

    public String getPosts() {
        return posts;
    }

    public void setPosts(String posts) {
        this.posts = posts;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Gallery> getgallerys() {
        return gallerys;
    }

    public void setGallerys(List<Gallery> galleries) {
        this.gallerys = galleries;
    }

    public List<BaseApp> getApps() {
        return apps;
    }

    public void setApps(List<BaseApp> apps) {
        this.apps = apps;
    }

    public List<BaseSheet> getSheets() {
        return sheets;
    }

    public void setSheets(List<BaseSheet> sheets) {
        this.sheets = sheets;
    }


}
