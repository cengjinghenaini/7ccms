package com.xizhu.qiyou.entity;

public class DownloadInfo {
    public String down_url;
}
