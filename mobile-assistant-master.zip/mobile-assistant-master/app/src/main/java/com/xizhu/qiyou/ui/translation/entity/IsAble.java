package com.xizhu.qiyou.ui.translation.entity;

public class IsAble {
    boolean isAble;

    public boolean isAble() {
        return isAble;
    }

    public void setAble(boolean able) {
        isAble = able;
    }

    public IsAble(boolean isAble) {
        this.isAble = isAble;
    }
}
