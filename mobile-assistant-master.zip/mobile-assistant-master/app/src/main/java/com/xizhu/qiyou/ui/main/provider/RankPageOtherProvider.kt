package com.xizhu.qiyou.ui.main.provider

import android.content.Context
import android.graphics.Color
import android.widget.TextView
import com.chad.library.adapter.base.provider.BaseItemProvider
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.pass.util.DisplayUtil
import com.qmuiteam.qmui.widget.QMUIFloatLayout
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.BaseApp
import com.xizhu.qiyou.entity.Label
import com.xizhu.qiyou.ui.main.GameListActivity
import com.xizhu.qiyou.ui.main.RankPageAdapter
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.UnitUtil

class RankPageOtherProvider(mContext: Context) : BaseItemProvider<Any>() {
    override val itemViewType: Int
        get() = RankPageAdapter.TYPE_OTHER
    override val layoutId: Int
        get() = R.layout.item_recy_game_rank_other
    private var dp10 = 0
    private var dp2 = 0
    private var textColor1 = Color.parseColor("#1C73FE")
    private var textColor2 = Color.parseColor("#FF5A5A")
    private var textColor3 = Color.parseColor("#CE5AFF")

    init {
        dp10 = DisplayUtil.dip2px(mContext, 10f)
        dp2 = DisplayUtil.dip2px(mContext, 2f)
    }


    override fun convert(helper: BaseViewHolder, item: Any) {
        val position = helper.layoutPosition + 1
        val data = item as? BaseApp
        ImgLoadUtil.load(helper.getView(R.id.iv_game_logo), data?.icon)
        helper.setText(R.id.tv_num, position.toString())
        helper.setText(R.id.tv_game_name, data?.name)
        helper.setText(R.id.tv_size, UnitUtil.zao(data?.size))
        updateTagView(helper.getView(R.id.fl_tag), data?.labels)
    }

    private fun updateTagView(fl_tag: QMUIFloatLayout?, cateList: List<Label>?) {
        fl_tag?.removeAllViews()
        cateList?.forEachIndexed { index, label ->
            val position = index % 4
            val textView = TextView(context)
            val textColor: Int
            val bgRes: Int
            when (position) {
                0 -> {
                    textColor = textColor1
                    bgRes = R.drawable.shape_game_blue_tag
                }
                2 -> {
                    textColor = textColor3
                    bgRes = R.drawable.shape_game_purple_tag
                }
                else -> {
                    textColor = textColor2
                    bgRes = R.drawable.shape_game_red_tag
                }
            }
            textView.textSize = 14f
            textView.setTextColor(textColor)
            textView.setBackgroundResource(bgRes)
            textView.setPadding(dp10, dp2, dp10, dp2)
            textView.text = label.name
            textView.setOnClickListener {
                GameListActivity.start(context, "", label.id, label.name)
            }
            fl_tag?.addView(textView)
        }
    }
}