package com.xizhu.qiyou.ui.account

import android.text.TextUtils
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.util.dialog.ToastUtil
import kotlinx.android.synthetic.main.activity_edit_password.*
import kotlinx.android.synthetic.main.title_layout.*

class EditPasswordActivity : BaseCompatActivity() {
    override fun getRes(): Int {
        return R.layout.activity_edit_password
    }

    override fun initView() {
        iv_back.setOnClickListener {
            finish()
        }
        tv_page_title.text = "修改密码"
        tv_edit.setOnClickListener {
            editPassword()
        }
    }

    private fun editPassword() {
        val pwd = et_pwd?.text.toString()
        val newPwd = et_new_pwd?.text.toString()

        if (TextUtils.isEmpty(pwd)) {
            ToastUtil.show(et_pwd.hint.toString())
            return
        }
        if (TextUtils.isEmpty(newPwd)) {
            ToastUtil.show(et_new_pwd.hint.toString())
            return
        }
        if (newPwd.length < 6) {
            ToastUtil.show("密码至少6位")
            return
        }
        showProgress()
        HttpUtil.getInstance()
            .setPassword(UserMgr.getUid(), pwd, newPwd, object : ResultCallback<Any>() {
                override fun onSuccess(result: ResultEntity<Any>) {
                    dismissProgress()
                    ToastUtil.show(result.msg)
                    setResult(Constant.SET_PWD, intent)
                    finish()
                }

                override fun onFailure(err: String, code: Int) {
                    dismissProgress()
                    super.onFailure(err, code)
                }
            })
    }


}