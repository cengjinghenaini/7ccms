package com.xizhu.qiyou.ui.main

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.*
import android.text.TextUtils
import android.view.*
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.arialyy.annotations.Download
import com.arialyy.aria.core.Aria
import com.arialyy.aria.core.task.DownloadTask
import com.xizhu.qiyou.R
import com.xizhu.qiyou.apps.DownloadService
import com.xizhu.qiyou.apps.EventService
import com.xizhu.qiyou.apps.UnzipService
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.broadcast.NetBroadCastReceiver
import com.xizhu.qiyou.entity.AppUpdate
import com.xizhu.qiyou.entity.Events.InstallApk
import com.xizhu.qiyou.entity.Events.UnreadEvent
import com.xizhu.qiyou.entity.NULL
import com.xizhu.qiyou.entity.UserHome
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.service.ForegroundService
import com.xizhu.qiyou.util.FileUtil
import com.xizhu.qiyou.util.PhoneUtil
import com.xizhu.qiyou.util.UnitUtil
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.util.dialog.ToastUtil
import kotlinx.android.synthetic.main.activity_main.*
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File

class MainActivity : BaseCompatActivity() {
    private var fragmentMap = mutableMapOf<Int, Fragment>()
    private var dialog: Dialog? = null
    private var btn_commit: Button? = null
    private var ll_progress: View? = null
    private var progress: ProgressBar? = null
    private val handler = Handler(Looper.getMainLooper())
    private var progress_speed: TextView? = null
    private var taskId: Long = 0
    private val up = Runnable { this.checkAppUpdate() }
    private var netReceiver: NetBroadCastReceiver? = null
    private var apk_desc: String? = null
    private var apkPath: String? = null
    private var apk_version: String? = null

    //邀请码
    private var inviteCode: String? = null

    override fun getRes(): Int {
        return R.layout.activity_main
    }

    companion object {
        const val INVITE_SETTING = "invite_setting"
        const val INVITE_KEY = "invite_code"
        const val REQUEST_DIALOG_PERMISSION = 11

        fun start(context: Context, changeDay: Boolean) {
            val intent = Intent(context, MainActivity::class.java)
            intent.putExtra("change", changeDay)
            context.startActivity(intent)
        }
    }


    override fun saved(savedInstanceState: Bundle?) {
        if (savedInstanceState != null) {
            val home = supportFragmentManager.getFragment(savedInstanceState, "home")
            if (home != null) {
                fragmentMap[R.id.rb_home] = home
            }
            val game = supportFragmentManager.getFragment(savedInstanceState, "game")
            if (game != null) {
                fragmentMap[R.id.rb_game] = game
            }
            val mine = supportFragmentManager.getFragment(savedInstanceState, "mine")
            if (mine != null) {
                fragmentMap[R.id.rb_mine] = mine
            }
        }
        super.saved(savedInstanceState)
    }

    //
    @SuppressLint("MissingSuperCall")
    override fun onSaveInstanceState(outState: Bundle) {
        val home = fragmentMap[R.id.rb_home]
        if (home != null) {
            supportFragmentManager.putFragment(outState, "home", home)
        }
        val game = fragmentMap[R.id.rb_game]
        if (game != null) {
            supportFragmentManager.putFragment(outState, "game", game)
        }
        val mine = fragmentMap[R.id.rb_mine]
        if (mine != null) {
            supportFragmentManager.putFragment(outState, "mine", mine)
        }
        super.onSaveInstanceState(outState)
    }


    override fun getStatusColorRes(): Int {
        return R.color.C_00000000
    }

    override fun fitWindow(): Boolean {
        return false
    }

    override fun initView() {
        Aria.download(this).register()
        rg_nav.setOnCheckedChangeListener { group, checkedId ->
            showFragment(checkedId)
        }
        registerNetBroadCast()
        startService()
    }

    private fun startService() {
        //启动服务
        // Android 8.0使用startForegroundService在前台启动新服务
//        Intent mForegroundService = new Intent(this, DownloadService.class);
//        startService(mForegroundService);
        startService(Intent(this, EventService::class.java))
        startService(Intent(this, DownloadService::class.java))
        startService(Intent(this, UnzipService::class.java))
    }

    override fun initData() {
        super.initData()
        intent = Intent(this, ForegroundService::class.java)
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }

        //检查更新
//        handler.postDelayed(up, 3000);
        //初始化用户
        initUser()
        val sp = getSharedPreferences(INVITE_SETTING, MODE_PRIVATE)
        inviteCode = sp.getString(INVITE_KEY, "")
    }


    //更新用户
    private fun initUser() {
        getUserHome()
    }

    //更新用户信息
    private fun getUserHome() {
        val uid = UserMgr.getUid()
        HttpUtil.getInstance().getUserHome(uid, uid, object : ResultCallback<UserHome>() {
            override fun onSuccess(s: ResultEntity<UserHome>) {
                val user = s.data.user
                UserMgr.setUser(user)
            }
        })
    }

    private fun checkAppUpdate() {
        HttpUtil.getInstance().version(object : ResultCallback<AppUpdate>() {
            override fun onSuccess(s: ResultEntity<AppUpdate>) {
                apk_version = s.data.apk_version
                val apk_url = s.data.apk_url
                apk_desc = s.data.apk_desc
                if (!TextUtils.equals(apk_version, PhoneUtil.getVersionName())) {
                    showCheckVersion(apk_url, apk_version)
                }
            }
        })
    }


    private fun showFragment(i: Int) {
        hideAll()
        val fragment = fragmentMap[i]
        if (fragment == null) {
            val fra: Fragment = when (i) {
                R.id.rb_home -> HomeFragment()
                R.id.rb_game -> GameFragment()
                R.id.rb_message -> MessageFragment()
                R.id.rb_mine -> MineFragment()
                else -> throw IllegalStateException("Unexpected value: $i")
            }
            fragmentManager.beginTransaction().add(R.id.fl_container, fra).commit()
            fragmentMap[i] = fra
        } else {
            fragmentManager.beginTransaction().show(fragment).commit()
        }
    }

    private fun hideAll() {
        for (integer in fragmentMap.keys) {
            val fragment = fragmentMap[integer]
            if (fragment != null) {
                fragmentManager.beginTransaction().hide(fragment).commit()
            }
        }
    }


    override fun isRegisterEventBus(): Boolean {
        return true
    }

    override fun initEvent() {
        super.initEvent()
        val change = intent.getBooleanExtra("change", false)
        if (change) {
            rg_nav.check(R.id.rb_mine)
        } else {
            rg_nav.check(R.id.rb_home)
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onInstallApk(installApk: InstallApk) {
        FileUtil.installApk(activity, installApk.apkPath)
    }


    fun showCheckVersion(apk_url: String?, apk_version: String?) {
        val spVersion = PhoneUtil.getSpVersion(this)
        var spPath = PhoneUtil.getSpPath(this)
        val spDesc = PhoneUtil.getSpDesc(this)
        if (spPath == null) {
            spPath = ""
        }
        val file = File(spPath)
        if (!TextUtils.isEmpty(spPath) && file.exists() && file.isFile && TextUtils.equals(
                spVersion,
                apk_version
            )
        ) {
            showDialog((spDesc ?: apk_desc)!!, spPath)
        } else {
            apkPath =
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).path + "/" + System.currentTimeMillis() + ".apk"
            taskId = Aria.download(this).load(apk_url).setFilePath(apkPath).create()
        }
    }


    private fun showDialog(apk_desc: String, apkPath: String) {
        dialog = Dialog(this, R.style.DialogRing)
        val root = LayoutInflater.from(this).inflate(R.layout.dialog_show_update, null)
        root.findViewById<View>(R.id.btn_cancel)
            .setOnClickListener { v: View? -> dialog?.dismiss() }
        ll_progress = root.findViewById(R.id.ll_progress)
        btn_commit = root.findViewById(R.id.btn_commit)
        val up_desc = root.findViewById<TextView>(R.id.up_desc)
        progress = root.findViewById(R.id.progress)
        progress_speed = root.findViewById(R.id.progress_speed)
        up_desc.text = apk_desc
        btn_commit?.setOnClickListener(View.OnClickListener { v: View? ->
            FileUtil.installApk(
                activity,
                apkPath
            )
        })
        dialog?.setContentView(root)
        dialog?.setCancelable(false)
        dialog?.setCanceledOnTouchOutside(false)
        dialog?.show()
        val window = dialog?.getWindow()
        val attributes = window?.attributes
        attributes?.height = WindowManager.LayoutParams.WRAP_CONTENT
        attributes?.width = UnitUtil.dip2px(this, 280f)
        attributes?.gravity = Gravity.CENTER
        window?.attributes = attributes
    }

    @Download.onPre
    fun onPre(task: DownloadTask?) {
//        if (task != null && task.getEntity().getId() == taskId) {
////            ll_progress.setVisibility(View.VISIBLE);
////            btn_commit.setText("更新中");
////            btn_commit.setOnClickListener(null);
//        }
    }

    @Download.onTaskFail
    fun onTaskFail(task: DownloadTask?) {
//        if (task != null && task.getEntity().getId() == taskId) {
////            ll_progress.setVisibility(View.GONE);
////            ToastUtil.show("更新失败");
//        }
    }

    @Download.onTaskRunning
    fun onTaskRunning(task: DownloadTask?) {
//        if (task != null && task.getEntity().getId() == taskId) {
//            progress_speed.setText(task.getPercent() + "%");
//            progress.setProgress(task.getPercent());
//        }
    }

    @Download.onTaskComplete
    fun onTaskComplete(task: DownloadTask?) {
        if (task != null && task.entity != null && task.entity.id == taskId) {
            PhoneUtil.putSpVersion(this, apk_version)
            PhoneUtil.putSpPath(this, apkPath)
            PhoneUtil.putSpDesc(this, apk_desc)
            showDialog(apk_desc!!, apkPath!!)
        }
    }


    override fun onBackPressed() {
        handler.removeCallbacks(up)
        if (dialog != null && dialog?.isShowing == true) {
            dialog?.dismiss()
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopService(intent)
        handler.removeCallbacks(up)
        if (netReceiver != null) {
            unregisterReceiver(netReceiver)
        }
    }

    //注册网络状态广播
    private fun registerNetBroadCast() {
        netReceiver = NetBroadCastReceiver()
        val filter = IntentFilter()
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        registerReceiver(netReceiver, filter)
    }

    override fun setRequestedOrientation(requestedOrientation: Int) {
        super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
    }


    private var mExitTime: Long = 0

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        //判断用户是否点击了“返回键”
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            //与上次点击返回键时刻作差
            if (System.currentTimeMillis() - mExitTime > 2000) {
                //大于2000ms则认为是误操作，使用Toast进行提示
                //并记录下本次点击“返回键”的时刻，以便下次进行判断
                ToastUtil.show("再按一次退出程序")
                mExitTime = System.currentTimeMillis()
            } else {
                //小于2000ms则认为是用户确实希望退出程序-调用System.exit()方法进行退出
//                AppManager.getAppManager().finishAllActivity();
                finish()
                //                System.exit(0);
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        if (!TextUtils.isEmpty(inviteCode) && UserMgr.isLogin()) {
            dealWithInvite()
        }
    }

    private fun dealWithInvite() {
        val uid = UserMgr.getUid()
        HttpUtil.getInstance()
            .setInviteCode(uid, inviteCode, object : ResultCallback<NULL>() {
                override fun onSuccess(s: ResultEntity<NULL>) {
                    inviteCode = ""
                    val sp = getSharedPreferences(INVITE_SETTING, MODE_PRIVATE)
                    val editor = sp.edit()
                    editor.clear()
                    editor.commit()
                    //                ToastUtil.show(s.getState().getMsg());
//                Log.e(TAG, "dealWithInvite success");
                }

                override fun onFailure(err: String, code: Int) {
                    inviteCode = ""
                    val sp = getSharedPreferences(INVITE_SETTING, MODE_PRIVATE)
                    val editor = sp.edit()
                    editor.clear()
                    editor.commit()
                    //                Log.e(TAG, "dealWithInvite failled");
                    super.onFailure(err, code)
                }
            })
    }

    override fun onPause() {
        if (!TextUtils.isEmpty(inviteCode)) {
            val sp = getSharedPreferences(INVITE_SETTING, MODE_PRIVATE)
            val editor = sp.edit()
            editor.putString(INVITE_KEY, inviteCode)
            editor.commit()
        }
        super.onPause()
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    fun showUnreadMessage(unreadEvent: UnreadEvent) {
        tv_unread_count?.visibility = if (unreadEvent.count > 0) View.VISIBLE else View.GONE
        tv_unread_count?.text = unreadEvent.count.toString()
    }

}