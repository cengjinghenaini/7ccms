package com.xizhu.qiyou.base

import android.content.Context
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.*
import androidx.annotation.LayoutRes
import androidx.fragment.app.DialogFragment
import com.xizhu.qiyou.R


abstract class BaseBottomDialogFragment : DialogFragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
        return inflater.inflate(getLayoutId(), container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
        initData()
    }

    override fun onStart() {
        super.onStart()
        initDialogStyle()
    }

    /**
     * DialogFragment Style
     */
    private fun initDialogStyle() {
        val window = dialog?.window
        context?.let {
            window?.setLayout(
                getScreenWidth(it),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        window?.setGravity(Gravity.BOTTOM)
        window?.setWindowAnimations(R.style.AnimBottom)
    }

    //Screen
    fun getScreenWidth(context: Context): Int {
        val dm = DisplayMetrics()
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        wm?.defaultDisplay?.getMetrics(dm)
        return dm.widthPixels
    }

    @LayoutRes
    abstract fun getLayoutId(): Int

    abstract fun initView()

    abstract fun initData()

}