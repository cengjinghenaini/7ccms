package com.xizhu.qiyou.ui.translation.entity;

public class Status {
    String status;

    public Status(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setOpen(String open) {
        status = open;
    }
}
