package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class UserRecDetailGame {

    /**
     * id : value
     * app_id : value
     * name : value
     * createtime : value
     * createtime_f : value
     * phone_type : value
     * rec_reason : value
     * is_release : value
     * score : value
     * zan_count : value
     * comment_count : value
     * app : {"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value","is_reserve":"value","yiyuyue":"value"}
     * user : {"uid":"value","phone":"value","email":"value","name":"value","wx_name":"value","qq":"value","head":"value","touxian_id":"value","touxian":"value","sex":"value","is_member":"value","age":"value","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":"","is_attention":"value"}
     */

    private String id;
    private String app_id;
    private String name;
    private String createtime;
    private String createtime_f;
    private String phone_type;
    private String rec_reason;
    private String is_release;
    private String score;
    private String zan_count;
    private String comment_count;
    private AppBean app;
    private UserBean user;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getCreatetime_f() {
        return createtime_f;
    }

    public void setCreatetime_f(String createtime_f) {
        this.createtime_f = createtime_f;
    }

    public String getPhone_type() {
        return phone_type;
    }

    public void setPhone_type(String phone_type) {
        this.phone_type = phone_type;
    }

    public String getRec_reason() {
        return rec_reason;
    }

    public void setRec_reason(String rec_reason) {
        this.rec_reason = rec_reason;
    }

    public String getIs_release() {
        return is_release;
    }

    public void setIs_release(String is_release) {
        this.is_release = is_release;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getZan_count() {
        return zan_count;
    }

    public void setZan_count(String zan_count) {
        this.zan_count = zan_count;
    }

    public String getComment_count() {
        return comment_count;
    }

    public void setComment_count(String comment_count) {
        this.comment_count = comment_count;
    }

    public AppBean getApp() {
        return app;
    }

    public void setApp(AppBean app) {
        this.app = app;
    }

    public UserBean getUser() {
        return user;
    }

    public void setUser(UserBean user) {
        this.user = user;
    }

    public static class AppBean implements Serializable {
        /**
         * id : value
         * pic : value
         * title : value
         * name : value
         * icon : value
         * introduction : value
         * score : value
         * comment_count : value
         * version : value
         * size : value
         * down_time : value
         * rec_reason : value
         * is_reserve : value
         * yiyuyue : value
         */

        private String id;
        private String pic;
        private String title;
        private String name;
        private String icon;
        private String introduction;
        private String score;
        private String comment_count;
        private String version;
        private String size;
        private String down_time;
        private String rec_reason;
        private String is_reserve;
        private String yiyuyue;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPic() {
            return pic;
        }

        public void setPic(String pic) {
            this.pic = pic;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        public String getIntroduction() {
            return introduction;
        }

        public void setIntroduction(String introduction) {
            this.introduction = introduction;
        }

        public String getScore() {
            return score;
        }

        public void setScore(String score) {
            this.score = score;
        }

        public String getComment_count() {
            return comment_count;
        }

        public void setComment_count(String comment_count) {
            this.comment_count = comment_count;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getSize() {
            return size;
        }

        public void setSize(String size) {
            this.size = size;
        }

        public String getDown_time() {
            return down_time;
        }

        public void setDown_time(String down_time) {
            this.down_time = down_time;
        }

        public String getRec_reason() {
            return rec_reason;
        }

        public void setRec_reason(String rec_reason) {
            this.rec_reason = rec_reason;
        }

        public String getIs_reserve() {
            return is_reserve;
        }

        public void setIs_reserve(String is_reserve) {
            this.is_reserve = is_reserve;
        }

        public String getYiyuyue() {
            return yiyuyue;
        }

        public void setYiyuyue(String yiyuyue) {
            this.yiyuyue = yiyuyue;
        }
    }

    public static class UserBean implements Serializable {
        /**
         * uid : value
         * phone : value
         * email : value
         * name : value
         * wx_name : value
         * qq : value
         * head : value
         * touxian_id : value
         * touxian : value
         * sex : value
         * is_member : value
         * age : value
         * sign :
         * integral :
         * exp :
         * contribution :
         * grade_id :
         * grade_name :
         * is_attention : value
         */

        private String uid;
        private String phone;
        private String email;
        private String name;
        private String wx_name;
        private String qq;
        private String head;
        private String touxian_id;
        private String touxian;
        private String sex;
        private String is_member;
        private String age;
        private String sign;
        private String integral;
        private String exp;
        private String contribution;
        private String grade_id;
        private String grade_name;
        private String is_attention;

        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getWx_name() {
            return wx_name;
        }

        public void setWx_name(String wx_name) {
            this.wx_name = wx_name;
        }

        public String getQq() {
            return qq;
        }

        public void setQq(String qq) {
            this.qq = qq;
        }

        public String getHead() {
            return head;
        }

        public void setHead(String head) {
            this.head = head;
        }

        public String getTouxian_id() {
            return touxian_id;
        }

        public void setTouxian_id(String touxian_id) {
            this.touxian_id = touxian_id;
        }

        public String getTouxian() {
            return touxian;
        }

        public void setTouxian(String touxian) {
            this.touxian = touxian;
        }

        public String getSex() {
            return sex;
        }

        public void setSex(String sex) {
            this.sex = sex;
        }

        public String getIs_member() {
            return is_member;
        }

        public void setIs_member(String is_member) {
            this.is_member = is_member;
        }

        public String getAge() {
            return age;
        }

        public void setAge(String age) {
            this.age = age;
        }

        public String getSign() {
            return sign;
        }

        public void setSign(String sign) {
            this.sign = sign;
        }

        public String getIntegral() {
            return integral;
        }

        public void setIntegral(String integral) {
            this.integral = integral;
        }

        public String getExp() {
            return exp;
        }

        public void setExp(String exp) {
            this.exp = exp;
        }

        public String getContribution() {
            return contribution;
        }

        public void setContribution(String contribution) {
            this.contribution = contribution;
        }

        public String getGrade_id() {
            return grade_id;
        }

        public void setGrade_id(String grade_id) {
            this.grade_id = grade_id;
        }

        public String getGrade_name() {
            return grade_name;
        }

        public void setGrade_name(String grade_name) {
            this.grade_name = grade_name;
        }

        public String getIs_attention() {
            return is_attention;
        }

        public void setIs_attention(String is_attention) {
            this.is_attention = is_attention;
        }
    }
}
