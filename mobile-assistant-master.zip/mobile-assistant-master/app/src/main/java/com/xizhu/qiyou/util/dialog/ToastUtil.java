package com.xizhu.qiyou.util.dialog;

import android.content.Context;
import android.widget.Toast;

import com.xizhu.qiyou.util.AppConfig;

public class ToastUtil {

    public static void show(Context context, String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    public static void show(String msg) {
        Toast.makeText(AppConfig.getApplication(), msg, Toast.LENGTH_SHORT).show();
    }
}
