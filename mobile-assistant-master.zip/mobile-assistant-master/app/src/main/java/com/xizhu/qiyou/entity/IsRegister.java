package com.xizhu.qiyou.entity;

public class IsRegister {

    /**
     * isRegister : 0
     */

    private int isRegister;

    public int getIsRegister() {
        return isRegister;
    }

    public void setIsRegister(int isRegister) {
        this.isRegister = isRegister;
    }
}
