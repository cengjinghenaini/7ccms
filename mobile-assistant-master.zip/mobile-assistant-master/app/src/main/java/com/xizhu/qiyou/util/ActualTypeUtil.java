package com.xizhu.qiyou.util;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public class ActualTypeUtil {

    public static Type getActualType(Object object) {
        ParameterizedType genericSuperclass = (ParameterizedType) object.getClass().getGenericSuperclass();
        Type[] actualTypeArguments = genericSuperclass.getActualTypeArguments();
        return actualTypeArguments[0];
    }
}
