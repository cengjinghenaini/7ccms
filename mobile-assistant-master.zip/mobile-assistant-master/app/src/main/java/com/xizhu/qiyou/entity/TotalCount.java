package com.xizhu.qiyou.entity;

public class TotalCount {

    /**
     * attention : 0
     * collect : 0
     * fans : 0
     * posts : 0
     */

    private String attention;
    private String collect;
    private String fans;
    private String posts;

    public String getAttention() {
        return attention;
    }

    public void setAttention(String attention) {
        this.attention = attention;
    }

    public String getCollect() {
        return collect;
    }

    public void setCollect(String collect) {
        this.collect = collect;
    }

    public String getFans() {
        return fans;
    }

    public void setFans(String fans) {
        this.fans = fans;
    }

    public String getPosts() {
        return posts;
    }

    public void setPosts(String posts) {
        this.posts = posts;
    }
}
