package com.xizhu.qiyou.base;

import android.app.Activity;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.xizhu.qiyou.R;
import com.xizhu.qiyou.broadcast.NetBroadCastReceiver;
import com.xizhu.qiyou.widget.LoadingDialog;
import com.zackratos.ultimatebarx.library.UltimateBarX;

import org.greenrobot.eventbus.EventBus;
import org.jetbrains.annotations.NotNull;

import java.util.List;

import butterknife.ButterKnife;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

public abstract class BaseActivity extends AppCompatActivity {
    public String TAG = this.getClass().getSimpleName();
    public FragmentManager fragmentManager;
    protected TabLayout tabLayout;
    protected ViewPager viewPager;
    protected Integer tabItemRes;
    protected List<Fragment> fragmentList;
    protected String[] titles;
    private Activity activity;
    protected LoadingDialog loadingDialog;
    private NetBroadCastReceiver netReceiver;
    private CompositeDisposable mCompositeDisposable;


    public Context getActivity() {
        return activity;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getRes());
        registerNetBroadCast();
        activity = this;
        ButterKnife.bind(this);
        loadingDialog = new LoadingDialog(this, R.style.DialogRing);
        loadingDialog.setTitle("正在加载中...");

        if (isRegisterEventBus()) {
            EventBus.getDefault().register(this);
        }
//        if (isSetUltimateBar()){
//            setStatusBar();
//        }

        // 如果页面有标题栏的返回键
        TextView back = findViewById(R.id.back);
        if (back != null) {
            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
        }

        initView();
        initData();
        initEvent();
    }


    //注册网络状态广播
    private void registerNetBroadCast() {
        netReceiver = new NetBroadCastReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netReceiver, filter);
    }

    // 是否使用UltimateBar
    protected boolean isSetUltimateBar() {
        return true;
    }

    //设置沉浸式状态栏
    private void setStatusBar() {
        UltimateBarX.create(UltimateBarX.STATUS_BAR)
                .fitWindow(fitWindow())
                .bgColorRes(getStatusColorRes())
                .light(isLight())
                .apply(this);
    }

    //是否阻止入侵
    protected boolean fitWindow() {
        return true;
    }

    //状态栏是否高亮
    protected boolean isLight() {
        return true;
    }

    //    返回状态栏颜色，可复写, 默认返回白色
    protected int getStatusColorRes() {
        return R.color.windowBackground;
    }


    protected void showProgress() {
        if (loadingDialog != null && !loadingDialog.isShowing()) {
            loadingDialog.show();
        }
    }


    protected boolean isShowing() {
        if (loadingDialog != null) {
            return loadingDialog.isShowing();
        }
        return false;
    }


    protected void dismissProgress() {
        if (loadingDialog != null && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }
    }


    protected boolean isRegisterEventBus() {
        return false;
    }


    // 返回
    protected List<Fragment> hasFragments() {
        return null;
    }

    // 返回tabItem资源
    protected Integer hasTabAndPager() {
        return null;
    }

    // 返回标题集
    protected String[] hasTitles() {
        return null;
    }


    protected abstract int getRes();

    protected abstract void initView();

    protected void initData() {
    }

    protected void initEvent() {
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        loadingDialog = null;
        if (isRegisterEventBus()) {
            EventBus.getDefault().unregister(this);
        }
        unregisterReceiver(netReceiver);
        unDisposable();
    }


    @Override
    public void setRequestedOrientation(int requestedOrientation) {
        super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

    public boolean addObserver(@NotNull Disposable disposable) {
        if (mCompositeDisposable == null) {
            mCompositeDisposable = new CompositeDisposable();
        }
        return mCompositeDisposable.add(disposable);
    }


    public void unDisposable() {
        if (mCompositeDisposable != null) {
            mCompositeDisposable.clear();
        }
    }
}
