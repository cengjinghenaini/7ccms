package com.xizhu.qiyou.entity;

import android.os.Parcel;

public class Record extends BaseApp{
    protected Record(Parcel in) {
        super(in);
    }

    /**
     * id : value
     * pic : value
     * title : value
     * name : value
     * icon : value
     * introduction : value
     * score : value
     * comment_count : value
     * version : value
     * size : value
     * down_time : value
     * rec_reason : value
     * labels : [{"id":"","name":""}]
     */


}
