package com.xizhu.qiyou.util;

import android.content.Context;

import com.tencent.cos.xml.CosXmlService;
import com.tencent.cos.xml.CosXmlServiceConfig;
import com.tencent.cos.xml.exception.CosXmlClientException;
import com.tencent.cos.xml.exception.CosXmlServiceException;
import com.tencent.cos.xml.listener.CosXmlProgressListener;
import com.tencent.cos.xml.listener.CosXmlResultListener;
import com.tencent.cos.xml.model.CosXmlRequest;
import com.tencent.cos.xml.model.CosXmlResult;
import com.tencent.cos.xml.transfer.COSXMLUploadTask;
import com.tencent.cos.xml.transfer.TransferConfig;
import com.tencent.cos.xml.transfer.TransferManager;
import com.tencent.qcloud.core.auth.QCloudCredentialProvider;
import com.tencent.qcloud.core.auth.ShortTimeCredentialProvider;
import com.xizhu.qiyou.config.COSConfig;
import com.xizhu.qiyou.inter.CosPutProgress;
import com.xizhu.qiyou.inter.CosPutResult;

public class Cos {
    private static Cos instance;
    private final TransferManager transferManager;

    public static void init(Context context) {
        instance = new Cos(context);
    }

    private Cos(Context context) {
        // 创建密钥对象 keyDuration 为请求中的密钥有效期，单位为秒
        QCloudCredentialProvider myCredentialProvider =
                new ShortTimeCredentialProvider(COSConfig.secretId, COSConfig.secretKey, 300);
        // 创建 CosXmlServiceConfig 对象，根据需要修改默认的配置参数
        CosXmlServiceConfig serviceConfig = new CosXmlServiceConfig.Builder()
                .setRegion(COSConfig.region)
                .isHttps(true) // 使用 HTTPS 请求, 默认为 HTTP 请求
                .builder();

        CosXmlService cosXmlService = new CosXmlService(context,
                serviceConfig, myCredentialProvider);

        // 初始化 TransferConfig，这里使用默认配置，如果需要定制，请参考 SDK 接口文档
        TransferConfig transferConfig = new TransferConfig.Builder().build();
        // 初始化 TransferManager
        transferManager = new TransferManager(cosXmlService,
                transferConfig);
    }




    public static Cos getInstance() {
        if (instance == null) {
            throw new IllegalArgumentException("Cos is not init");
        }
        return instance;
    }
    public TransferManager getTransferMgr(){
        return transferManager;
    }
    public void putObj(String objKey, String srcPath, CosPutProgress putProgress, CosPutResult cosPutResult) {
        //为null时是新建上传
        String uploadId = null;
        // 上传文件
        COSXMLUploadTask cosxmlUploadTask = transferManager.upload(COSConfig.bucket, objKey,
                srcPath, uploadId);

        //监听进度
        cosxmlUploadTask.setCosXmlProgressListener(new CosXmlProgressListener() {
            @Override
            public void onProgress(long complete, long target) {
                if (putProgress != null) {
                    putProgress.onProgress(complete, target);
                }
            }
        });

        //结果回调
        cosxmlUploadTask.setCosXmlResultListener(new CosXmlResultListener() {
            @Override
            public void onSuccess(CosXmlRequest request, CosXmlResult result) {
                if (cosPutResult != null) {
                    LogUtil.e("onSuccess: " );
                    cosPutResult.onPutSuccess(request, result);
                }
            }

            @Override
            public void onFail(CosXmlRequest request, CosXmlClientException exception, CosXmlServiceException serviceException) {
                if (cosPutResult != null) {
                    cosPutResult.onPutFail(request, exception, serviceException);
                }
            }
        });
    }
}
