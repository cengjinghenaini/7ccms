package com.xizhu.qiyou.util;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.FitCenter;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.pass.util.UIUtil;
import com.xizhu.qiyou.R;

public class ImgLoadUtil {

    public static void previewBig(ImageView img, String url) {
        if (img == null) {
            return;
        }
        Context context = img.getContext();
        if (context instanceof Activity && ((Activity) context).isDestroyed()) {
            return;
        }
        Glide.with(img.getContext())
                .load(url)
                .centerCrop()
                .placeholder(R.color.color_f7)
                .error(R.color.color_f7)
                .into(img);
    }

    public static void load(ImageView img, String url) {
        if (img == null) {
            return;
        }
        Context context = img.getContext();
        if (context instanceof Activity && ((Activity) context).isDestroyed()) {
            return;
        }
        Glide.with(context)
                .load(url)
                .centerCrop()
                .placeholder(R.color.color_f7)
                .error(R.color.color_f7)
                .into(img);
//
//        if (TextUtils.isEmpty(url)) {
//            img.setImageResource(R.mipmap.img_place_holder);
//        } else {
//            Glide.with(img.getContext())
//                    .setDefaultRequestOptions(
//                            new RequestOptions()
//                                    .error(R.mipmap.img_place_holder)
//                                    .fitCenter()
//                    )
//                    .asBitmap()
//                    .load(url)
//                    .into(img);
//        }
    }    public static void load1(ImageView img, String url) {
        if (img == null) {
            return;
        }
        Context context = img.getContext();
        if (context instanceof Activity && ((Activity) context).isDestroyed()) {
            return;
        }
        Glide.with(context)
                .load(url)
                .placeholder(R.color.color_f7)
                .error(R.color.color_f7)
                .into(img);
//
//        if (TextUtils.isEmpty(url)) {
//            img.setImageResource(R.mipmap.img_place_holder);
//        } else {
//            Glide.with(img.getContext())
//                    .setDefaultRequestOptions(
//                            new RequestOptions()
//                                    .error(R.mipmap.img_place_holder)
//                                    .fitCenter()
//                    )
//                    .asBitmap()
//                    .load(url)
//                    .into(img);
//        }
    }

    public static void loadHead(ImageView headView, String url) {
        if (headView == null) {
            return;
        }
        Context context = headView.getContext();
        if (context instanceof Activity && ((Activity) context).isDestroyed()) {
            return;
        }
        Glide.with(context)
                .load(url)
                .centerCrop()
                .placeholder(R.mipmap.icon_mine_header)
                .error(R.mipmap.icon_mine_header)
                .into(headView);
    }


    public static <T extends ImageView> void load(T h, T v, String url) {


        RequestOptions options = new RequestOptions()
                .error(R.color.color_e8);

        Glide.with(h)
                .load(url)
                .apply(options)
                .into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@Nullable Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        int minimumWidth = resource.getMinimumWidth();
                        int minimumHeight = resource.getMinimumHeight();

                        if (minimumWidth > minimumHeight) {
                            h.setVisibility(View.VISIBLE);
                            v.setVisibility(View.GONE);
                            h.setImageDrawable(resource);
                        } else {
                            h.setVisibility(View.GONE);
                            v.setVisibility(View.VISIBLE);
                            v.setImageDrawable(resource);
                        }
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });

    }
}
