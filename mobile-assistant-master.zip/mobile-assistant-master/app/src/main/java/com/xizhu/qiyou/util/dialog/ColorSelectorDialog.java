//package com.xizhu.qiyou.util.dialog;
//
//import android.app.Dialog;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.WindowManager;
//
//import androidx.appcompat.app.AlertDialog;
//
//import com.larswerkman.holocolorpicker.ColorPicker;
//import com.larswerkman.holocolorpicker.OpacityBar;
//import com.larswerkman.holocolorpicker.SVBar;
//import com.xizhu.qiyou.R;
//
//public class ColorSelectorDialog {
//
//    private final Context mContext;
//    private final View mDialogView;
//    private ColorPicker mColorPickerView;
//    private SVBar mSVBar;
//    private OpacityBar mOpacityBar;
//    private OnColorChangeListener mListenr;
//    private Dialog mDialog;
//
//    public ColorSelectorDialog(Context context,OnColorChangeListener listener) {
//        this.mContext = context;
//        this.mListenr = listener;
//        mDialogView = LayoutInflater.from(mContext).inflate(R.layout.colo_picker_view,null);
//        mColorPickerView = mDialogView.findViewById(R.id.color_picker_view);
//        //饱和度Bar
//        mSVBar = mDialogView.findViewById(R.id.color_picker_SVB_bar);
//        //不透明度Bar
//        mOpacityBar = mDialogView.findViewById(R.id.color_picker_opacity_bar);
//        //将以上两种Bar和mColorPickerView连接起来
//        mColorPickerView.addOpacityBar(mOpacityBar);
//        mColorPickerView.addSVBar(mSVBar);
//
//        //监听ColorPicker颜色改变
//        mColorPickerView.setOnColorChangedListener(new ColorPicker.OnColorChangedListener() {
//            @Override
//            public void onColorChanged(int color) {
//                //通知外面当前选择的颜色
//                mListenr.onColorChange(color);
//            }
//        });
//        //创建对话框
//        AlertDialog.Builder builder = new AlertDialog.Builder(mContext,R.style.DialogRing);
//
//        Dialog dialog = new Dialog(context, R.style.DialogRing);
//
//        dialog.setCancelable(false);
//        dialog.setContentView(mDialogView);
//
//
////        builder.setTitle("")//对话框标题
////                .setView(mDialogView)//对话框中显示的View
////                .setCancelable(false)
////                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
////                    @Override
////                    public void onClick(DialogInterface dialogInterface, int i) {
////                        dialogInterface.dismiss();
////                        //也可以在这里调用回调方法来获取最后选中的颜色
////                    }
////                })
////                .create();
//        mDialog = dialog;
//    }
//
//    public void showDialog(){
//        //显示对话框
//        mDialog.show();
//        //下面这句代码用于设置对话框的大小，调整大小使颜色选择器能够完全显示不被遮挡
//        mDialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,1100);
//    }
//
//    //颜色改变时的回调接口
//    public interface OnColorChangeListener{
//        void onColorChange(int color);
//    }
//
//    public int getColor(){
//        //获取当前选中颜色
//        return mColorPickerView.getColor();
//    }
//}
