package com.xizhu.qiyou.ui.commnet

import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.iarcuschin.simpleratingbar.SimpleRatingBar
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.Reply
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.UnitUtil

class GameCommentReplyAdapter :
    BaseQuickAdapter<Reply, BaseViewHolder>(R.layout.item_recy_game_comment_reply) {
    override fun convert(holder: BaseViewHolder, item: Reply) {
        ImgLoadUtil.loadHead(holder.getView(R.id.iv_head), item.user?.head)
        holder.setText(R.id.tv_name, item.user?.name)
        holder.setText(R.id.tv_date, UnitUtil.time(item.createtime))
        holder.setText(R.id.tv_content, item.content)
        val score = item.score.toFloat()

        val ratingBar = holder.getView<SimpleRatingBar>(R.id.rating_bar)
        ratingBar.rating = score
    }
}