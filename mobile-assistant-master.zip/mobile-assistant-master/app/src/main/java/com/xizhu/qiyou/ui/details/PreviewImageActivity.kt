package com.xizhu.qiyou.ui.details

import android.content.Context
import android.content.Intent
import androidx.viewpager.widget.ViewPager
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import kotlinx.android.synthetic.main.activity_preview_image.*
import kotlinx.android.synthetic.main.title_layout.*
import java.util.*

class PreviewImageActivity : BaseCompatActivity() {
    private val imageList = mutableListOf<String>()
    private var position = -1
    private var adapter: PreviewImageAdapter? = null

    companion object {
        fun start(context: Context, images: ArrayList<String>, position: Int = 0) {
            val intent = Intent(context, PreviewImageActivity::class.java)
            intent.putExtra("images", images)
            intent.putExtra("position", position)
            context.startActivity(intent)
        }
    }

    override fun getRes(): Int {
        return R.layout.activity_preview_image
    }

    override fun initView() {
        val images = intent.getStringArrayListExtra("images")
        if (images != null && images.isNotEmpty()) {
            imageList.addAll(images)
        }
        position = intent.getIntExtra("position", position)
        iv_back.setOnClickListener {
            finish()
        }
        adapter = PreviewImageAdapter(this) { finish() }
        adapter?.bindData(imageList)
        preview_pager.adapter = adapter
        preview_pager.currentItem = position
        setTitle()
        preview_pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(i: Int) {
                position = i
                setTitle()
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
    }

    private fun setTitle() {
        tv_page_title.text =
            getString(R.string.preview_image_num, position + 1, adapter!!.size)
    }

    override fun onDestroy() {
        super.onDestroy()
        adapter?.clear()
    }
}