package com.xizhu.qiyou.ui.details

import android.app.Activity
import android.content.Intent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.scwang.smart.refresh.layout.api.RefreshLayout
import com.scwang.smart.refresh.layout.listener.OnRefreshLoadMoreListener
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.DetailGame
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.ui.commnet.GameCommentDetailsActivity
import com.xizhu.qiyou.ui.commnet.ReleaseGameCommentActivity
import com.xizhu.qiyou.util.PopupUtils
import com.xizhu.qiyou.util.UnitUtil
import com.xizhu.qiyou.util.UserMgr
import kotlinx.android.synthetic.main.fragment_game_comment.*
import kotlinx.android.synthetic.main.header_game_comment.view.*

class GameCommentFragment : BaseFragment(), View.OnClickListener {
    private var adapter: GameCommentAdapter? = null
    private var headerView: View? = null
    private var detailGame: DetailGame? = null
    private var pageNum = 1
    private var type = 0

    companion object {
        fun instance(detailGame: DetailGame): GameCommentFragment {
            val fragment = GameCommentFragment()
            fragment.detailGame = detailGame
            return fragment
        }
    }


    override fun getRes(): Int {
        return R.layout.fragment_game_comment
    }

    override fun initView() {
        super.initView()
        refresh_layout?.setOnRefreshLoadMoreListener(object : OnRefreshLoadMoreListener {
            override fun onRefresh(refreshLayout: RefreshLayout) {
                pageNum = 1
                getAppComment()
            }

            override fun onLoadMore(refreshLayout: RefreshLayout) {
                pageNum++
                getAppComment()
            }
        })
        recycler.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        adapter = GameCommentAdapter().apply {
            addChildClickViewIds(R.id.iv_head, R.id.iv_head_replay, R.id.tv_reply_count)
            setOnItemChildClickListener { _, view, position ->
                val item = getItem(position)
                when (view.id) {
                    R.id.iv_head -> {
                        PopupUtils.showUserInfo(item.user, view)
                    }
                    R.id.iv_head_replay -> {
                        PopupUtils.showUserInfo(item.replys[0].user, view)
                    }
                    R.id.tv_reply_count -> {
                        if (detailGame != null) {
                            GameCommentDetailsActivity.start(context, detailGame!!, item)
                        }
                    }
                }
            }
            setOnItemClickListener { _, _, position ->
                val item = getItem(position)
                activity?.let {
                    ReleaseGameCommentActivity.start(
                        it, detailGame?.id, item
                    )
                }
            }
        }
        recycler.adapter = adapter
        initHeader()
    }

    private fun initHeader() {
        headerView = View.inflate(context, R.layout.header_game_comment, null)
        headerView?.tv_add_comment?.setOnClickListener(this)
        headerView?.rb_all?.setOnClickListener(this)
        headerView?.rb_good?.setOnClickListener(this)
        headerView?.rb_middle?.setOnClickListener(this)
        headerView?.rb_last?.setOnClickListener(this)
        adapter?.addHeaderView(headerView!!)
    }


    override fun initData() {
        super.initData()
        headerView?.apply {
            tv_score.text = detailGame?.score
            tv_comment_number.text = "${detailGame?.comment_count}人参与了评论"
            tv_rate.text = "${detailGame?.comment_count}% 好评率"
        }
        getAppComment()
    }


    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.tv_add_comment -> {
                activity?.let { it1 ->
                    ReleaseGameCommentActivity.start(
                        it1,
                        detailGame?.id
                    )
                }
            }
            R.id.rb_all -> {
                pageNum = 1
                type = 0
                getAppComment()
            }
            R.id.rb_good -> {
                pageNum = 1
                type = 3
                getAppComment()
            }
            R.id.rb_middle -> {
                pageNum = 1
                type = 2
                getAppComment()
            }
            R.id.rb_last -> {
                pageNum = 1
                type = 1
                getAppComment()
            }
        }
    }

    private fun getAppComment() {
        if (detailGame == null) {
            return
        }
        val params = hashMapOf<String, String?>()
        params["uid"] = UserMgr.getUid()
        params["app_id"] = detailGame?.id
        params["page"] = pageNum.toString()
        params["pageSize"] = Constant.PAGE_SIZE
        params["score_type"] = type.toString()
        val disposable = getApiService()
            .getAppComment(params)
            .compose(IoMainScheduler())
            .subscribe({
                val data = it.data
                if (pageNum == 1) {
                    adapter?.setNewInstance(data)
                } else {
                    adapter?.addData(data)
                }
                if (data.size >= Constant.PAGE_SIZE.toInt()) {
                    refresh_layout?.setEnableLoadMore(true)
                } else {
                    refresh_layout?.setEnableLoadMore(false)
                }
                refresh_layout?.finishRefresh()
                refresh_layout?.finishLoadMore()
            }) {
                refresh_layout?.setEnableLoadMore(false)
                refresh_layout?.finishRefresh(false)
                refresh_layout?.finishLoadMore(false)
                if (pageNum > 1) {
                    pageNum--
                }
            }
        addObserver(disposable)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            pageNum = 1
            getAppComment()
        }
    }


}