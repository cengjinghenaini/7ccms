package com.xizhu.qiyou.ui.main

import android.view.View
import androidx.core.content.ContextCompat
import com.pass.util.DisplayUtil
import com.qmuiteam.qmui.widget.textview.QMUISpanTouchFixTextView
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.Label
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import kotlinx.android.synthetic.main.activity_browser_history.empty_view
import kotlinx.android.synthetic.main.activity_browser_history.refresh_layout
import kotlinx.android.synthetic.main.activity_label_list.*
import kotlinx.android.synthetic.main.title_layout.*

class LabelListActivity : BaseCompatActivity() {
    private var textColor: Int = 0
    private var tagBgColor: Int = 0
    private var dp4: Int = 0
    private var dp12: Int = 0
    private var dp20: Int = 0

    override fun getRes(): Int {
        return R.layout.activity_label_list
    }

    override fun initView() {
        iv_back.setOnClickListener {
            finish()
        }
        tv_page_title.text = "全部标签"
        refresh_layout.setOnRefreshListener {
            getAppLabel()
        }
        textColor = ContextCompat.getColor(this, R.color.color_66)
        tagBgColor = ContextCompat.getColor(this, R.color.color_ee)
        dp4 = DisplayUtil.dip2px(this, 4f)
        dp12 = DisplayUtil.dip2px(this, 12f)
        dp20 = DisplayUtil.dip2px(this, 20f)
    }

    override fun initData() {
        super.initData()
        getAppLabel()
    }

    private fun getAppLabel() {
        val params = HashMap<String, String>()
        params["type"] = "0"
        getApiService()
            .getAppLabel(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<MutableList<Label>>() {
                override fun success(t: MutableList<Label>) {
                    updateTagView(t)
                    refresh_layout?.finishRefresh()
                    empty_view?.visibility = View.GONE
                }

                override fun error(msg: String?, code: Int) {
                    if (empty_view?.visibility == View.VISIBLE) {
                        empty_view?.setLoadFail()
                    }
                    refresh_layout?.finishRefresh(false)
                }
            })
    }

    private fun updateTagView(cateList: List<Label>?) {
        fl_tag?.removeAllViews()
        cateList?.forEach {
            val textView = QMUISpanTouchFixTextView(this)
            textView.textSize = 15f
            textView.setTextColor(textColor)
            textView.setBackgroundColor(tagBgColor)
            textView.radius = dp20
            textView.setPadding(dp12, dp4, dp12, dp4)
            textView.text = it.name
            textView.setOnClickListener { _ ->
                GameListActivity.start(this, "", it.id, it.name)
            }
            fl_tag?.addView(textView)
        }
    }
}