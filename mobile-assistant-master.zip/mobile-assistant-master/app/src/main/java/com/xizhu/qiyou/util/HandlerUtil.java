package com.xizhu.qiyou.util;


import android.os.Handler;
import android.os.Looper;

public class HandlerUtil {
    private static final Handler handler;

    static {
        handler = new Handler(Looper.getMainLooper());
    }

    public static Handler getHandler() {
        return handler;
    }
}
