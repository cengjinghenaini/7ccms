package com.xizhu.qiyou.http;

import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;

import com.google.gson.Gson;
import com.tencent.cos.xml.exception.CosXmlClientException;
import com.tencent.cos.xml.exception.CosXmlServiceException;
import com.tencent.cos.xml.model.CosXmlRequest;
import com.tencent.cos.xml.model.CosXmlResult;
import com.xizhu.qiyou.config.API;
import com.xizhu.qiyou.entity.Kf;
import com.xizhu.qiyou.entity.NULL;
import com.xizhu.qiyou.http.result.ResultCallback;
import com.xizhu.qiyou.http.result.ResultEntity;
import com.xizhu.qiyou.http.retrofit.RetrofitUtil;
import com.xizhu.qiyou.inter.CosPutResult;
import com.xizhu.qiyou.room.entity.TranslationConfig;
import com.xizhu.qiyou.ui.translation.entity.BaiduAuth;
import com.xizhu.qiyou.ui.translation.entity.BaiduImage;
import com.xizhu.qiyou.ui.translation.entity.TencentImg;
import com.xizhu.qiyou.ui.translation.entity.TencentImgErr;
import com.xizhu.qiyou.ui.translation.entity.TencentTrans;
import com.xizhu.qiyou.ui.translation.entity.TencentTransErr;
import com.xizhu.qiyou.ui.translation.http.TransApi;
import com.xizhu.qiyou.ui.translation.util.Base64Util;
import com.xizhu.qiyou.util.AppConfig;
import com.xizhu.qiyou.util.Cos;
import com.xizhu.qiyou.util.FileUtil;
import com.xizhu.qiyou.util.UserMgr;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.Response;

public class HttpUtil {
    private static final String TAG = "HttpUtil";
    private static final String CHARSET = "UTF-8";
    private static HttpUtil INSTANCE;

    private static final ThreadPoolExecutor poolExecutor = new ThreadPoolExecutor(4, 4, 5,
            TimeUnit.SECONDS, new LinkedBlockingDeque<>(1280));

    private HttpUtil() {
    }

    public static HttpUtil getInstance() {
        if (INSTANCE == null) {
            synchronized (HttpUtil.class) {
                if (INSTANCE == null) {
                    INSTANCE = new HttpUtil();
                }
            }
        }
        return INSTANCE;
    }


    private void enqueue(Request request, Callback callback) {
        HttpClient.getInstance().enqueue(request, callback);
    }

    private Response execute(Request request) throws IOException {
        return HttpClient.getInstance().execute(request);
    }


    private Request postRequest(String Path, Map<String, String> map) {
        return HttpX.post().url(API.DOMAIN + Path).addParams(map).createReq();
    }


    private Request fileRequest(File file, String uid) {
        return HttpX.file()
                .url(API.DOMAIN + API.FileUpload)
                .addFile(file)
                .addParams("is_android", "1")
                .addParams("uid", uid)
                .createReq();
    }

    private Request fileNoysRequest(File file, String uid) {
        return HttpX.file()
                .url(API.DOMAIN + API.FileUpload)
                .addFile(file)
                .addParams("is_android", "1")
                .addParams("noys", "1")
                .addParams("uid", uid)
                .createReq();
    }

    // 获取首页大图 1
    public void getBigPicture(String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getBigPicture, map), httpResult);
    }

    // 获取首页 热门游戏推荐2
    public void getHotGame(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getHotGame, map), httpResult);
    }

    // 获取首页 月份游戏推荐3
    public void getMonthRec(ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        enqueue(postRequest(API.getMonthRec, map), httpResult);
    }

    // 获取所有月份游戏推荐4
    public void getAllMonths(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getAllMonthRec, map), httpResult);
    }

    // 获取首页 用户分享游戏5
    public void getUserShare(String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getUserShare, map), httpResult);
    }

    // 获取首页 精选游戏单6
    public void getHomeSheet(String label_ids, String is_hot, String is_new, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("label_ids", label_ids);
        map.put("is_hot", is_hot);
        map.put("is_new", is_new);
        enqueue(postRequest(API.getChoiceGame, map), httpResult);
    }

    // 获取精选游戏单 标签7
    public void getSheetLabel(ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        enqueue(postRequest(API.getSheetLabel, map), httpResult);
    }

    // 获取游戏单详情8
    public void getSheetInfo(String uid, String sheet_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("sheet_id", sheet_id);
        enqueue(postRequest(API.getSheetInfo, map), httpResult);
    }

    // 获取游戏单 评论9
    //    uid	Y
    //    sheet_id	Y
    //    reply_id	N
    //    reply_uid	N
    //    content	Y
    //    phone_type	N
    //    score  Y
    public void sheetComment(String uid, String sheet_id, String reply_id, String reply_uid, String content, String phone_type, String score, String tail_id, String pics, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("sheet_id", sheet_id);
        map.put("reply_id", reply_id);
        map.put("reply_uid", reply_uid);
        map.put("content", content);
        map.put("phone_type", phone_type);
        map.put("score", score);
        map.put("tail_id", tail_id);
        map.put("pics", pics);
        enqueue(postRequest(API.sheetComment, map), httpResult);
    }

    // 获取游戏单评论 10
    //uid	Y
    //sheet_id	Y
    //page	N	1
    //pageSize	N
    public void getSheetComment(String uid, String sheet_id, String page, String pageSize, String order, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("sheet_id", sheet_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        map.put("order", order);
        enqueue(postRequest(API.getSheetComment, map), httpResult);
    }

    // 获取游戏单评论 11
    //uid	Y
    //comment_id	Y
    //page	N	1
    //pageSize	N	20
    public void getSheetCommentReply(String uid, String comment_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("comment_id", comment_id);
        map.put("page", page);
        map.put("pageSize", pageSize);

        enqueue(postRequest(API.getSheetCommentReply, map), httpResult);
    }

    // 获取游戏单评论 12
    //uid	Y
    //id
    public void deleteSheetComment(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.deleteSheetComment, map), httpResult);
    }


    // 获取首页 游戏推荐 13
    //page	N	1
    //pageSize	N	20
    public void getHomeGame(String page, String sheet_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("page", page); // Y
        map.put("sheet_id", sheet_id); // Y
        enqueue(postRequest(API.getHomeGame, map), httpResult);
    }

    // 获取搜索关键字 14
    public void getSearchKeyword(ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        enqueue(postRequest(API.getSearchKeyword, map), httpResult);
    }

    public void getSearchPointKeyword(ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        enqueue(postRequest(API.getSearchPointKeyword, map), httpResult);
    }

    public void getConfigPlayTime(ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        enqueue(postRequest(API.getConfigPlayTime, map), httpResult);
    }

    public void flagFinishPlayTime(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.flagFinishPlayTime, map), httpResult);
    }

    // 获取首页搜索结果  分为用户 游戏 软件15
    //uid	N
    //keyword	Y
    public void getSearchResult(String type, String uid, String keyword, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        map.put("uid", uid);
        map.put("keyword", keyword); // Y
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getSearchResult, map), httpResult);
    }


    // 关注 16
    //uid	Y
    //fuid	Y		关注对象id，根据type值变化
    //type	Y		0.用户，1.版块
    public void attention(String uid, String fuid, String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("fuid", fuid);
        map.put("type", type);
        enqueue(postRequest(API.attention, map), httpResult);
    }

    // 收藏 17
    //uid	Y
    //fuid	Y		对象id，根据type值变化
    //type	Y		0.游戏单，1.铃声，2.应用，3.帖子
    public void collect(String uid, String fuid, String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("fuid", fuid);
        map.put("type", type);
        enqueue(postRequest(API.collect, map), httpResult);
    }

    // 赞 18
    //uid	Y
    //fuid	Y		对象id，根据type值变化
    //type	Y		0.游戏单，1.单款游戏推荐，2.帖子，3.专题评论，4.应用评论，5.单款游戏推荐评论，6.游戏单评论，7.帖子评论
    public void zan(String uid, String fuid, String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("fuid", fuid);
        map.put("type", type);
        enqueue(postRequest(API.zan, map), httpResult);
    }

    // 消息未读数量 19
    //uid	Y
    public void getNoReadCount(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getNoReadCount, map), httpResult);
    }

    // 获取消息中心 用户消息20
    //uid	Y
    //page	N	1
    //pageSize	N	20
    public void getUserMessage(String uid, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid); // Y
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getUserMessage, map), httpResult);
    }

    // 获取消息中心 系统消息21
    //page	N	1
    //pageSize	N	20
    public void getUserNotice(String uid, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getUserNotice, map), httpResult);
    }

    // 我的游戏 是否更新 22
    //names	Y		游戏名称，多个逗号隔开
    //versions	Y		和游戏名称对应的版本号，多个逗号隔开
    public void gameIsUpdate(String pkgs, String versions, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("pagecks", pkgs);
        map.put("versions", versions);
        enqueue(postRequest(API.gameIsUpdate, map), httpResult);
    }

    // 我的游戏 预约游戏 23
    // uid	Y
    public void gameReserve(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.gameReserve, map), httpResult);
    }

    // 应用分类 24
    // type	Y		0.游戏，1.软件(资源工具)，2.模拟器
    public void getAppCate(String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        enqueue(postRequest(API.getAppCate, map), httpResult);
    }

    // 应用标签 25
    //type	Y		0.应用，1.游戏单
    //app_type	Y		0.游戏，1.软件
    public void getAppLabel(String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        enqueue(postRequest(API.getAppLabel, map), httpResult);
    }


    // 获取游戏 游戏列表26
    //cate_id	N		分类id
    //label_id	N		标签id
    //page	N	1
    //pageSize	N	202020-12-01 11:39:56.402 25675-27881/com.xizhu.qiyou E/HttpUtil: successful: {"data":{},"state":{"code":1,"msg":"\u8bf7\u5148\u767b\u5f55\u6216\u6ce8\u518c","debugMsg":"\u7528\u6237uid\u4e0d\u5b58\u5728\u6216uid\u4e3a\u7a7a","url":"Api\/Home\/getUserNotice"}}
    public void getGame(String uid, String cate_id, String label_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("cate_id", cate_id);
        map.put("label_id", label_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getGame, map), httpResult);
    }

    // 专题 27
    // type	 Y
    public void getTopic(String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        enqueue(postRequest(API.getTopic, map), httpResult);
    }


    // 专题详情 28
    // id	Y
    public void getTopicInfo(String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("id", id);
        enqueue(postRequest(API.getTopicInfo, map), httpResult);
    }

    // 获取专题评论 29
    //uid
    //id	Y
    //page	N	1
    //pageSize	N	20
    public void getTopicComment(String uid, String id, String page, String pageSize, String order, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        map.put("order", order);
        enqueue(postRequest(API.getTopicComment, map), httpResult);
    }

    // 获取专题评论回复 30
    //comment_id	Y
    //page	N	1
    //pageSize	N	20
    public void getTopicCommentReply(String uid, String comment_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("comment_id", comment_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getTopicCommentReply, map), httpResult);
    }

    // 删除专题评论 31
    // id	Y
    public void deleteTopicComment(String uid, String comment_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("comment_id", comment_id);
        enqueue(postRequest(API.deleteTopicComment, map), httpResult);
    }

    // 删除专题评论 32
    //topic_id	Y
    //reply_id	N
    //reply_uid	N
    //phone_type	N
    //content	Y
    public void commentTopic(String uid, String topic_id, String reply_id, String reply_uid, String phone_type, String content, String tail_id, String pics, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("topic_id", topic_id);
        map.put("reply_id", reply_id);
        map.put("reply_uid", reply_uid);
        map.put("phone_type", phone_type);
        map.put("content", content);
        map.put("tail_id", tail_id);
        map.put("pics", pics);
        enqueue(postRequest(API.commentTopic, map), httpResult);
    }


    // 获取游戏 模拟器列表33
    //uid	Y
    //cate_id	N
    //page	N	1
    //pageSize	N	20
    public void getMoNiQi(String uid, String cate_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("cate_id", cate_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getMoNiQi, map), httpResult);
    }

    // 资源-工具 34
    //uid	Y
    //type	Y		0.游戏，1.软件(资源工具)，2.模拟器
    //cate_id1	Y		分类1，对应页面左右滑动部分
    //cate_id2	Y		分类2，对应页面下面部分
    public void ziyuanGongju(ResultCallback<?> httpResult, String... strings) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", "");
        map.put("type", "");
        map.put("cate_id1", "");
        map.put("cate_id2", "");
        enqueue(postRequest(API.ziyuanGongju, map), httpResult);
    }

    // 分类应用 35
    //uid	Y
    //type	Y		0.游戏，1.软件(资源工具)，2.模拟器
    //cate_id	Y
    public void getCateApp(String uid, String type, String cate_id, String page, String page_size, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", type);
        map.put("cate_id", cate_id);
        map.put("page", page);
        map.put("page_size", page_size);
        enqueue(postRequest(API.getCateApp, map), httpResult);
    }


    // 最近更新应用 36
    //uid	Y
    //type	Y		0.游戏，1.软件(资源工具)，2.模拟器
    public void getNewApp(String uid, String type, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", type);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getNewApp, map), httpResult);
    }

    // 铃声分类 37
    // type	Y		0.来电，1.短信，2.闹钟
    public void getSoundCate(String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        enqueue(postRequest(API.getSoundCate, map), httpResult);
    }

    // 铃声 38
    //cate_id	N
    //keyword	N
    //page	N	1
    //pageSize	N	20
    public void getSound(String cate_id, String keyword, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("cate_id", cate_id);
        map.put("keyword", keyword);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getSound, map), httpResult);
    }

    // 铃声下载 39
    //uid	Y
    //id	Y
    public void downloadSound(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.downloadSound, map), httpResult);
    }

    // 铃声下载记录 40
    //uid	Y
    //page	Y	1
    //pageSize	Y	20
    public void downSoundRecord(String uid, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.downSoundRecord, map), httpResult);
    }

    // 应用下载 41
    //uid	Y
    //id	Y
    public void downloadApp(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.downloadApp, map), httpResult);
    }


    // 应用下载记录 42
    //uid	Y
    //page	N	1
    //pageSize	N	20
    public void downAppRecord(String uid, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.downAppRecord, map), httpResult);
    }

    // 许愿瓶 43
    //uid	Y
    //content	Y
    //pics	Y		图片地址，多个逗号隔开
    //type	Y		0.求电影，1.求动漫，2.求游戏
    public void xuYuan(String uid, String content, String pics, String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("content", content);
        map.put("pics", pics);
        map.put("type", type);
        enqueue(postRequest(API.xuYuan, map), httpResult);
    }

    // 7友分享 44
    //uid	Y
    //order_type	Y		0.推荐，1.最新，2.排行榜
    //type	Y		0.全部，1.游戏，2.软件
    public void getShareRec(String uid, String order_type, String type, String page, String pageCount, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("order_type", order_type);
        map.put("type", type);
        map.put("page", page);
        map.put("pageSize", pageCount);
        enqueue(postRequest(API.getShareRec, map), httpResult);
    }

    // 用户添加资源 45
    //uid	Y		用户id
    //icon	Y		图标地址
    //app_path	Y		应用上传后的地址
    //cate_id	Y		分类id
    //down_url	N		下载地址
    //name	Y		名称
    //introduction	Y		简介
    //desc	Y		介绍
    //pics	Y		截图地址，多个逗号隔开
    //version	Y		版本号
    //size	Y		资源大小
    public void addUserApp(String uid, String icon, String app_path, String cate_id
            , String down_url, String name, String introduction
            , String desc, String pics, String version, String size, String rec_reason,
                           String pkage,
                           ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("icon", icon);
        map.put("app_path", app_path);
        map.put("cate_id", cate_id);
        map.put("down_url", down_url);
        map.put("name", name);
        map.put("introduction", introduction);
        map.put("desc", desc);
        map.put("pics", pics);
        map.put("version", version);
        map.put("size", size);
        map.put("rec_reason", rec_reason);
        map.put("package", pkage);
        enqueue(postRequest(API.addUserApp, map), httpResult);
    }

    // 应用详情 46
    //uid	Y
    //id	Y
    public void appInfo(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.appInfo, map), httpResult);
    }


    // 应用打赏积分 47
    //uid	Y
    //app_id	Y
    //integral	Y
    public void rewardAppIntegral(String uid, String app_id, String integral, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("app_id", app_id);
        map.put("integral", integral);
        enqueue(postRequest(API.rewardAppIntegral, map), httpResult);
    }

    // 获取应用评论 48
    //uid	Y
    //app_id	Y
    //page	N	1
    //pageSize	N	20
    public void getAppComment(String uid, String app_id, String page, String pageSize, String order_type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("app_id", app_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        map.put("order_type", order_type);
        enqueue(postRequest(API.getAppComment, map), httpResult);
    }


    // 获取应用评论回复 49
    //uid	Y
    //comment_id	Y
    public void getAppCommentReply(String uid, String comment_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("comment_id", comment_id);
        enqueue(postRequest(API.getAppCommentReply, map), httpResult);
    }

    // 删除应用评论 50
    //uid	Y
    //id	Y
    public void deleteAppComment(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.deleteAppComment, map), httpResult);
    }

    // 评论应用或回复评论 51
    //uid	Y
    //app_id	Y
    //reply_id	N
    //reply_uid	N
    //phone_type	N
    //content	Y
    //score	Y
    public void commentApp(String uid, String app_id, String reply_id, String reply_uid, String phone_type, String content, String score, String tail_id, String pics, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("app_id", app_id);
        map.put("reply_id", reply_id);
        map.put("reply_uid", reply_uid);
        map.put("phone_type", phone_type);
        map.put("content", content);
        map.put("score", score);
        map.put("tail_id", tail_id);
        map.put("pics", pics);
        enqueue(postRequest(API.commentApp, map), httpResult);
    }

    // 力荐墙-游戏单 52
    //keyword	N
    //label_ids	N		标签id，多个逗号隔开
    //is_new	N		最新传1
    public void lijianQiangSheet(String keyword, String label_ids, String is_new, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("keyword", keyword);
        map.put("label_ids", label_ids);
        map.put("is_new", is_new);
        enqueue(postRequest(API.lijianQiangSheet, map), httpResult);
    }

    // 获取浏览记录 53
    //uid	Y
    //type	Y		0.应用，1.帖子
    //app_type	N		0.游戏，1.软件，应用时要传
    public void getLookRecord(String uid, String type, String app_type, int pageNo, int pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", type);
        map.put("app_type", app_type);
        map.put("page", pageNo + "");
        map.put("pageSize", pageSize + "");
        enqueue(postRequest(API.getLookRecord, map), httpResult);
    }

    public void getLookRecord(String uid, String type, String app_type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", type);
        map.put("app_type", app_type);
        enqueue(postRequest(API.getLookRecord, map), httpResult);
    }

    // 收藏记录 54
    //uid	Y
    //type	Y		0.游戏单，1.铃声，2.应用，3.帖子
    public void getCollectRecord(String uid, String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", type);
        enqueue(postRequest(API.getCollectRecord, map), httpResult);
    }

    // 搜索应用  55
    //keyword	N
    //type	N		0.全部，1.游戏，2.软件
    //page	N	1
    //pageSize	N	20
    public void searchApp(String keyword, String type, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("keyword", keyword);
        map.put("type", type);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.searchApp, map), httpResult);
    }

    // 用户推荐游戏-保存  56
    //uid	Y
    //id	N		草稿id，编辑时必传
    //app_id	Y
    //phone_type	N		手机型号
    //rec_reason	Y		推荐理由
    //score	Y		推荐分数
    //is_release	Y		是否直接发表
    public void userRecApp(String uid, String id, String app_id, String phone_type, String rec_reason, String score, String is_release, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        map.put("app_id", app_id);
        map.put("phone_type", phone_type);
        map.put("rec_reason", rec_reason);
        map.put("score", score);
        map.put("is_release", is_release);
        enqueue(postRequest(API.userRecApp, map), httpResult);
    }

    // 用户推荐游戏-发表  57
    //uid	Y
    //id	Y		草稿id
    public void userRecAppRelease(ResultCallback<?> httpResult, String... strings) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", "");
        map.put("id", "");
        enqueue(postRequest(API.userRecAppRelease, map), httpResult);
    }


    // 用户推荐游戏-草稿箱  58
    //uid	Y
    //page	N	1
    //pageSize	N	20
    public void userRecAppCaogao(String uid, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.userRecAppCaogao, map), httpResult);
    }

    // 用户推荐游戏-详情  59
    //uid	Y
    //id	Y
    public void userRecAppInfo(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.userRecAppInfo, map), httpResult);
    }

    // 用户推荐游戏-详情-获取评论  60
    //uid	Y
    //rec_id	Y
    //page	N	1
    //pageSize	N	20
    public void getUserRecAppCommnet(String uid, String rec_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("rec_id", rec_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getUserRecAppCommnet, map), httpResult);
    }

    // 用户推荐游戏-详情-获取评论  61
    //uid	Y
    //rec_id	Y
    //reply_id	N
    //reply_uid	N
    //phone_type	N
    //content	Y
    public void userRecAppCommnet(String uid, String rec_id, String reply_id, String reply_uid, String phone_type, String content, String tail_id, String pics, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("rec_id", rec_id);
        map.put("reply_id", reply_id);
        map.put("reply_uid", reply_uid);
        map.put("phone_type", phone_type);
        map.put("content", content);
        map.put("tail_id", tail_id);
        map.put("pics", pics);
        enqueue(postRequest(API.userRecAppCommnet, map), httpResult);
    }

    // 用户推荐游戏-详情-获取评论回复  62
    //uid	Y
    //rec_id	Y
    //reply_id	N
    //reply_uid	N
    //phone_type	N
    //content	Y
    public void getRecCommentReply(String uid, String comment_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("comment_id", comment_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getRecCommentReply, map), httpResult);
    }


    // 用户推荐游戏-详情-删除评论  63
    //uid	Y
    //id	Y
    public void deleteRecComment(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.deleteRecComment, map), httpResult);
    }


    // 用户推荐游戏-草稿箱删除  64
    //uid	Y
    //id	Y
    public void userRecAppDelete(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.userRecAppDelete, map), httpResult);
    }

    // 力荐墙-单款游戏  65
    //uid	Y
    //page	N	1
    //pageSize	N	20
    public void lijianQiangGame(String uid, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.lijianQiangGame, map), httpResult);
    }

    // 用力荐墙-分享好游戏用户  66
    //uid	Y
    public void lijianQiangUser(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.lijianQiangUser, map), httpResult);
    }

    // 标签应用  67
    //uid	Y
    //label_id	Y
    //page	N
    //pageSize	N
    public void getLabelApp(ResultCallback<?> httpResult, String... strings) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", "");
        enqueue(postRequest(API.getLabelApp, map), httpResult);
    }

    // 应用攻略  68
    //uid	Y
    //app_id	Y
    //page	N
    //pageSize	N
    public void appRaiders(String uid, String app_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("app_id", app_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.appRaiders, map), httpResult);
    }

    // 应用攻略  69
    //uid	Y
    //app_id	Y
    //page	N
    //pageSize	N
    public void appRaidersInfo(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);

        enqueue(postRequest(API.appRaidersInfo, map), httpResult);
    }

    // 应用评论星数量  70
    //uid	Y
    public void getAppCommentScore(String app_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("app_id", app_id);
        enqueue(postRequest(API.getAppCommentScore, map), httpResult);
    }


    // 榜单  73
    //uid	Y
    //type	Y		0.飙升榜，1.下载榜，2.评分榜，3.玩家榜，4.总榜
    //keyword	N
    //page	N
    //pageSize	N
    public void getLeaderboard(String uid, String type, String keyword, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", type);
        map.put("keyword", keyword);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getLeaderboard, map), httpResult);
    }


    // 榜单  74
    //keyword	N
    //page	N
    //pageSize	N
    public void gambitBang(String keyword, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("keyword", keyword);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.gambitBang, map), httpResult);
    }

    // 榜单  75
    //type	N		0.全部，1.最新，2.最热
    //page	N
    //pageSize
    public void gambitBangDetail(String gambit_id, String type, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("gambit_id", gambit_id);
        map.put("type", type);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.gambitBangDetail, map), httpResult);
    }


    // 举报类型  76

    public void getReportType(ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        enqueue(postRequest(API.getReportType, map), httpResult);
    }

    // 举报  77
    //uid	Y
    //type	Y		0.应用，1.帖子，2.用户
    //type_id	N		举报类型，应用时必传
    //value_id	Y		相关id，比如用户就传用户id，帖子传帖子id，应用传应用id
    //remark	N		补充说明
    public void report(String uid, String type, String type_id, String value_id, String remark, String comment_type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", type);
        map.put("type_id", type_id);
        map.put("value_id", value_id);
        map.put("remark", remark);
        map.put("comment_type", comment_type);
        enqueue(postRequest(API.report, map), httpResult);
    }


    // 举报类型  78

    public void play_sound(String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("id", id);
        enqueue(postRequest(API.play_sound, map), httpResult);
    }


    // 举报  78
    //type	Y		0.飙升榜，1.下载榜，2.评分榜，3.玩家榜，4.总榜
    public void leaderboardDesc(String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        enqueue(postRequest(API.leaderboardDesc, map), httpResult);
    }


    public void reportComment(String uid, String value_id, String comment_type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", "3");
        map.put("value_id", value_id);
        map.put("comment_type", comment_type);
        enqueue(postRequest(API.report, map), httpResult);
    }









    /*=================================================================================*/
    /*=================================================================================*/
    /*=================================================================================*/

    // 获取个性装扮分类  1
    //type	Y		0.背景空间，1.个性主题
    public void getCate(String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        enqueue(postRequest(API.getCate, map), httpResult);
    }

    // 获取个性装扮  2
    //cate_id	Y		分类id
    //type	Y		0.背景空间，1.个性主题
    //page	N
    //pageSize	N
    public void getDressUp(String type, String cate_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        map.put("cate_id", cate_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getDressUp, map), httpResult);
    }


    // 个性装扮详情 3
    //uid	Y
    //id	Y
    public void getDressUpInfo(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.getDressUpInfo, map), httpResult);
    }


    // 兑换个性装扮  4
    //uid	Y
    //id	Y
    public void buyDressUp(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.buyDressUp, map), httpResult);
    }

    // 获取用户积分和贡献值  5
    //uid	Y
    public void getUserIntegral(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getUserIntegral, map), httpResult);
    }

    public void addUserIntegral(String uid, String card_pwd, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("card_pwd", card_pwd);
        enqueue(postRequest(API.addUserIntegral, map), httpResult);
    }


    // 积分详情  5
    //uid	Y
    public void getGrades(String uid, int gradeType, int pageNo, int pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", "" + gradeType);
        map.put("page", "" + pageNo);
        map.put("pageSize", "" + pageSize);
        enqueue(postRequest(API.getGrades, map), httpResult);
    }

    // 兑换个性装扮  6
    //page	N
    //pageSize	N
    public void getIntegralGoods(String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getIntegralGoods, map), httpResult);
    }

    // 积分物品详情  7
    //uid	Y
    //id	Y
    public void integralGoodsInfo(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.integralGoodsInfo, map), httpResult);
    }


    // 兑换积分物品  8
    //uid	Y
    //id	Y
    //name	Y		收货人
    //phone	Y		电话
    //address	Y		收货地址
    //remark	N		备注
    public void convertGoods(String uid, String id, String name, String phone, String address, String remark, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        map.put("name", name);
        map.put("phone", phone);
        map.put("address", address);
        map.put("remark", remark);
        enqueue(postRequest(API.convertGoods, map), httpResult);
    }

    // 下载赚积分  9
    //page	N
    //pageSize	N
    public void downGetIntegral(String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.downGetIntegral, map), httpResult);
    }

    // 任务列表  10
    //uid	Y
    public void getTask(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getTask, map), httpResult);
    }

    // 勋章列表  11
    //page	N
    //pageSize	N
    public void getMedal(String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getMedal, map), httpResult);
    }

    // 勋章详情  12
    //uid	Y
    //id	Y
    public void getMedalInfo(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.getMedalInfo, map), httpResult);
    }

    // 兑换勋章  13
    //uid	Y
    //id	Y
    public void convertMedal(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.convertMedal, map), httpResult);
    }

    // 活动分类  14
    public void getActiveCate(ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        enqueue(postRequest(API.getActiveCate, map), httpResult);
    }

    // 任务列表  15
    //cate_id	Y
    //page	N
    //pageSize	N
    public void getActiveList(String cate_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("cate_id", cate_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getActiveList, map), httpResult);
    }


    // 任务列表  16
    //uid	N
    //id	N		主题id
    //page	N
    //pageSize	N
    public void getThemLike(String uid, String id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getThemLike, map), httpResult);
    }
    /*=================================================================================*/
    /*=================================================================================*/
    /*=================================================================================*/

    // 协议内容  1
    //type	Y		0.服务条款，1.隐私协议，2.分享协议，3.达人堂说明，4.邀请须知，5.评价须知，6.推荐须知，7.等级经验说明，8.客服QQ
    public void pageContent(String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        enqueue(postRequest(API.pageContent, map), httpResult);
    }

    // 上传文件  2
    //file	Y		文件
    public void uploadFile(File file, String uid, ResultCallback<?> httpResult) {
        enqueue(fileRequest(file, uid), httpResult);
    }

    // 客服  3
    public Observable<ResultEntity<Kf>> kf() {
        HashMap<String, String> map = new HashMap<>();
        return RetrofitUtil.instance().server().kf(map)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    // 客服  3
    public void version(ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        enqueue(postRequest(API.version, map), httpResult);
    }
    /*=================================================================================*/
    /*=================================================================================*/
    /*=================================================================================*/

    // 获取验证码  1
    //phone	Y
    //type	Y		0.登录，1.绑定手机号，2.验证手机号
    public void getCode(String phone, int type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("phone", phone);
        map.put("type", String.valueOf(type));
        enqueue(postRequest(API.getCode, map), httpResult);
    }

    // 获取邮箱验证码  2
    //email	Y
    public void getEmailCode(String email, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("email", email);
        enqueue(postRequest(API.getEmailCode, map), httpResult);
    }


    // 第三方登录-检查是否已注册  3  isRegister = 1是已经注册，并返回用户信息；isRegister = 0未注册
    //type	Y		0.微信，1.QQ
    //openid	Y
    //lng	N		经度
    //lat	N		纬度
    public void otherLoginCheck(String type, String openid, String lng, String lat, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        map.put("openid", openid);
        map.put("lng", lng);
        map.put("lat", lat);
        enqueue(postRequest(API.otherLoginCheck, map), httpResult);
    }


    // 第三方注册  4
    //type	Y		0.微信，1.QQ
    //openid	Y
    //phone	Y
    //lng	N
    //lat	N
    public void otherLogin(String type, String openid, String phone, String code, String lng, String lat, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        map.put("openid", openid);
        map.put("phone", phone);
        map.put("code", code);
        map.put("lng", lng);
        map.put("lat", lat);
        enqueue(postRequest(API.otherLogin, map), httpResult);
    }


    // 手机号登录  5
    //phone	Y
    //code	Y		手机验证码
    public void phoneLogin(String phone, String code, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("phone", phone);
        map.put("code", code);
        enqueue(postRequest(API.phoneLogin, map), httpResult);
    }

    //一键登录
    public void phoneOnceLogin(String token, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("token", token);
        enqueue(postRequest(API.phoneOnceLogin, map), httpResult);
    }

    // 密码登录  5
    //phone	Y
    //code	Y		密码
    public void pwdLogin(String phone, String pwd, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("phone", phone);
        map.put("pwd", pwd);
        enqueue(postRequest(API.pwdLogin, map), httpResult);
    }


    // 密码注册  5
    //phone	Y
    //code	Y		密码
    public void pwdRegister(String phone, String pwd, String secret, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("phone", phone);
        map.put("pwd", pwd);
        map.put("secret", secret);
        enqueue(postRequest(API.pwdRegister, map), httpResult);
    }

    // 密码登录  5
    //phone	Y
    //code	Y		密码
    public void forgetPassword(String uid, String phone, String code, String pwd, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("phone", phone);
        map.put("code", code);
        map.put("newpwd", pwd);
        enqueue(postRequest(API.forgetPassword, map), httpResult);
    }


    // 邮箱登录  6
    //email	Y
    //code	Y
    public void emailLogin(ResultCallback<?> httpResult, String... strings) {
        HashMap<String, String> map = new HashMap<>();
        map.put("email", "");
        map.put("code", "");
        enqueue(postRequest(API.emailLogin, map), httpResult);
    }


    // 修改用户信息  7
    //uid	Y
    //head	N
    //name	N
    //sign	N
    //sex	N
    //birthday	N		生日时间戳
    //email	N
    //password	N		新密码
    public void updatePro(String uid, String head, String name, String sign, String sex, String birthday, String email, String password, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("head", head);
        map.put("name", name);
        map.put("sign", sign);
        map.put("sex", sex);
        map.put("birthday", birthday);
        map.put("email", email);
        map.put("password", password);

        enqueue(postRequest(API.updatePro, map), httpResult);
    }

    public void setPassword(String uid, String oldpwd, String newpwd, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("oldpwd", oldpwd);
        map.put("newpwd", newpwd);
        enqueue(postRequest(API.setPassword, map), httpResult);
    }


    // 获取邮箱验证码  8
    //uid	Y
    public void getUserTotalCount(String uid, ResultCallback<?> httpResult, String... strings) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getUserTotalCount, map), httpResult);
    }


    // 获取邮箱验证码  9
    //uid	Y
    //fuid	Y		查看自己的时候和uid相同
    public void getUserHome(String uid, String fuid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("fuid", fuid);
        enqueue(postRequest(API.getUserHome, map), httpResult);
    }


    // 用户勋章  10
    //uid	Y
    public void getUserMedal(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getUserMedal, map), httpResult);
    }


    // 显示或隐藏勋章  11
    //uid	Y
    //id	Y
    public void settingMedal(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.settingMedal, map), httpResult);
    }


    // 我的照片  12
    //uid	Y
    //page	N
    //pageSize	N
    public void getUserPhoto(String uid, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getUserPhoto, map), httpResult);
    }


    // 获取邮箱验证码  13
    //uid	Y
    //pic	Y
    public void addUserPhoto(String uid, String pic, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("pic", pic);
        enqueue(postRequest(API.addUserPhoto, map), httpResult);
    }


    // 删除照片  14
    //uid	Y
    //id	Y
    public void delUserPhoto(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.delUserPhoto, map), httpResult);
    }


    // 获取邮箱验证码  15
    //uid	Y
    //type	Y
    //page	N
    //pageSize	N
    public void getUserApp(String uid, String type, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", type);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getUserApp, map), httpResult);
    }


    // 我的合集  16
    //uid	Y
    //page	N
    //pageSize	N
    public void getUserSheet(String uid, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getUserSheet, map), httpResult);
    }


    // 删除合集应用  17
    //uid	Y
    //sheet_id	Y
    //app_id	Y
    public void delUserSheetApp(String uid, String sheet_id, String app_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("sheet_id", sheet_id);
        map.put("app_id", app_id);
        enqueue(postRequest(API.delUserSheetApp, map), httpResult);
    }


    // 添加合集应用  18
    //uid	Y
    //sheet_id	Y		等于0时为创建新合集
    //title	Y		名称
    //label_ids	Y		标签id，多个逗号隔开
    //desc	Y		介绍
    //pic	Y		封面图
    //app_ids	Y		应用id，多个逗号隔开
    public Observable<ResultEntity<NULL>> addUserSheetApp(String uid, String sheet_id, String title, String label_ids, String desc, String pic, String app_ids) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("sheet_id", sheet_id);
        map.put("title", title);
        map.put("label_ids", label_ids);
        map.put("desc", desc);
        map.put("pic", pic);
        map.put("app_ids", app_ids);
//        enqueue(postRequest(API.addUserSheetApp, map), httpResult);

        return RetrofitUtil.instance().server()
                .addUserSheetApp(map)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }


    // 获取邮箱验证码  19
    //uid	Y
    //page	N
    //pageSize	N
    public void attentionList(String uid, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.attentionList, map), httpResult);
    }


    // 获取粉丝列表  20
    //uid	Y
    //page	N
    //pageSize	N
    public void fansList(String uid, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.fansList, map), httpResult);
    }

    // 我的帖子  21
    //uid	Y
    //page	N
    //pageSize	N
    public void getUserPosts(String uid, String page, String pageSize, String fuid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("page", page);
        map.put("pageSize", pageSize);
        map.put("fuid", fuid);
        enqueue(postRequest(API.getUserPosts, map), httpResult);
    }

    // 删除帖子  22
    //uid	Y
    //id	Y
    public void delUserPosts(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.delUserPosts, map), httpResult);
    }

    // 获取用户邀请信息  23
    //uid	Y
    public void getInviteInfo(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getInviteInfo, map), httpResult);
    }

    // 删除帖子  24
    //uid	Y
    //invite_code	Y
    public void setInviteCode(String uid, String invite_code, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("invite_code", invite_code);
        enqueue(postRequest(API.setInviteCode, map), httpResult);
    }

    // 问题反馈  25
    //uid	Y
    //content	Y		反馈内容
    //pics	N		图片，多个逗号隔开
    public void setQuestion(String uid, String content, String pics, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("content", content);
        map.put("pics", pics);
        enqueue(postRequest(API.setQuestion, map), httpResult);
    }

    // 获取开通会员页面信息  26
    //uid	Y
    public void getMemberData(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getMemberData, map), httpResult);
    }

    // 开通会员  27
    //uid	Y
    //month	Y		购买几个月
    //pay_type	Y		0.支付宝，1.微信
    public void openMember(String uid, String month, String pay_type, String openType, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("month", month);
        map.put("pay_type", pay_type);
        map.put("open_type", openType); //0.交费，1.积分
        enqueue(postRequest(API.openMember, map), httpResult);
    }

    // 绑定微信qq 28
    //uid	Y
    //type	Y		0.微信，1.qq
    //openid	Y
    public void bindWxQq(String uid, String type, String openid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("type", type);
        map.put("openid", openid);
        enqueue(postRequest(API.bindWxQq, map), httpResult);
    }

    // 验证手机号  29
    //uid	Y
    //code	Y
    //phone	Y
    public void checkPhone(String uid, String code, String phone, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("code", code);
        map.put("phone", phone);
        enqueue(postRequest(API.checkPhone, map), httpResult);
    }

    // 换绑手机号  30
    //uid	Y
    //code	Y
    //phone	Y
    public void updatePhone(String uid, String code, String phone, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("code", code);
        map.put("phone", phone);
        enqueue(postRequest(API.updatePhone, map), httpResult);
    }

    // 换绑手机号  31
    //uid	Y
    //id	Y		资源id
    public void deleteUserApp(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.deleteUserApp, map), httpResult);
    }


    // 换绑手机号  31
    //uid	Y
    //id	Y		资源id
    public void delUserLook(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.delUserLook, map), httpResult);
    }


    // 换绑手机号  31
    //uid	Y
    //id	Y		资源id
    public void delUserMessage(String type, String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.delUserMessage, map), httpResult);
    }


    //社区首页1
    // uid	Y
    public void homeData(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.homeData, map), httpResult);
    }

    // 2
    //uid	Y
    //forum_id	N		版块id，社区首页不传
    //type	N	0	0.关注用户，1.推荐
    //order_type	N	0	0.发布时间，1.回复时间
    //cate_id	Y
    //page	N
    //pageSize	N
    //is_gonggao	N	0	是否公告，1.是
    //keyword
    public void getPostsList(String uid, String forum_id, String type, String order_type, String cate_id, String page, String pageSize, String is_gonggao, String keyword, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("forum_id", forum_id);
        map.put("type", type);
        map.put("order_type", order_type);
        map.put("cate_id", cate_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        map.put("is_gonggao", is_gonggao);
        map.put("keyword", keyword);
        enqueue(postRequest(API.getPostsList, map), httpResult);
    }

    //版块分类 3
    public void getForumCate(ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        enqueue(postRequest(API.getForumCate, map), httpResult);
    }

    //版块列表 4
    //uid	Y
    //cate_id	Y
    //page	N
    //pageSize	N
    public void getForumList(String uid, String cate_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("cate_id", cate_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getForumList, map), httpResult);
    }

    //版块签到 6
    //uid	Y
    //forum_id	Y
    public void forumSignIn(String uid, String forum_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("forum_id", forum_id);
        enqueue(postRequest(API.forumSignIn, map), httpResult);
    }

    //版块签到 6
    //uid	Y
    //forum_id	Y
    public void forumOneKeySignIn(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.forumOneKeySignIn, map), httpResult);
    }

    //帖子分类7
    //forum_id	Y		版块id
    public void getPostsCate(String uid, String forum_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("forum_id", forum_id);
        enqueue(postRequest(API.getPostsCate, map), httpResult);
    }


    //版块详情 8
    //uid	Y
    //forum_id	Y
    public void forumDetail(String uid, String forum_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("forum_id", forum_id);
        enqueue(postRequest(API.forumDetail, map), httpResult);
    }

    // 帖子详情 9
    //uid	Y
    //posts_id	Y		帖子id
    //integral	Y
    public void postsDetail(String uid, String posts_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("posts_id", posts_id);
        enqueue(postRequest(API.postsDetail, map), httpResult);
    }

    // 支付查看帖子详情 9
    //uid	Y
    //posts_id	Y		帖子id
    //integral	Y
    public void postPay(String uid, String posts_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("posts_id", posts_id);
        enqueue(postRequest(API.postPay, map), httpResult);
    }

    //打赏帖子
    // 10
    public void rewardPosts(String uid, String posts_id, String integral, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("posts_id", posts_id);
        map.put("integral", integral);
        enqueue(postRequest(API.rewardPosts, map), httpResult);
    }

    // 11
    //打赏记录
    //uid	Y
    //posts_id	Y
    //page	N
    //pageSize	N
    public void getRewardRecord(String uid, String posts_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("posts_id", posts_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getRewardRecord, map), httpResult);
    }

    //获取评论 12
    //uid	Y
    //posts_id	Y
    //order_type	Y		0.正序，1.倒序，2.只看楼主
    //page	N
    //pageSize	Y
    public void getPostsComment(String uid, String posts_id, String order_type, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("posts_id", posts_id);
        map.put("order_type", order_type);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getPostsComment, map), httpResult);
    }

    //获取评论 13
    //uid	Y
    //comment_id	Y
    //page	N
    //pageSize	N
    public void getPostsCommentReply(String uid, String comment_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("comment_id", comment_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getPostsCommentReply, map), httpResult);
    }

    //删除帖子评论 14
    //uid	Y
    //id	Y
    public void deletePostsComment(String uid, String comment_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", comment_id);
        enqueue(postRequest(API.deletePostsComment, map), httpResult);
    }

    // 评论帖子 15
    //uid	Y
    //posts_id	Y
    //reply_id	Y
    //reply_uid	Y
    //phone_type	Y
    //content	Y
    //is_reward_rem	Y	0	是否悬赏提醒，1.提醒
    //tail_id	N		尾巴id
    public void commentPosts(String uid, String posts_id, String reply_id, String reply_uid, String phone_type, String content, String is_reward_rem, String tail_id, String pics, String atuids, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("posts_id", posts_id);
        map.put("reply_id", reply_id);
        map.put("reply_uid", reply_uid);
        map.put("phone_type", phone_type);
        map.put("content", content);
        map.put("is_reward_rem", is_reward_rem);
        map.put("tail_id", tail_id);
        map.put("pics", pics);
        map.put("atuids", atuids);
        enqueue(postRequest(API.commentPosts, map), httpResult);
    }


    //版块介绍 16
    //uid	Y
    //forum_id	Y
    public void getForumDesc(String uid, String forum_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("forum_id", forum_id);
        enqueue(postRequest(API.getForumDesc, map), httpResult);
    }

    //签到榜单17
    //uid	Y
    //forum_id	Y
    //page	N
    //pageSize	N
    public void signPaihang(String uid, String forum_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("forum_id", forum_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.signPaihang, map), httpResult);
    }

    // 收获榜单 18
    //uid	Y
    //forum_id	Y
    //page	N
    //pageSize	N
    public void rewardPaihang(String uid, String forum_id, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("forum_id", forum_id);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.rewardPaihang, map), httpResult);
    }


    public void setPosts(String uid, String forum_id, String title, String gambit, String atuids, String links, String content, String pics,
                         String video, String phone_type, String is_reward, String reward_integral, String cate_id, String app_id, String tail_id,
                         String is_gonggao, String show_type, String posts_id, String look_type, String look_grade,
                         ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("forum_id", forum_id);
        map.put("title", title);
        map.put("gambit", gambit);
        map.put("atuids", atuids);
        map.put("links", links);
        map.put("content", content);
        map.put("pics", pics);
        map.put("video", video);
        map.put("phone_type", phone_type);
        map.put("is_reward", is_reward);
        map.put("reward_integral", reward_integral);
        map.put("cate_id", cate_id);
        map.put("app_id", app_id);
        map.put("tail_id", tail_id);
        map.put("is_gonggao", is_gonggao);
        map.put("show_type", show_type);
        map.put("posts_id", posts_id);
        map.put("look_type", look_type);
        map.put("look_intagral", look_grade);
        enqueue(postRequest(API.setPosts, map), httpResult);
    }

    // 尾巴列表 20
    //uid	Y
    //id	Y
    //content	Y
    public void getTailList(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getTailList, map), httpResult);
    }

    // 添加编辑尾巴 21
    //uid	Y
    //id	Y
    //content	Y
    public void saveTail(String uid, String id, String content, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        map.put("content", content);
        enqueue(postRequest(API.saveTail, map), httpResult);
    }


    // 获取话题
    //uid	Y
    //app_id	Y
    //order_type	N	0
    //page	N
    //pageSize	N
    public void getAppGambit(String uid, String app_id, String order_type, String page, String pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("app_id", app_id);
        map.put("order_type", order_type);
        map.put("page", page);
        map.put("pageSize", pageSize);
        enqueue(postRequest(API.getAppGambit, map), httpResult);
    }

    // 版主删帖 22
    //uid	Y
    //id	Y		帖子id
    public void delForumPosts(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.delForumPosts, map), httpResult);
    }

    // 版主置顶 23
    //uid	Y
    //id	Y		帖子id
    public void topForumPosts(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.topForumPosts, map), httpResult);
    }


    // 版主设置帖子未审核 24
    //uid	Y
    //id	Y		帖子id
    public void checkForumPosts(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.checkForumPosts, map), httpResult);
    }


    // 删除尾巴 26  /Api/Forum/delTail
    //    uid：用户id，id：尾巴id
    public void delTail(String uid, String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("id", id);
        enqueue(postRequest(API.delTail, map), httpResult);
    }

    // 确认帖子评论 26
    //uid	Y
    //posts_id	Y		帖子id
    //comment_id	Y		评论id
    public void compReward(String uid, String posts_id, String comment_id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("posts_id", posts_id);
        map.put("comment_id", comment_id);
        enqueue(postRequest(API.compReward, map), httpResult);
    }

    //传输文件信息
    public void transfeInfo(String url, String integral, String code, String name, String size, String imgUrl, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", UserMgr.getUid());
        map.put("integral", integral);
        map.put("url", url);
        map.put("code", code);
        map.put("name", name);
        map.put("size", size);
        map.put("icon", imgUrl);
        enqueue(postRequest(API.TRANSFE_INFO, map), httpResult);
    }

    //传输文件列表
    public void transfeList(int page, int pageSize, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", UserMgr.getUid());
        map.put("page", page + "");
        map.put("pageSize", pageSize + "");
        enqueue(postRequest(API.TRANSFE_LIST, map), httpResult);
    }

    //传输文件接收码校验
    public void transfeFileCheck(String code, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", UserMgr.getUid());
        map.put("code", code);
        enqueue(postRequest(API.TRANSFE_FILE_CHECK, map), httpResult);
    }

    //传输文件下载次数
    public void transfeFileDownloadCount(ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", UserMgr.getUid());
        enqueue(postRequest(API.TRANSFE_DOWNLOAD_COUNT, map), httpResult);
    }

    //传输文件下载次数
    public void transfeFileDel(String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", UserMgr.getUid());
        map.put("id", id);
        enqueue(postRequest(API.TRANSFE_DEL_RECORD, map), httpResult);
    }

    public void downloadTransfeApp(String id, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", UserMgr.getUid());
        map.put("ft_id", id);
        enqueue(postRequest(API.TRANSFE_DOWNLOAD, map), httpResult);
    }

    // 上传 1
    public void upload(File file, String uid, ResultCallback<?> httpResult) {
        enqueue(fileRequest(file, uid), httpResult);
    }

    // 上传 2
    public void uploadNoYs(File file, String uid, ResultCallback<?> httpResult) {
        enqueue(fileNoysRequest(file, uid), httpResult);
    }

    //翻译 0.百度翻译，1.腾讯翻译，2.百度图片提取文字
    public void getFySdk(String type, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        enqueue(postRequest(API.getFySdk, map), httpResult);
    }

    //翻译
    public void setFyRecord(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.setFyRecord, map), httpResult);
    }

    //翻译
    public void duihuanFyCount(String uid, String fycount, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        map.put("fycount", fycount);
        enqueue(postRequest(API.duihuanFyCount, map), httpResult);
    }

    //翻译
    public void getFyCount(String uid, ResultCallback<?> httpResult) {
        HashMap<String, String> map = new HashMap<>();
        map.put("uid", uid);
        enqueue(postRequest(API.getFyCount, map), httpResult);
    }


    //翻译
    public static TreeMap<String, Object> getTencentSign(String SourceText, String from, String to, String SecretId, String secret_key) throws Exception {
        TreeMap<String, Object> map = new TreeMap<>(); // TreeMap可以自动排序
        map.put("Action", "TextTranslate");
        map.put("Region", "ap-guangzhou");
        map.put("Version", "2018-03-21");
        map.put("Timestamp", (System.currentTimeMillis() / 1000));
        map.put("Nonce", 13256);
        map.put("SourceText", SourceText);
        map.put("Source", from);
        map.put("ProjectId", 0);
        map.put("Target", to.equals("auto") ? "zh" : to);
        map.put("SecretId", SecretId);
        map.put("Signature", sign(getStringToSign(false, map), secret_key, "HmacSHA1")); // 公共参数
        return map;
    }

    //图片识别
    public static TreeMap<String, Object> getTencentSign(String ImageUrl, String SecretId, String secret_key) throws Exception {
        TreeMap<String, Object> map = new TreeMap<>(); // TreeMap可以自动排序
        map.put("Action", "GeneralBasicOCR");
        map.put("Region", "ap-guangzhou");
        map.put("Version", "2018-11-19");
        map.put("Timestamp", (System.currentTimeMillis() / 1000));
        map.put("Nonce", 13256);
        map.put("LanguageType", geTencentImgFrom(AppConfig.getTranslationConfig().getFrom()));
        map.put("ImageUrl", ImageUrl);
//        map.put("ImageBase64", ImageBase64);
        map.put("SecretId", SecretId);
        map.put("Signature", sign(getStringToSign(true, map), secret_key, "HmacSHA1")); // 公共参数
        return map;
    }

    public static String sign(String s, String key, String method) throws Exception {
        Mac mac = Mac.getInstance(method);
        SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(CHARSET), mac.getAlgorithm());
        mac.init(secretKeySpec);
        byte[] hash = mac.doFinal(s.getBytes(CHARSET));
        return Base64.encodeToString(hash, Base64.DEFAULT);
    }

    public static String getStringToSign(boolean isImg, TreeMap<String, Object> params) {
        //"GETcvm.tencentcloudapi.com/?"
        StringBuilder s2s;
        if (isImg) {
            s2s = new StringBuilder("GETocr.tencentcloudapi.com/?");
        } else {
            s2s = new StringBuilder("GETtmt.tencentcloudapi.com/?");
        }
        // 签名时要求对参数进行字典排序，此处用TreeMap保证顺序
        for (String k : params.keySet()) {
            s2s.append(k).append("=").append(params.get(k).toString()).append("&");
        }
        return s2s.toString().substring(0, s2s.length() - 1);
    }

    public static String getUrl(boolean isImg, TreeMap<String, Object> params) throws UnsupportedEncodingException {
        StringBuilder url;
        if (isImg) {
            url = new StringBuilder("https://ocr.tencentcloudapi.com/?");
        } else {
            url = new StringBuilder("https://tmt.tencentcloudapi.com/?");
        }
        // 实际请求的url中对参数顺序没有要求
        for (String k : params.keySet()) {
            // 需要对请求串进行urlencode，由于key都是英文字母，故此处仅对其value进行urlencode
            url.append(k).append("=").append(URLEncoder.encode(params.get(k).toString(), CHARSET)).append("&");
        }
        return url.toString().substring(0, url.length() - 1);
    }


    private static String generalBasicByHttpURLConnection(String filePath, String accessToken) {
        // 请求url

        String url = "https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic";
//        url = "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate_basic";
//        url = "https://aip.baidubce.com/rest/2.0/ocr/v1/webimage";
        try {
            // 本地文件路径
            byte[] imgData = FileUtil.readFileByBytes(filePath);
            String imgStr = Base64Util.encode(imgData);
            String imgParam = URLEncoder.encode(imgStr, "UTF-8");

            String from = AppConfig.getTranslationConfig().getFrom();

//+ "&language_type=" + getBaiduImgFrom(from)
            String param = "image=" + imgParam + "&language_type=" + getBaiduImgFrom(from);
            // 注意这里仅为了简化编码每一次请求都去获取access_token，线上环境access_token有过期时间， 客户端可自行缓存，过期后重新获取。
            String result = HttpUtil.post(url, accessToken, param);
            System.out.println(result);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String geTencentImgFrom(String f) {
        String tencentFrom;
        switch (f) {
            case "fra":
                tencentFrom = "fre";
                break;
            case "jp":
                tencentFrom = "jap";
                break;
            case "de":
                tencentFrom = "ger";
                break;
            case "kor":
                tencentFrom = "kor";
                break;
            case "zh":
            case "en":
                tencentFrom = "zh";
                break;
            default:
                tencentFrom = "auto";
                break;
        }
        return tencentFrom;
    }

    private static String getBaiduImgFrom(String f) {
        String baiduFrom;
        switch (f) {
            case "en":
                baiduFrom = "ENG";
                break;
            case "fra":
                baiduFrom = "FRE";
                break;
            case "jp":
                baiduFrom = "JAP";
                break;
            case "zh":
                baiduFrom = "CHN_ENG";
                break;
            case "de":
                baiduFrom = "GER";
                break;
            case "kor":
                baiduFrom = "KOR";
                break;
            default:
                baiduFrom = "auto_detect";
                break;
        }
        return baiduFrom;
    }

    private static String post(String requestUrl, String accessToken, String params)
            throws Exception {
        String contentType = "application/x-www-form-urlencoded";
        return post(requestUrl, accessToken, contentType, params);
    }

    private static String post(String requestUrl, String accessToken, String contentType, String params)
            throws Exception {
        String encoding = "UTF-8";
        if (requestUrl.contains("nlp")) {
            encoding = "GBK";
        }
        return post(requestUrl, accessToken, contentType, params, encoding);
    }

    private static String post(String requestUrl, String accessToken, String contentType, String params, String encoding)
            throws Exception {
        String url = requestUrl + "?access_token=" + accessToken;
        return postGeneralUrl(url, contentType, params, encoding);
    }

    private static String postGeneralUrl(String generalUrl, String contentType, String params, String encoding)
            throws Exception {
        URL url = new URL(generalUrl);
        // 打开和URL之间的连接
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        // 设置通用的请求属性
        connection.setRequestProperty("Content-Type", contentType);
        connection.setRequestProperty("Connection", "Keep-Alive");
        connection.setUseCaches(false);
        connection.setDoOutput(true);
        connection.setDoInput(true);

        // 得到请求的输出流对象
        DataOutputStream out = new DataOutputStream(connection.getOutputStream());
        out.write(params.getBytes(encoding));
        out.flush();
        out.close();

        // 建立实际的连接
        connection.connect();
        // 获取所有响应头字段
        Map<String, List<String>> headers = connection.getHeaderFields();
        // 遍历所有的响应头字段
        for (String key : headers.keySet()) {
            System.err.println(key + "--->" + headers.get(key));
        }
        // 定义 BufferedReader输入流来读取URL的响应
        BufferedReader in = null;
        in = new BufferedReader(
                new InputStreamReader(connection.getInputStream(), encoding));
        String result = "";
        String getLine;
        while ((getLine = in.readLine()) != null) {
            result += getLine;
        }
        in.close();
        System.err.println("result:" + result);
        return result;
    }


    public interface ImageCallBack {
        void onResult(BaiduImage data);

        void onFailure(String e, int code);
    }

    public interface ImageTencentCallBack {
        void onResult(TencentImg data);

        void onFailure(String e, int code);
    }

    public interface TransTencentCallBack {
        void onResult(TencentTrans data);

        void onFailure(String e, int code);
    }
}
