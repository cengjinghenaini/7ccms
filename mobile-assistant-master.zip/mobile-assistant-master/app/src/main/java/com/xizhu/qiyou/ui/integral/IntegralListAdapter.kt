package com.xizhu.qiyou.ui.integral

import com.chad.library.adapter.base.BaseProviderMultiAdapter
import com.xizhu.qiyou.entity.GradeBean

class IntegralListAdapter : BaseProviderMultiAdapter<Any>() {
    companion object {
        const val TYPE_EMPTY = 1
        const val TYPE_NORMAL = 2
    }

    init {
        addItemProvider(IntegralEmptyProvider())
        addItemProvider(IntegralNormalProvider())
    }

    override fun getItemType(data: List<Any>, position: Int): Int {
        val item = data[position]
        return if (item is GradeBean) {
            TYPE_NORMAL
        } else {
            TYPE_EMPTY
        }
    }
}