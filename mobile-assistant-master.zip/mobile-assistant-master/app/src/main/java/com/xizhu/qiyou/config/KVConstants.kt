package com.xizhu.qiyou.config

object KVConstants {
    const val IS_LOGIN="is_login"
    const val IS_MEMBER="is_member"
    const val GRADE_ID="grade_id"
    const val LOGIN_USER_ID="login_user_id"
    const val LOGIN_USER_INFO = "LOGIN_USER_INFO"
}