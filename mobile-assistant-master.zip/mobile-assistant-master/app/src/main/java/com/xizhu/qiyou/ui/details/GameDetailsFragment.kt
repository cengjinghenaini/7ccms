package com.xizhu.qiyou.ui.details

import androidx.recyclerview.widget.LinearLayoutManager
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.entity.DetailGame
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.UnitUtil
import kotlinx.android.synthetic.main.fragment_game_details.*
import java.util.*

class GameDetailsFragment : BaseFragment() {
    private var detailGame: DetailGame? = null
    private val adapter = ImageAdapter().apply {
        addChildClickViewIds(R.id.img_v, R.id.img_h)
        setOnItemChildClickListener { _, _, position ->
            PreviewImageActivity.start(context, data as ArrayList<String>, position)
        }
    }

    companion object {
        fun instance(detailGame: DetailGame): GameDetailsFragment {
            val fragment = GameDetailsFragment()
            fragment.detailGame = detailGame
            return fragment
        }
    }

    override fun getRes(): Int {
        return R.layout.fragment_game_details
    }

    override fun initView() {
        super.initView()
        recycler_img?.layoutManager =
            LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
        recycler_img?.adapter = adapter
    }

    override fun initData() {
        super.initData()
        adapter.setNewInstance(detailGame?.pics)
        tv_version?.text = "版本：${detailGame?.version}"
        tv_date?.text = "日期：${UnitUtil.timeStamp2Date(detailGame?.createtime)}"
        tv_des?.text = detailGame?.desc
    }

    private class ImageAdapter :
        BaseQuickAdapter<String, BaseViewHolder>(R.layout.item_recy_game_details_img) {
        override fun convert(holder: BaseViewHolder, item: String) {
            ImgLoadUtil.load(holder.getView(R.id.img_h), holder.getView(R.id.img_v), item)
        }
    }
}