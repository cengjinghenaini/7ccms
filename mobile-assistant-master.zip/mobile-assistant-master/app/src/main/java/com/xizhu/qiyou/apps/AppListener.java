package com.xizhu.qiyou.apps;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

/**
 * @ClassName AppListener
 * @Description 监控APP的安装和卸载
 * @Author guchu
 * @Date 2021/3/3 14:38
 * @Version 1.0
 */
public class AppListener {
    private Context mContext;
    private AppBroadcastReceiver mAppReceiver;
    private AppStateListener mAppStateListener;

    public AppListener(Context context) {
        mContext = context;
        mAppReceiver = new AppBroadcastReceiver();
    }

    private class AppBroadcastReceiver extends BroadcastReceiver {
        private String packageStr = null;

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (intent.getDataString().startsWith("package:")) {
                packageStr = intent.getDataString().substring("package:".length());
            }
            if (Intent.ACTION_PACKAGE_ADDED.equals(action)) { // 
                mAppStateListener.onAppInstall(packageStr);
            } else if (Intent.ACTION_PACKAGE_REMOVED.equals(action)) { // 
                mAppStateListener.onAppUninstall(packageStr);
            }
        }
    }

    /**
     * 开始监听app状态
     *
     * @param listener
     */
    public void begin(AppStateListener listener) {
        mAppStateListener = listener;
        registerListener();
    }

    public void unregisterListener() {
        mContext.unregisterReceiver(mAppReceiver);
    }

    /**
     * 启动app状态广播接收器
     */
    private void registerListener() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_PACKAGE_ADDED);
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        filter.addDataScheme("package");
        mContext.registerReceiver(mAppReceiver, filter);
    }

    public interface AppStateListener {//

        public void onAppInstall(String packageName);

        public void onAppUninstall(String packageName);
    }
}