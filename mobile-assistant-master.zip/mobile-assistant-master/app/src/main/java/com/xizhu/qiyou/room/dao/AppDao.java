package com.xizhu.qiyou.room.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.xizhu.qiyou.room.entity.AppEntity;

import java.util.List;

@Dao
public interface AppDao {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    void insert(AppEntity appEntity);


    @Query("select * from apps where downloadUrl=(:downloadUrl)")
    AppEntity getAppByDownloadUrl(String downloadUrl);

    @Query("select * from apps where webPackage=(:webPackage)")
    AppEntity getAppByWebPackage(String webPackage);

    @Query("select * from apps where realPackage=(:realPackage)")
    AppEntity getAppByRealPackage(String realPackage);


    @Query("select * from apps where unzipPath=(:unzipPath)")
    AppEntity getAppByDstPath(String unzipPath);


    @Query("select * from apps ")
    LiveData<List<AppEntity>> getAllApps();

    @Query("select * from apps where isInstalled=0")
    List<AppEntity> getAppsNoFinished();

    @Query("select * from apps where isInstalled=0 and downloadProgress=100 and  downloadUrl like '%.apk' or unzipProgress=100 ")
    List<AppEntity> getApps4Install();

    @Query("select * from apps where isInstalled=1")
    List<AppEntity> getAppsFinished();

    @Query("select * from apps where  isInstalled=0 and isManualPaused=0 and downloadProgress<100 and isWorking=1 order by queueTimeInMill desc")
    List<AppEntity> getDownloadingApps();


    @Query("select * from apps where  isInstalled=0 and isManualPaused=0 and downloadProgress<100 and isWorking=0 order by queueTimeInMill desc")
    List<AppEntity> getInQueueDownloadApps();


    @Query("select * from apps where  isInstalled=0 and isManualPaused=0 and isWorking=1 and downloadProgress=100 and unzipProgress<100 and downloadUrl like '%.zip' order by queueTimeInMill desc")
    List<AppEntity> getUnzippingApps();


    @Query("select * from apps where  isInstalled=0 and isManualPaused=0 and isWorking=0 and downloadProgress=100  and unzipProgress<100 and  downloadUrl like '%.zip'  order by queueTimeInMill desc")
    List<AppEntity> getInQueueUnzipApps();


    @Query("select * from apps where  isManualPaused=1")
    List<AppEntity> getPausedApps();

    //这里需要先查询，然后组装结构在调用该函数.

    /**
     * 1.	更新操作start.  update weburl by webPackage. if exists(and clean others msg.)
     * 2.	更新进度...
     * 3.	manualPaused.
     * 4.	更新操作end.	解析apk，update app真正的版本号. realVersion realPackage.
     * 5.	isInstalled.	finish install.
     *
     * @param appEntity
     */
    @Update
    void update(AppEntity appEntity); //这个函数简单，调用起来就要分各种情况咯.

    @Delete
    void deleteApp(AppEntity appEntity);
}
