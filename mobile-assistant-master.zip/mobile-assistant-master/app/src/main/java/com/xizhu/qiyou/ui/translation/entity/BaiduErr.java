package com.xizhu.qiyou.ui.translation.entity;

public class BaiduErr {

    /**
     * error_code : 54003
     * error_msg : Invalid Access Limit
     */

    private String error_code;
    private String error_msg;

    public String getError_code() {
        return error_code;
    }

    public void setError_code(String error_code) {
        this.error_code = error_code;
    }

    public String getError_msg() {
        return error_msg;
    }

    public void setError_msg(String error_msg) {
        this.error_msg = error_msg;
    }
}
