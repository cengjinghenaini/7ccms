package com.xizhu.qiyou.entity;

public class TransfeDownloadConfigBean {
    public int sy;
    public int shiyong;
}
