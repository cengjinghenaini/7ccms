package com.xizhu.qiyou.entity;

import java.util.List;

public class ForumDesc {
    /**
     * id : 1
     * name : 版块1
     * icon : /Uploads/Picture/20201204/0ae1d67d67b2d6f6.jpg
     * cate_id : 1
     * desc : 12312321
     * stipulate : asjkhdasljkhaskjfhaskj
     * app_count : 0
     * hot_count : 0
     * createtime : 1607086510
     * forum_host : [{"uid":"1","phone":"18254127300","email":"123@12.com","name":"","wx_name":"","qq":"","head":"","touxian_id":"","touxian":"","sex":"1","is_member":"","age":"","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":""}]
     * cate : {"id":"1","name":"版块分类1"}
     */

    private String id;
    private String name;
    private String icon;
    private String cate_id;
    private String desc;
    private String stipulate;
    private String app_count;
    private String hot_count;
    private String createtime;
    private Cate cate;
    private List<ForumHost> forum_host;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getCate_id() {
        return cate_id;
    }

    public void setCate_id(String cate_id) {
        this.cate_id = cate_id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getStipulate() {
        return stipulate;
    }

    public void setStipulate(String stipulate) {
        this.stipulate = stipulate;
    }

    public String getApp_count() {
        return app_count;
    }

    public void setApp_count(String app_count) {
        this.app_count = app_count;
    }

    public String getHot_count() {
        return hot_count;
    }

    public void setHot_count(String hot_count) {
        this.hot_count = hot_count;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public Cate getCate() {
        return cate;
    }

    public void setCate(Cate cate) {
        this.cate = cate;
    }

    public List<ForumHost> getForum_host() {
        return forum_host;
    }

    public void setForum_host(List<ForumHost> forum_host) {
        this.forum_host = forum_host;
    }



    /**
     * forum : {"name":"1","id":"","icon":"","cate_id":"","desc":"介绍","stipulate":"规定","hot_count":"","app_count":"","createtime":""}
     * forum_host : [{"uid":"1","phone":"18254127300","email":"123@12.com","name":"","wx_name":"","qq":"","head":"","touxian_id":"","touxian":"","sex":"1","is_member":"","age":"","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":""}]
     * cate : {"id":"","name":""}
     */




}
