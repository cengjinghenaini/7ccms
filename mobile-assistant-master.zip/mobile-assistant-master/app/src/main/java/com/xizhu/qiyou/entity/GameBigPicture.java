package com.xizhu.qiyou.entity;


public class GameBigPicture extends BaseGame {

    /**
     * id : 1
     * app_id : 1
     * title : 1
     * pic : http://www.7you.cn1
     * sort : 100
     * createtime : 0
     * app : {"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value"}
     * createtime_f : 1970-01-01 08:00:00
     * type:  0.应用，1.专题
     * topic_id: 1
     */
    public static final String TYPE_APP = "0";
    public static final String TYPE_TOPIC = "1";
    private String id;
    private String title;
    private String pic;
    //支持主题类型
    private String type;
    private String topic_id;


    public Special getTopic() {
        return topic;
    }

    public void setTopic(Special topic) {
        this.topic = topic;
    }

    private Special topic;


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTopic_id() {
        return topic_id;
    }

    public void setTopic_id(String topic_id) {
        this.topic_id = topic_id;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }
}

