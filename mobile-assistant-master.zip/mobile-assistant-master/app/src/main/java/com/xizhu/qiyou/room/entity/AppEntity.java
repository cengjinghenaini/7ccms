package com.xizhu.qiyou.room.entity;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.xizhu.qiyou.entity.DetailGame;

import java.io.File;

@Entity(tableName = "apps")
public class AppEntity implements Parcelable {
    public static final int TYPE_MANUAL_PAUSED = 1;
    public static final int TYPE_NO_PAUSED = 0;
    public static final int TYPE_INSTALLED = 1;
    public static final int TYPE_NO_INSTALLED = 0;
    public static final int TYPE_WORKING = 1;
    public static final int TYPE_IN_QUEUE = 0;
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String name;
    private String icon;
    private String appDesc;
    private String downloadUrl;
    private String webPackage;
    private String webVersion;
    private long size;
    private String score;

    private String realPackage;
    private String realVersion;
    private String downPath;
    private int downloadProgress;
    private String unzipPath;
    private int unzipProgress;
    private long queueTimeInMill;
    private int isWorking;  //这个仅仅在Service中进行更新.
    private int downSpeed;
    private int unzipSpeed;

    public int getUnzipSpeed() {
        return unzipSpeed;
    }

    public void setUnzipSpeed(int unzipSpeed) {
        this.unzipSpeed = unzipSpeed;
    }

    protected AppEntity(Parcel in) {
        id = in.readInt();
        name = in.readString();
        icon = in.readString();
        appDesc = in.readString();
        downloadUrl = in.readString();
        webPackage = in.readString();
        webVersion = in.readString();
        size = in.readLong();
        score = in.readString();
        realPackage = in.readString();
        realVersion = in.readString();
        downPath = in.readString();
        downloadProgress = in.readInt();
        unzipPath = in.readString();
        unzipProgress = in.readInt();
        queueTimeInMill = in.readLong();
        isWorking = in.readInt();
        isManualPaused = in.readInt();
        isInstalled = in.readInt();
    }

    public static final Creator<AppEntity> CREATOR = new Creator<AppEntity>() {
        @Override
        public AppEntity createFromParcel(Parcel in) {
            return new AppEntity(in);
        }

        @Override
        public AppEntity[] newArray(int size) {
            return new AppEntity[size];
        }
    };

    private int isManualPaused;
    private int isInstalled;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AppEntity appEntity = (AppEntity) o;

        return id == appEntity.id;
    }

    @Override
    public int hashCode() {
        return id;
    }

    public void update(DetailGame detailGame) {
        this.name = detailGame.getName();
        this.icon = detailGame.getIcon();
        this.appDesc = detailGame.getDesc();
        this.downloadUrl = detailGame.getDownload_url();
        this.webVersion = detailGame.getVersion();
        this.size = (long) Double.parseDouble(detailGame.getSize());
        this.score = detailGame.getScore();
        this.realPackage = "";
        this.realVersion = "";
        this.downPath = "";
        this.downloadProgress = 0;
        this.unzipPath = "";
        this.unzipProgress = 0;
        this.isManualPaused = 0;
        this.isInstalled = 0;
        this.queueTimeInMill = System.currentTimeMillis();
        this.isWorking = 0;
    }

    public void clear() {
        this.realPackage = "";
        this.realVersion = "";
        this.downloadProgress = 0;
        this.unzipProgress = 0;
        this.isManualPaused = 0;
        this.isManualPaused = 0;
        this.isInstalled = 0;
        this.queueTimeInMill = 0;
        this.isWorking = 0;
    }


    @Override
    public String toString() {
        return "AppEntity{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", icon='" + icon + '\'' +
                ", appDesc='" + appDesc + '\'' +
                ", downloadUrl='" + downloadUrl + '\'' +
                ", webPackage='" + webPackage + '\'' +
                ", webVersion='" + webVersion + '\'' +
                ", size=" + size +
                ", realPackage='" + realPackage + '\'' +
                ", realVersion='" + realVersion + '\'' +
                ", downPath='" + downPath + '\'' +
                ", downloadProgress=" + downloadProgress +
                ", unzipPath='" + unzipPath + '\'' +
                ", unzipProgress=" + unzipProgress +
                ", isManualPaused=" + isManualPaused +
                ", isInstalled=" + isInstalled +
                '}';
    }

    public AppEntity() {

    }


    public AppEntity(DetailGame detailGame) {
        this.id = Integer.parseInt(detailGame.getId());
        this.name = detailGame.getName();
        this.icon = detailGame.getIcon();
        this.appDesc = detailGame.getDesc();
        this.downloadUrl = detailGame.getDownload_url();
        this.webPackage = detailGame.getPackageX();
        this.webVersion = detailGame.getVersion();
        this.size = (long) Double.parseDouble(detailGame.getSize());
        this.score = detailGame.getScore();
        this.realPackage = "";
        this.realVersion = "";
        this.downPath = "";
        this.downloadProgress = 0;
        this.unzipPath = "";
        this.unzipProgress = 0;
        this.isManualPaused = 0;
        this.isManualPaused = 0;
        this.isInstalled = 0;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAppDesc() {
        return appDesc;
    }

    public void setAppDesc(String appDesc) {
        this.appDesc = appDesc;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRealPackage() {
        return realPackage;
    }

    public void setRealPackage(String realPackage) {
        this.realPackage = realPackage;
    }

    public String getWebPackage() {
        return webPackage;
    }

    public void setWebPackage(String webPackage) {
        this.webPackage = webPackage;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getRealVersion() {
        return realVersion;
    }

    public void setRealVersion(String realVersion) {
        this.realVersion = realVersion;
    }

    public String getWebVersion() {
        return webVersion;
    }

    public void setWebVersion(String webVersion) {
        this.webVersion = webVersion;
    }

    public String getDownPath() {
        return downPath;
    }

    public void setDownPath(String downPath) {
        File downloadFile = new File(downPath);
        this.downPath = downloadFile.getAbsolutePath();
    }

    public int getDownloadProgress() {
        return downloadProgress;
    }

    public void setDownloadProgress(int downloadProgress) {
        this.downloadProgress = downloadProgress;
    }

    public String getUnzipPath() {
        return unzipPath;
    }

    public void setUnzipPath(String unzipPath) {
        if (!TextUtils.isEmpty(unzipPath)) {
            File unzippedFile = new File(unzipPath);
            this.unzipPath = unzippedFile.getAbsolutePath();
        }
    }

    public int getUnzipProgress() {
        return unzipProgress;
    }

    public void setUnzipProgress(int unzipProgress) {
        this.unzipProgress = unzipProgress;
    }

    public int getIsManualPaused() {
        return isManualPaused;
    }

    public void setIsManualPaused(int isManualPaused) {
        this.isManualPaused = isManualPaused;
    }

    public int getIsInstalled() {
        return isInstalled;
    }

    public void setIsInstalled(int isInstalled) {
        this.isInstalled = isInstalled;
    }

    public long getQueueTimeInMill() {
        return queueTimeInMill;
    }

    public void setQueueTimeInMill(long queueTimeInMill) {
        this.queueTimeInMill = queueTimeInMill;
    }

    public int getIsWorking() {
        return isWorking;
    }

    public void setIsWorking(int isWorking) {
        this.isWorking = isWorking;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(icon);
        dest.writeString(appDesc);
        dest.writeString(downloadUrl);
        dest.writeString(webPackage);
        dest.writeString(webVersion);
        dest.writeLong(size);
        dest.writeString(score);
        dest.writeString(realPackage);
        dest.writeString(realVersion);
        dest.writeString(downPath);
        dest.writeInt(downloadProgress);
        dest.writeString(unzipPath);
        dest.writeInt(unzipProgress);
        dest.writeLong(queueTimeInMill);
        dest.writeInt(isWorking);
        dest.writeInt(isManualPaused);
        dest.writeInt(isInstalled);
    }

    public int getDownSpeed() {
        return downSpeed;
    }

    public void setDownSpeed(int downSpeed) {
        this.downSpeed = downSpeed;
    }
}
