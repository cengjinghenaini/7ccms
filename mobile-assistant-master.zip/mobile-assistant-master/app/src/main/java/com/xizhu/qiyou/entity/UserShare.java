package com.xizhu.qiyou.entity;

public class UserShare {

    /**
     * id : value
     * uid : value
     * app_id : value
     * type : value
     * createtime : value
     * app : {"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value"}
     */

    private String id;
    private String uid;
    private String app_id;
    private String type;
    private String createtime;
    private BaseApp app;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public BaseApp getApp() {
        return app;
    }

    public void setApp(BaseApp app) {
        this.app = app;
    }

    @Override
    public String toString() {
        return "UserShare{" +
                "id='" + id + '\'' +
                ", uid='" + uid + '\'' +
                ", app_id='" + app_id + '\'' +
                ", type='" + type + '\'' +
                ", createtime='" + createtime + '\'' +
                ", app=" + app +
                '}';
    }
}
