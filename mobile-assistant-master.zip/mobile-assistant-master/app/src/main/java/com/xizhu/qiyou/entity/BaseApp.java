package com.xizhu.qiyou.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class BaseApp implements Serializable {
    /**
     * id : value
     * pic : value
     * title : value
     * name : value
     * icon : value
     * introduction : value
     * score : value
     * comment_count : value
     * version : value
     * size : value
     * down_time : value
     * rec_reason : value
     */

    protected String id;
    protected String pic;
    protected String title;
    protected String name;
    protected String icon;
    protected String introduction;
    protected String score;
    protected String down_count;
    protected String comment_count;
    protected String version;
    protected String size;
    protected String down_time;
    protected String rec_reason;
    protected String is_reserve;
    protected String yiyuyue;
    protected String video;
    protected List<Label> labels;
    @SerializedName("package")
    private String packageX;
    private String down_url;//免费下载链接
    private int is_comment;
    private String uid;
    private String desc;
    private String look_id;
    private WebGame app_type;
    private String old_version;

    public BaseApp() {
    }

    public String getOld_version() {
        return old_version;
    }

    public void setOld_version(String old_version) {
        this.old_version = old_version;
    }

    public WebGame getApp_type() {
        return app_type;
    }

    public void setApp_type(WebGame app_type) {
        this.app_type = app_type;
    }

    public String getLook_id() {
        return look_id;
    }

    public void setLook_id(String look_id) {
        this.look_id = look_id;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    protected BaseApp(Parcel in) {
        id = in.readString();
        pic = in.readString();
        title = in.readString();
        name = in.readString();
        icon = in.readString();
        introduction = in.readString();
        score = in.readString();
        down_count = in.readString();
        comment_count = in.readString();
        version = in.readString();
        size = in.readString();
        down_time = in.readString();
        rec_reason = in.readString();
        is_reserve = in.readString();
        yiyuyue = in.readString();
        labels = in.createTypedArrayList(Label.CREATOR);
    }

    public void setLabels(List<Label> labels) {
        this.labels = labels;
    }

    public List<Label> getLabels() {
        return labels;
    }

    public String getYiyuyue() {
        return yiyuyue;
    }

    public void setYiyuyue(String yiyuyue) {
        this.yiyuyue = yiyuyue;
    }

    public String getIs_reserve() {
        return is_reserve;
    }

    public void setIs_reserve(String is_reserve) {
        this.is_reserve = is_reserve;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getDown_count() {
        return down_count;
    }

    public void setDown_count(String down_count) {
        this.down_count = down_count;
    }

    public String getComment_count() {
        return comment_count;
    }

    public void setComment_count(String comment_count) {
        this.comment_count = comment_count;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getDown_time() {
        return down_time;
    }

    public void setDown_time(String down_time) {
        this.down_time = down_time;
    }

    public String getRec_reason() {
        return rec_reason;
    }

    public void setRec_reason(String rec_reason) {
        this.rec_reason = rec_reason;
    }

    @Override
    public String toString() {
        return "BaseApp{" +
                "id='" + id + '\'' +
                ", pic='" + pic + '\'' +
                ", title='" + title + '\'' +
                ", name='" + name + '\'' +
                ", icon='" + icon + '\'' +
                ", introduction='" + introduction + '\'' +
                ", score='" + score + '\'' +
                ", comment_count='" + comment_count + '\'' +
                ", version='" + version + '\'' +
                ", size='" + size + '\'' +
                ", down_time='" + down_time + '\'' +
                ", rec_reason='" + rec_reason + '\'' +
                ", is_reserve='" + is_reserve + '\'' +
                ", yiyuyue='" + yiyuyue + '\'' +
                '}';
    }

    public String getPackageX() {
        return packageX;
    }

    public void setPackageX(String packageX) {
        this.packageX = packageX;
    }

    public String getDown_url() {
        return down_url;
    }

    public void setDown_url(String down_url) {
        this.down_url = down_url;
    }

    public int getIs_comment() {
        return is_comment;
    }

    public void setIs_comment(int is_comment) {
        this.is_comment = is_comment;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}