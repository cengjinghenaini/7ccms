package com.xizhu.qiyou.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;

import androidx.annotation.RequiresApi;

import com.xizhu.qiyou.apps.CurrentNetEvent;
import com.xizhu.qiyou.util.NetUtil;

import org.greenrobot.eventbus.EventBus;

public class NetBroadCastReceiver extends BroadcastReceiver {
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onReceive(Context context, Intent intent) {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo MOBILE = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        NetworkInfo WIFI = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetUtil.netIsConnected = true;

        Network network = manager.getActiveNetwork();
        if (network == null) {
            EventBus.getDefault().post(new CurrentNetEvent(CurrentNetEvent.TYPE_NONE));
            return;
        }
        NetworkCapabilities nc = manager.getNetworkCapabilities(network);
        if (nc == null) {
            EventBus.getDefault().post(new CurrentNetEvent(CurrentNetEvent.TYPE_NONE));
            return;
        }
        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            EventBus.getDefault().post(new CurrentNetEvent(CurrentNetEvent.TYPE_WIFI));
            return;
        }

        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            EventBus.getDefault().post(new CurrentNetEvent(CurrentNetEvent.TYPE_4G));
            return;
        }
        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
            EventBus.getDefault().post(new CurrentNetEvent(CurrentNetEvent.TYPE_ETHERNET));
            return;
        }
    }
}
