package com.xizhu.qiyou.util;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.drawable.RoundedBitmapDrawable;
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory;
import androidx.fragment.app.FragmentActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.bumptech.glide.request.target.ImageViewTarget;
import com.luck.picture.lib.PictureSelector;
import com.luck.picture.lib.config.PictureConfig;
import com.luck.picture.lib.config.PictureMimeType;
import com.luck.picture.lib.engine.ImageEngine;
import com.luck.picture.lib.listener.OnImageCompleteCallback;
import com.luck.picture.lib.tools.MediaUtils;
import com.luck.picture.lib.widget.longimage.ImageSource;
import com.luck.picture.lib.widget.longimage.ImageViewState;
import com.luck.picture.lib.widget.longimage.SubsamplingScaleImageView;
import com.permissionx.guolindev.PermissionX;
import com.xizhu.qiyou.R;
import com.xizhu.qiyou.config.Constant;
import com.xizhu.qiyou.util.dialog.ToastUtil;

public class PicSelectUtil {

    public static void selectPic(Activity activity) {
        selectPic(activity, false);
    }

    public static void selectPic(Activity activity, boolean isCrop) {

        PictureSelector.create(activity)
                .openGallery(PictureConfig.TYPE_IMAGE)
                .isGif(true)
                .imageEngine(GlideEngine.createGlideEngine())
                .imageSpanCount(4)// 每行显示个数 int
                .maxSelectNum(1)
                .selectionMode(PictureConfig.SINGLE)// 多选 or 单选 PictureConfig.MULTIPLE or PictureConfig.SINGLE
                .isPreviewImage(true)// 是否可预览图片 true or false
                .isCamera(true)// 是否显示拍照按钮 true or false
                .imageFormat(PictureMimeType.JPEG)// 拍照保存图片格式后缀,默认jpeg
                .isZoomAnim(true)// 图片列表点击 缩放效果 默认true
//                .setOutputCameraPath(Const.IMG_PATH)// 自定义拍照保存路径,可不填
                .isEnableCrop(isCrop)// 是否裁剪 true or false
                .withAspectRatio(1, 1)
                .isCompress(true)// 是否压缩 true or false
//                .compressSavePath(Const.IMG_PATH)//压缩图片保存地址
                .freeStyleCropEnabled(true)// 裁剪框是否可拖拽 true or false
                .showCropGrid(true)// 是否显示裁剪矩形网格 圆形裁剪时建议设为false    true or false
                .forResult(PictureConfig.CHOOSE_REQUEST);//结果回调onActivityResult code
    }


    public static void selectPicComment(Activity activity) {

        PictureSelector.create(activity)
                .openGallery(PictureConfig.TYPE_IMAGE)
                .isGif(true)
                .imageEngine(GlideEngine.createGlideEngine())
                .imageSpanCount(4)// 每行显示个数 int
                .maxSelectNum(1)
                .selectionMode(PictureConfig.SINGLE)// 多选 or 单选 PictureConfig.MULTIPLE or PictureConfig.SINGLE
                .isPreviewImage(true)// 是否可预览图片 true or false
                .isCamera(false)// 是否显示拍照按钮 true or false
                .imageFormat(PictureMimeType.JPEG)// 拍照保存图片格式后缀,默认jpeg
                .isZoomAnim(true)// 图片列表点击 缩放效果 默认true
//                .setOutputCameraPath(Const.IMG_PATH)// 自定义拍照保存路径,可不填
                .isEnableCrop(false)// 是否裁剪 true or false
                .compressQuality(40)
                .minimumCompressSize(1024)
                .isCompress(true)// 是否压缩 true or false
//                .compressSavePath(Const.IMG_PATH)//压缩图片保存地址
                .freeStyleCropEnabled(false)// 裁剪框是否可拖拽 true or false
                .showCropGrid(false)// 是否显示裁剪矩形网格 圆形裁剪时建议设为false    true or false
                .forResult(Constant.CHOICE_PHOTO);//结果回调onActivityResult code

    }

    public static void selectPic(Activity activity, int max) {
//        PictureSelector.create(activity)
//                .openGallery(PictureMimeType.ofImage())
//                .loadImageEngine(GlideEngine.createGlideEngine()) // Please refer to the Demo GlideEngine.java
//                .forResult(PictureConfig.CHOOSE_REQUEST);

        PictureSelector.create(activity)
                .openGallery(PictureConfig.TYPE_IMAGE)
                .imageEngine(GlideEngine.createGlideEngine())
                .isGif(true)
                .imageSpanCount(4)// 每行显示个数 int
                .maxSelectNum(max)
                .selectionMode(PictureConfig.MULTIPLE)// 多选 or 单选 PictureConfig.MULTIPLE or PictureConfig.SINGLE
                .isPreviewImage(false)// 是否可预览图片 true or false
                .isCamera(false)// 是否显示拍照按钮 true or false
                .imageFormat(PictureMimeType.JPEG)// 拍照保存图片格式后缀,默认jpeg
                .isZoomAnim(true)// 图片列表点击 缩放效果 默认true
//                .setOutputCameraPath(Const.IMG_PATH)// 自定义拍照保存路径,可不填
                .isEnableCrop(false)// 是否裁剪 true or false
                .compressQuality(40)
                .minimumCompressSize(1024)
                .isCompress(true)// 是否压缩 true or false
//                .compressSavePath(Const.IMG_PATH)//压缩图片保存地址
                .freeStyleCropEnabled(true)// 裁剪框是否可拖拽 true or false
                .showCropGrid(true)// 是否显示裁剪矩形网格 圆形裁剪时建议设为false    true or false
                .forResult(PictureConfig.CHOOSE_REQUEST);//结果回调onActivityResult code

    }

    public static void openPic(FragmentActivity fragmentActivity) {
        PermissionX.init(fragmentActivity)
                .permissions(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .request((allGranted, grantedList, deniedList) -> {
                    if (allGranted) {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("image/*");
                        fragmentActivity.startActivityForResult(intent, Constant.CHOICE_PHOTO);
                    } else {
                        ToastUtil.show("你拒绝了！！");
                    }
                });
    }

    public static void openVideo(FragmentActivity fragmentActivity) {
        PermissionX.init(fragmentActivity)
                .permissions(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .request((allGranted, grantedList, deniedList) -> {
                    if (allGranted) {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("video/*");
                        fragmentActivity.startActivityForResult(intent, Constant.CHOICE_VIDEO);
                    } else {
                        ToastUtil.show("你拒绝了！！");
                    }
                });
    }

    public static void loadImage(@NonNull Context context, @NonNull String url, @NonNull ImageView imageView) {
        GlideEngine.createGlideEngine().loadImage(context, url, imageView);
    }

    static class GlideEngine implements ImageEngine {

        @Override
        public void loadImage(@NonNull Context context, @NonNull String url, @NonNull ImageView imageView) {
            LogUtil.e("loadImage0: " + url);
            Glide.with(context)
                    .load(url)
                    .into(imageView);
        }

        @Override
        public void loadImage(@NonNull Context context, @NonNull String url,
                              @NonNull ImageView imageView,
                              SubsamplingScaleImageView longImageView, OnImageCompleteCallback callback) {
            LogUtil.e("loadImage1: " + url);
            Glide.with(context)
                    .asBitmap()
                    .load(url)
                    .into(new ImageViewTarget<Bitmap>(imageView) {
                        @Override
                        public void onLoadStarted(@Nullable Drawable placeholder) {
                            super.onLoadStarted(placeholder);
                            if (callback != null) {
                                callback.onShowLoading();
                            }
                        }

                        @Override
                        public void onLoadFailed(@Nullable Drawable errorDrawable) {
                            super.onLoadFailed(errorDrawable);
                            if (callback != null) {
                                callback.onHideLoading();
                            }
                        }

                        @Override
                        protected void setResource(@Nullable Bitmap resource) {
                            if (callback != null) {
                                callback.onHideLoading();
                            }
                            if (resource != null) {
                                boolean eqLongImage = MediaUtils.isLongImg(resource.getWidth(),
                                        resource.getHeight());
                                longImageView.setVisibility(eqLongImage ? View.VISIBLE : View.GONE);
                                imageView.setVisibility(eqLongImage ? View.GONE : View.VISIBLE);
                                if (eqLongImage) {
                                    // 加载长图
                                    longImageView.setQuickScaleEnabled(true);
                                    longImageView.setZoomEnabled(true);
                                    longImageView.setDoubleTapZoomDuration(100);
                                    longImageView.setMinimumScaleType(SubsamplingScaleImageView.SCALE_TYPE_CENTER_CROP);
                                    longImageView.setDoubleTapZoomDpi(SubsamplingScaleImageView.ZOOM_FOCUS_CENTER);
                                    longImageView.setImage(ImageSource.bitmap(resource),
                                            new ImageViewState(0, new PointF(0, 0), 0));
                                } else {
                                    // 普通图片
                                    imageView.setImageBitmap(resource);
                                }
                            }
                        }
                    });
        }

        @Override
        public void loadImage(@NonNull Context context, @NonNull String url,
                              @NonNull ImageView imageView,
                              SubsamplingScaleImageView longImageView) {
            LogUtil.e("loadImage: " + url);
            Glide.with(context)
                    .asBitmap()
                    .load(url)
                    .into(new ImageViewTarget<Bitmap>(imageView) {
                        @Override
                        protected void setResource(@Nullable Bitmap resource) {
                            if (resource != null) {
                                boolean eqLongImage = MediaUtils.isLongImg(resource.getWidth(),
                                        resource.getHeight());
                                longImageView.setVisibility(eqLongImage ? View.VISIBLE : View.GONE);
                                imageView.setVisibility(eqLongImage ? View.GONE : View.VISIBLE);
                                if (eqLongImage) {
                                    // 加载长图
                                    longImageView.setQuickScaleEnabled(true);
                                    longImageView.setZoomEnabled(true);
                                    longImageView.setDoubleTapZoomDuration(100);
                                    longImageView.setMinimumScaleType(SubsamplingScaleImageView.SCALE_TYPE_CENTER_CROP);
                                    longImageView.setDoubleTapZoomDpi(SubsamplingScaleImageView.ZOOM_FOCUS_CENTER);
                                    longImageView.setImage(ImageSource.bitmap(resource),
                                            new ImageViewState(0, new PointF(0, 0), 0));
                                } else {
                                    // 普通图片
                                    imageView.setImageBitmap(resource);
                                }
                            }
                        }
                    });
        }

        /**
         * 加载相册目录
         *
         * @param context   上下文
         * @param url       图片路径
         * @param imageView 承载图片ImageView
         */
        @Override
        public void loadFolderImage(@NonNull Context context, @NonNull String url, @NonNull ImageView imageView) {
            LogUtil.e("loadFolderImage: " + url);
            Glide.with(context)
                    .asBitmap()
                    .load(url)
                    .override(180, 180)
                    .centerCrop()
                    .sizeMultiplier(0.5f)
                    .apply(new RequestOptions().placeholder(R.drawable.picture_image_placeholder))
                    .into(new BitmapImageViewTarget(imageView) {
                        @Override
                        protected void setResource(Bitmap resource) {
                            RoundedBitmapDrawable circularBitmapDrawable =
                                    RoundedBitmapDrawableFactory.
                                            create(context.getResources(), resource);
                            circularBitmapDrawable.setCornerRadius(8);
                            imageView.setImageDrawable(circularBitmapDrawable);
                        }
                    });
        }


        /**
         * 加载gif
         *
         * @param context   上下文
         * @param url       图片路径
         * @param imageView 承载图片ImageView
         */
        @Override
        public void loadAsGifImage(@NonNull Context context, @NonNull String url,
                                   @NonNull ImageView imageView) {
            LogUtil.e("loadAsGifImage: " + url);
            Glide.with(context)
                    .asGif()
                    .load(url)
                    .into(imageView);
        }

        /**
         * 加载图片列表图片
         *
         * @param context   上下文
         * @param url       图片路径
         * @param imageView 承载图片ImageView
         */
        @Override
        public void loadGridImage(@NonNull Context context, @NonNull String url, @NonNull ImageView imageView) {
            LogUtil.e("loadGridImage: " + url);
            Glide.with(context)
                    .load(url)
                    .override(200, 200)
                    .centerCrop()
                    .apply(new RequestOptions().placeholder(R.drawable.picture_image_placeholder))
                    .into(imageView);
        }


        private GlideEngine() {
        }

        private static GlideEngine instance;

        public static GlideEngine createGlideEngine() {
            if (null == instance) {
                synchronized (GlideEngine.class) {
                    if (null == instance) {
                        instance = new GlideEngine();
                    }
                }
            }
            return instance;
        }
    }
}
