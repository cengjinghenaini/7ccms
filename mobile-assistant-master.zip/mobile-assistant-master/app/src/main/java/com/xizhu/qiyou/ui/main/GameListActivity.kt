package com.xizhu.qiyou.ui.main

import android.content.Context
import android.content.Intent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.scwang.smart.refresh.layout.api.RefreshLayout
import com.scwang.smart.refresh.layout.listener.OnRefreshLoadMoreListener
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.*
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.ui.search.SearchAdapter
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.widget.EmptyView
import kotlinx.android.synthetic.main.activity_game_list.*
import kotlinx.android.synthetic.main.title_layout.*

class GameListActivity : BaseCompatActivity() {
    private var adapter: SearchAdapter? = null
    private var pageNum = 1
    private var cateId: String? = null
    private var labelId: String? = null
    private var labelName: String? = null

    companion object {
        fun start(context: Context?, cateId: String?, labelId: String?, labelName: String?) {
            val intent = Intent(context, GameListActivity::class.java)
            intent.putExtra("cateId", cateId)
            intent.putExtra("labelId", labelId)
            intent.putExtra("labelName", labelName)
            context?.startActivity(intent)
        }
    }


    override fun getRes(): Int {
        return R.layout.activity_game_list
    }

    override fun initView() {
        cateId = intent.getStringExtra("cateId")
        labelId = intent.getStringExtra("labelId")
        labelName = intent.getStringExtra("labelName")
        iv_back.setOnClickListener {
            finish()
        }
        tv_page_title.text = labelName
        refresh_layout?.setOnRefreshLoadMoreListener(object : OnRefreshLoadMoreListener {
            override fun onRefresh(refreshLayout: RefreshLayout) {
                pageNum = 1
                getGameList()
            }

            override fun onLoadMore(refreshLayout: RefreshLayout) {
                pageNum++
                getGameList()
            }
        })
        empty_view?.setLoadListener {
            pageNum = 1
            getGameList()
        }
        recycler.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        adapter = SearchAdapter().apply {
            setEmptyView(EmptyView(this@GameListActivity).setNoData())
            setOnItemClickListener { _, _, position ->
                val item = getItem(position)
                JumpUtils.jumpToGameDetailsPage(this@GameListActivity,item.id)
            }
        }
        recycler.adapter = adapter
    }

    override fun initData() {
        super.initData()
        getGameList()
    }

    private fun getGameList() {
        val uid = UserMgr.getUid()
        HttpUtil.getInstance()
            .getGame(uid, cateId ?: "", labelId ?: "", pageNum.toString(), Constant.PAGE_SIZE,
                object : ResultCallback<MutableList<BaseApp>>() {
                    override fun onSuccess(s: ResultEntity<MutableList<BaseApp>>) {
                        val data = s.data
                        if (pageNum == 1) {
                            adapter?.setNewInstance(data)
                        } else {
                            adapter?.addData(data)
                        }
                        if (data.size >= Constant.PAGE_SIZE.toInt()) {
                            refresh_layout?.setEnableLoadMore(true)
                        } else {
                            refresh_layout?.setEnableLoadMore(false)
                        }
                        refresh_layout?.finishRefresh()
                        refresh_layout?.finishLoadMore()
                        empty_view?.visibility = View.GONE
                    }

                    override fun onFailure(err: String?, code: Int) {
                        super.onFailure(err, code)
                        if (empty_view?.visibility == View.VISIBLE) {
                            empty_view?.setLoadFail()
                        }
                        refresh_layout?.setEnableLoadMore(false)
                        refresh_layout?.finishRefresh(false)
                        refresh_layout?.finishLoadMore(false)
                        if (pageNum > 1) {
                            pageNum--
                        }
                    }
                })
    }
}