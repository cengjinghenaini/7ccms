package com.xizhu.qiyou.ui.account

import android.text.TextUtils
import com.xizhu.qiyou.BuildConfig
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.NULL
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.util.AppUtils
import com.xizhu.qiyou.util.dialog.ToastUtil
import kotlinx.android.synthetic.main.activity_retrieve_password.*

class RetrievePasswordActivity : BaseCompatActivity() {

    override fun fitWindow(): Boolean {
        return false
    }

    override fun isLight(): Boolean {
        return false
    }

    override fun getStatusColorRes(): Int {
        return R.color.C_00000000
    }

    override fun getRes(): Int {
        return R.layout.activity_retrieve_password
    }

    override fun initView() {
        val welcomeText = tv_welcome.text.toString()
        tv_welcome.text = welcomeText.replace("XXX", AppUtils.getAppName(this))
        tv_action_1.setOnClickListener {
            retrievePassword()
        }
        tv_action_2.setOnClickListener {
            onBackPressed()
        }
        if (!BuildConfig.DEBUG) {
            et_account.text = null
            et_pwd.text = null
            et_pwd1.text = null
            et_secret_security.text = null
        }
    }


    //检测是否非法输入
    private fun illegal(): Boolean {
        val phone = et_account.text.toString()
        if (phone.length != 11) {
            ToastUtil.show("请输入正确的手机号")
            return true
        }
        val secretSecurity = et_secret_security.text.toString()
        if (TextUtils.isEmpty(secretSecurity)) {
            ToastUtil.show(et_secret_security.hint.toString())
            return true
        }
        val pwd = et_pwd.text.toString()
        if (TextUtils.isEmpty(pwd)) {
            ToastUtil.show(et_pwd.hint.toString())
            return true
        }
        if (pwd.length < 6) {
            ToastUtil.show("密码至少6位")
            return true
        }
        val pwd1 = et_pwd1.text.toString()
        if (TextUtils.isEmpty(pwd1)) {
            ToastUtil.show(et_pwd1.hint.toString())
            return true
        }
        if (!TextUtils.equals(pwd, pwd1)) {
            ToastUtil.show("两次密码输入不一致，请重新输入")
            return true
        }

        return false
    }


    private fun retrievePassword() {
        if (illegal()) {
            return
        }
        showProgress()
        val phone = et_account.text.toString()
        val pwd = et_pwd.text.toString()
        val secretSecurity = et_secret_security.text.toString()
        val params = hashMapOf<String, Any>()
        params["phone"] = phone
        params["secret"] = secretSecurity
        params["newpwd"] = pwd
        getApiService()
            .retrievePassword(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<NULL>() {
                override fun success(t: NULL) {
                    dismissProgress()
                    ToastUtil.show("密码找回成功，快去登录吧")
                    finish()
                }

                override fun error(msg: String?, code: Int) {
                    super.error(msg, code)
                    dismissProgress()
                }
            })
    }


    override fun onBackPressed() {
        finish()
    }
}