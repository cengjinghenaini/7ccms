package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class QQUser implements Serializable {

    /**
     * ret : 0
     * openid : B34935C23F80619A23CC54E826B67CB0
     * access_token : 229C5ADA4D704319184DAD514BD02FF7
     * pay_token : CE3A7F9652FE71875A0341264B9985FB
     * expires_in : 7776000
     * code :
     * proxy_code :
     * proxy_expires_in : 0
     * pf : desktop_m_qq-10000144-android-2002-
     * pfkey : a6aa3a79ce12611355a84a25ac1c5029
     * msg :
     * login_cost : 45
     * query_authority_cost : -202396991
     * authority_cost : 0
     * expires_time : 1615196008137
     */

    private long ret;
    private String access_token;
    private String pay_token;
    private long expires_in;
    private String code;
    private String proxy_code;
    private long proxy_expires_in;
    private String pf;
    private String pfkey;
    private String msg;
    private long login_cost;
    private long query_authority_cost;
    private int authority_cost;
    private long expires_time;
    protected String openid;

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public void setRet(long ret) {
        this.ret = ret;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public void setPay_token(String pay_token) {
        this.pay_token = pay_token;
    }

    public void setExpires_in(long expires_in) {
        this.expires_in = expires_in;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setProxy_code(String proxy_code) {
        this.proxy_code = proxy_code;
    }

    public void setProxy_expires_in(long proxy_expires_in) {
        this.proxy_expires_in = proxy_expires_in;
    }

    public void setPf(String pf) {
        this.pf = pf;
    }

    public void setPfkey(String pfkey) {
        this.pfkey = pfkey;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setLogin_cost(long login_cost) {
        this.login_cost = login_cost;
    }

    public void setQuery_authority_cost(long query_authority_cost) {
        this.query_authority_cost = query_authority_cost;
    }

    public void setAuthority_cost(int authority_cost) {
        this.authority_cost = authority_cost;
    }

    public long getRet() {
        return ret;
    }

    public String getAccess_token() {
        return access_token;
    }

    public String getPay_token() {
        return pay_token;
    }

    public long getExpires_in() {
        return expires_in;
    }

    public String getCode() {
        return code;
    }

    public String getProxy_code() {
        return proxy_code;
    }

    public long getProxy_expires_in() {
        return proxy_expires_in;
    }

    public String getPf() {
        return pf;
    }

    public String getPfkey() {
        return pfkey;
    }

    public String getMsg() {
        return msg;
    }

    public long getLogin_cost() {
        return login_cost;
    }

    public long getQuery_authority_cost() {
        return query_authority_cost;
    }

    public int getAuthority_cost() {
        return authority_cost;
    }

    public long getExpires_time() {
        return expires_time;
    }

    @Override
    public String toString() {
        return "QQUser{" +
                "ret=" + ret +
                ", access_token='" + access_token + '\'' +
                ", pay_token='" + pay_token + '\'' +
                ", expires_in=" + expires_in +
                ", code='" + code + '\'' +
                ", proxy_code='" + proxy_code + '\'' +
                ", proxy_expires_in=" + proxy_expires_in +
                ", pf='" + pf + '\'' +
                ", pfkey='" + pfkey + '\'' +
                ", msg='" + msg + '\'' +
                ", login_cost=" + login_cost +
                ", query_authority_cost=" + query_authority_cost +
                ", authority_cost=" + authority_cost +
                ", expires_time=" + expires_time +
                '}';
    }

    public void setExpires_time(long expires_time) {
        this.expires_time = expires_time;
    }
}
