package com.xizhu.qiyou;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.multidex.MultiDex;

import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.connection.FileDownloadUrlConnection;
import com.scwang.smart.refresh.footer.ClassicsFooter;
import com.scwang.smart.refresh.header.ClassicsHeader;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;
import com.tencent.bugly.Bugly;
import com.tencent.mmkv.MMKV;
import com.umeng.analytics.MobclickAgent;
import com.umeng.commonsdk.UMConfigure;
import com.xizhu.qiyou.service.ForegroundService;
import com.xizhu.qiyou.util.AppConfig;
import com.xizhu.qiyou.util.LogUtil;
import com.xizhu.qiyou.util.PhoneUtil;


public class QiYouApp extends Application {
    //    public static final String GLOBAL_SETTING = "gb_setting";
//    public static final String KEY_4G = "allow_4g";
    private static final String TAG = "QiYouApp";
    private double mActivityCount;
//    public boolean mAllow4G = false;

    //static 代码段可以防止内存泄露
    static {
        SmartRefreshLayout.setDefaultRefreshInitializer((context, layout) -> {
            layout.setEnableLoadMore(false);
            layout.setEnableAutoLoadMore(true);
            layout.setPrimaryColorsId(R.color.white, R.color.color_66);//全局设置主题颜色
        });
        //设置全局的Header构建器
        SmartRefreshLayout.setDefaultRefreshHeaderCreator((context, layout) -> {
            return new ClassicsHeader(context);//.setTimeFormat(new DynamicTimeFormat("更新于 %s"));//指定为经典Header，默认是 贝塞尔雷达Header
        });
        //设置全局的Footer构建器
        SmartRefreshLayout.setDefaultRefreshFooterCreator((context, layout) -> {
            //指定为经典Footer，默认是 BallPulseFooter
            return new ClassicsFooter(context).setDrawableSize(20);
        });
    }

    @Override
    public void onCreate() {
        super.onCreate();
        AppConfig.init(this);
//        全局异常捕获
//        setDefaultCaught();

        if (PhoneUtil.getSpMode(this)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
        // buildConfigField('String', "UMConfigure", '"5ff5185c44bb94418a75ad5d"')
//        //友盟 新6066d3b8de41b946ab3bb7ef  旧5ff5185c44bb94418a75ad5d
        UMConfigure.init(this, "5ff5185c44bb94418a75ad5d", "Umeng", UMConfigure.DEVICE_TYPE_PHONE, "");
        MobclickAgent.setPageCollectionMode(MobclickAgent.PageMode.AUTO);
        Bugly.init(this, "62273b747f", BuildConfig.DEBUG);
//        SharedPreferences sp = getSharedPreferences(GLOBAL_SETTING, Context.MODE_PRIVATE);
//        mAllow4G = sp.getBoolean(KEY_4G, false);
        FileDownloader.setupOnApplicationOnCreate(this)
                .connectionCreator(new FileDownloadUrlConnection
                        .Creator(new FileDownloadUrlConnection.Configuration()
                        .connectTimeout(15_000) // set connection timeout.
                        .readTimeout(15_000) // set read timeout.
                )).commit();
        //检测是否前台,开启前台服务保活
//        getAppBackground();
        String rootDir = MMKV.initialize(this);
        System.out.println("mmkv root: " + rootDir);
    }


    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }


    private void setDefaultCaught() {
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            LogUtil.e("test-->log++++++" + e.getMessage());
            e.printStackTrace();
//            restartApplication(this);
//            Thread.getDefaultUncaughtExceptionHandler().uncaughtException(t,e);
        });
    }

    //重启
    private void restartApplication(Context context) {
        final Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        android.os.Process.killProcess(android.os.Process.myPid());
    }

    private void getAppBackground() {
        Intent intent = new Intent(QiYouApp.this, ForegroundService.class);

        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

            }

            @Override
            public void onActivityStarted(Activity activity) {
                mActivityCount++;
                if (mActivityCount >= 1) {
                    stopService(intent);
                }
            }

            @Override
            public void onActivityResumed(Activity activity) {

            }

            @Override
            public void onActivityPaused(Activity activity) {

            }

            @Override
            public void onActivityStopped(Activity activity) {
                mActivityCount--;
                if (mActivityCount == 0) {
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.O) {
                        startForegroundService(intent);
                    } else {
                        startService(intent);
                    }
                }
            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

            }

            @Override
            public void onActivityDestroyed(Activity activity) {

            }
        });
    }
}
