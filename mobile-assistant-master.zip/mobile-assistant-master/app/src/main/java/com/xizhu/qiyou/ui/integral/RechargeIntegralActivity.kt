package com.xizhu.qiyou.ui.integral

import android.text.Html
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import androidx.core.content.ContextCompat
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.UserIntegral
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.util.DialogUtils
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.util.dialog.ToastUtil
import kotlinx.android.synthetic.main.activity_recharge_integral.*
import kotlinx.android.synthetic.main.title_layout.*

class RechargeIntegralActivity : BaseCompatActivity() {
    override fun getRes(): Int {
        return R.layout.activity_recharge_integral
    }

    override fun initView() {
        iv_back.setOnClickListener {
            finish()
        }
        tv_recharge.setOnClickListener {
            addUserIntegral()
        }
        tv_buy.setOnClickListener {
            getBuyUrl()
        }
        tv_page_title.text = "积分充值"
    }

    override fun initData() {
        super.initData()
        getPageContent()
    }

    private fun getPageContent() {
        val params = hashMapOf<String, Any>()
        params["type"] = "11"
        getApiService()
            .getPageContent(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<Map<String, String>>() {
                override fun success(t: Map<String, String>) {
                    val content = t["content"]
                    tv_des.text = Html.fromHtml(content, Html.FROM_HTML_MODE_LEGACY)
                }
            })
    }

    private fun getBuyUrl() {
        showProgress()
        val params = hashMapOf<String, Any>()
        val key = "card_buy_link"
        params["fields"] = key
        getApiService()
            .getH5Url(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<Map<String, String>>() {
                override fun success(t: Map<String, String>) {
                    dismissProgress()
                    if (t.isNotEmpty()) {
                        JumpUtils.jumpToWeb(this@RechargeIntegralActivity, t[key])
                    } else {
                        ToastUtil.show("未获取到充值地址 , 请重试")
                    }
                }

                override fun error(msg: String?, code: Int) {
                    super.error(msg, code)
                    dismissProgress()
                }
            })
    }


    private fun addUserIntegral() {
        if (TextUtils.isEmpty(et_pwd.text.toString())) {
            ToastUtil.show("卡密不能为空")
            return
        }
        if (UserMgr.isLogin()) {
            showProgress()
            val uid = UserMgr.getUid()
            HttpUtil.getInstance().addUserIntegral(
                uid,
                et_pwd.text.toString().trim { it <= ' ' },
                object : ResultCallback<UserIntegral>() {
                    override fun onSuccess(userIntegral: ResultEntity<UserIntegral>) {
                        dismissProgress()
                        val integralStr = "${userIntegral.data.integral}积分"
                        val message = "您充值的${integralStr}已到账，请注意查收，如有问题请联系客服。"
                        val spannable = SpannableString(message)
                        val pinkColor = ContextCompat.getColor(
                            this@RechargeIntegralActivity,
                            R.color.color_main_pink
                        )
                        spannable.setSpan(
                            ForegroundColorSpan(pinkColor),
                            spannable.indexOf(integralStr),
                            spannable.indexOf(integralStr) + integralStr.length,
                            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                        )
                        DialogUtils.showTipsDialog(
                            this@RechargeIntegralActivity,
                            message = spannable
                        )
                    }

                    override fun onFailure(err: String, code: Int) {
                        super.onFailure(err, code)
                        ToastUtil.show(err)
                        dismissProgress()
                    }
                })
        }
    }
}