package com.xizhu.qiyou.config;

public class Constant {

    public static final int CODE_TIME = 60;

    public static final int SUCCESS = 0;
    public static final int FAIL = -1;
    public static final int NO_DATA = 0;
    public static final int BACKGROUND_SPACE = 0;
    public static final int MY_THEME = 1;
    public static final int FOLLOW = 0;
    public static final int FANS = 1;
    public static final int GAME = 0;
    public static final int GAME_SPECIAL = 3;
    public static final int RES_SPECIAL = 4;
    public static final int VM = 2;
    public static final int GAME_UP = 0;
    public static final int GAME_INSTALL = 1;
    public static final int GAME_ORDER = 2;
    public static final int GAME_DOWNLOAD = 3;
    public static final int GAME_UNINSTALL = -1;
    public static final int CHOICE_GAME = 4;
    public static final int CHOICE_CATE = 5;
    public static final int CHOICE_LABEL = 6;
    public static final int CHOICE_RES = 7;
    public static final int CHOICE_TAIL = 8;
    public static final int CHOICE_POINT = 9;
    public static final int SET_HEAD = 0;
    public static final int SET_NAME = 1;
    public static final int SET_DESC = 2;
    public static final int SET_SEX = 4;
    public static final int SET_AGE = 5;
    public static final int SET_EMAIL = 6;
    public static final int SET_PWD = 7;
    public static final int SET_PHONE = 8;
    public static final int FIND_PWD = 9;

    public static final int PERMISSION_REQUEST = 0;
    public static final int CHOICE_PHOTO = 0;
    public static final int CHOICE_VIDEO = 1;

    public static final int WRITE_SHEET = 0;
    public static final int WRITE_APP = 1;
    public static final int GAME_COLLECT = 0;

    public static final int RING_PHONE = 0;
    public static final int RING_MSG = 1;
    public static final int RING_NAOZHONG = 2;

    public static final int SHARE_REC = 0;
    public static final int SHARE_NEW = 1;
    public static final int SHARE_BILL = 2;

    public static final int DOWN = 0;
    public static final int COLLECT = 1;


    //评论
    public static final int COMMENT_APP = 0;
    public static final int COMMENT_SHEET = 1;
    public static final int COMMENT_REC_APP = 2;
    public static final int COMMENT_RES_SPECIAL = 3;
    public static final int COMMENT_POINT = 4;


    //举报
    public static final String REPORT_APP = "0";
    public static final String REPORT_POINT = "1";
    public static final String REPORT_USER = "2";
    public static final String REPORT_COMMENT = "3";


    //评论时必填；0.应用评论，1.帖子评论，2.游戏单评论，3.专题评论，4.单款游戏推荐评论
    //举报
    public static final String REPORT_APP_COMMENT = "0";
    public static final String REPORT_POINT_COMMENT = "1";
    public static final String REPORT_SHEET_COMMENT = "2";
    public static final String REPORT_SEPCIAL_COMMENT = "3";
    public static final String REPORT_REC_COMMENT = "4";


    public static final int RECYCLER = 1;


    public static final int DAREN_QIANDAO = 0;
    public static final int DAREN_SHOUHUO = 1;


    // 0.游戏单，1.铃声，2.应用，3.帖子
    public static final String Collect_sheet = "0";
    public static final String Collect_ring = "1";
    public static final String Collect_app = "2";
    public static final String Collect_point = "3";


    // 0.游戏单，1.单款游戏推荐，2.帖子，3.专题评论，4.应用评论，5.单款游戏推荐评论，6.游戏单评论，7.帖子评论
    public static final String Zan_sheet = "0";
    public static final String Zan_rec_game = "1";
    public static final String Zan_point = "2";
    public static final String Zan_special_comment = "3";
    public static final String Zan_app_comment = "4";
    public static final String Zan_rec_game_comment = "5";
    public static final String Zan_sheet_comment = "6";
    public static final String Zan_point_comment = "7";

    //0 用户 1 板块
    public static final String attention_user = "0";
    public static final String attention_forum = "1";


    // 浏览记录 0.应用，1.帖子
    public static final String Record_app = "0";
    public static final String Record_point = "1";

    //0.游戏，1.软件，应用时要传
    public static final String Record_app_app = "1";
    public static final String Record_app_game = "0";

    //0.全部，1.游戏，2.软件
    public static final String searchAppType_all = "0";
    public static final String searchAppType_game = "1";
    public static final String searchAppType_app = "2";

    //0.服务条款，1.隐私协议，2.分享协议，3.达人堂说明，4.邀请须知，5.评价须知，6.推荐须知，7.等级经验说明，8.客服QQ
    public static final String FUWU = "0";
    public static final String YINSI = "1";
    public static final String FENXIANG = "2";
    public static final String DARENTANG = "3";
    public static final String YAOQING = "4";
    public static final String PINGJIA = "5";
    public static final String TUIJAIN = "6";
    public static final String DENGJI = "7";
    public static final String KEFUQQ = "8";

    //0.正序，1.倒序，2.只看楼主
    public static final String POINT_ZHENGXU = "0";
    public static final String POINT_DAOXU = "1";
    public static final String POINT_ZHIKANLOUZHU = "2";

    //0.微信，1.QQ
    public static final String LOGIN_BY_WX = "0";
    public static final String LOGIN_BY_QQ = "1";

    //微信登录还是绑定
    public static boolean WX_IS_BIND;

    //话题排序 0.最热，1.最新
    public static final String ORDER_BY_HOT = "0";
    public static final String ORDER_BY_NEW = "1";

    //0.游戏，1.软件(资源工具)，2.模拟器  分类
    public static final String CATE_GAME = "0";
    public static final String CATE_TOOL = "1";
    public static final String CATE_MONIQI = "2";

    //发帖类型
    public static final String SEND_TUWEN = "1";
    public static final String SEND_JIUGONG = "2";
    public static final String SEND_VIDEO = "3";
    public static final String SEND_GONGGAO = "4";

    //是否公告
    public static final String IS_GONGGAO_NO = "0";
    public static final String IS_GONGGAO_YES = "1";


    //分页大小
    public static final String PAGE = "1";
    public static final String PAGE_SIZE = "20";
    public static final String PAGE_MAX_SIZE = "9999";

    public static final int SEND_POINT = 888;
    public static final int CLOSE = 9999;
}
