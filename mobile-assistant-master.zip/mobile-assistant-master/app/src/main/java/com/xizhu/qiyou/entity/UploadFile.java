package com.xizhu.qiyou.entity;

public class UploadFile {

    /**
     * key : file
     * originUrl : /Uploads/Picture/20201105/9fa749de16bb4016.png
     * smallUrl : /Uploads/Picture/20201105/s_9fa749de16bb4016.png
     * id : 0f39f81ded6265b3dab2c4ad49213c82
     * size : 3495
     * show_url : http://www.7you.cn/Uploads/Picture/20201105/s_9fa749de16bb4016.png
     */
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
