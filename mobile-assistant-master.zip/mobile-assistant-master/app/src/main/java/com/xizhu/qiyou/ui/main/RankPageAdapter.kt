package com.xizhu.qiyou.ui.main

import android.content.Context
import com.chad.library.adapter.base.BaseProviderMultiAdapter
import com.xizhu.qiyou.R
import com.xizhu.qiyou.ui.main.provider.RankPageEmptyProvider
import com.xizhu.qiyou.ui.main.provider.RankPageOtherProvider
import com.xizhu.qiyou.ui.main.provider.RankPageTopThreeProvider

class RankPageAdapter(mContext:Context) : BaseProviderMultiAdapter<Any>() {

    companion object {
        const val TYPE_EMPTY = 1
        const val TYPE_ONE = 1
        const val TYPE_TWO = 2
        const val TYPE_THREE = 3
        const val TYPE_OTHER = 4
    }

    init {
        addItemProvider(RankPageEmptyProvider())
        addItemProvider(RankPageTopThreeProvider(TYPE_ONE, R.layout.item_recy_game_rank_one))
        addItemProvider(RankPageTopThreeProvider(TYPE_TWO, R.layout.item_recy_game_rank_two))
        addItemProvider(RankPageTopThreeProvider(TYPE_THREE, R.layout.item_recy_game_rank_three))
        addItemProvider(RankPageOtherProvider(mContext))
    }

    override fun getItemType(data: List<Any>, position: Int): Int {
        val item = data[position]
        return when {
            item is String -> {
                TYPE_EMPTY
            }
            position == 0 -> {
                TYPE_TWO
            }
            position == 1 -> {
                TYPE_ONE
            }
            position == 2 -> {
                TYPE_THREE
            }
            else -> {
                TYPE_OTHER
            }
        }
    }
}