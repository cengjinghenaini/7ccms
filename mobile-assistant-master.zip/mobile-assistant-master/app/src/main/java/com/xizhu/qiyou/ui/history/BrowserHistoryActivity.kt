package com.xizhu.qiyou.ui.history

import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.scwang.smart.refresh.layout.api.RefreshLayout
import com.scwang.smart.refresh.layout.listener.OnRefreshLoadMoreListener
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.BaseApp
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.widget.EmptyView
import kotlinx.android.synthetic.main.activity_browser_history.*
import kotlinx.android.synthetic.main.title_layout.*

class BrowserHistoryActivity : BaseCompatActivity() {
    private var adapter: BrowserHistoryAdapter? = null
    private var pageNum = 1


    override fun getRes(): Int {
        return R.layout.activity_browser_history
    }

    override fun initView() {
        iv_back.setOnClickListener {
            finish()
        }
        tv_page_title.text = "历史记录"
        refresh_layout?.setOnRefreshLoadMoreListener(object : OnRefreshLoadMoreListener {
            override fun onRefresh(refreshLayout: RefreshLayout) {
                pageNum = 1
                getHistoryList()
            }

            override fun onLoadMore(refreshLayout: RefreshLayout) {
                pageNum++
                getHistoryList()
            }
        })
        empty_view?.setLoadListener {
            pageNum = 1
            getHistoryList()
        }
        recycler.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        adapter = BrowserHistoryAdapter().apply {
            setEmptyView(EmptyView(this@BrowserHistoryActivity).setNoData())
            setOnItemClickListener { _, _, position ->
                val item = getItem(position)
                JumpUtils.jumpToGameDetailsPage(this@BrowserHistoryActivity,item.id)
            }
        }
        recycler.adapter = adapter
    }

    override fun initData() {
        super.initData()
        getHistoryList()
    }

    private fun getHistoryList() {
        val uid = UserMgr.getUid()
        HttpUtil.getInstance().getLookRecord(
            uid,
            Constant.Record_app,
            "0",
            pageNum,
            Constant.PAGE_SIZE.toInt(),
            object : ResultCallback<MutableList<BaseApp>>() {
                override fun onSuccess(s: ResultEntity<MutableList<BaseApp>>) {
                    val data = s.data
                    if (pageNum == 1) {
                        adapter?.setNewInstance(data)
                    } else {
                        adapter?.addData(data)
                    }
                    if (data.size >= Constant.PAGE_SIZE.toInt()) {
                        refresh_layout?.setEnableLoadMore(true)
                    } else {
                        refresh_layout?.setEnableLoadMore(false)
                    }
                    refresh_layout?.finishRefresh()
                    refresh_layout?.finishLoadMore()
                    empty_view?.visibility = View.GONE
                }

                override fun onFailure(err: String?, code: Int) {
                    super.onFailure(err, code)
                    if (empty_view?.visibility == View.VISIBLE) {
                        empty_view?.setLoadFail()
                    }
                    refresh_layout?.setEnableLoadMore(false)
                    refresh_layout?.finishRefresh(false)
                    refresh_layout?.finishLoadMore(false)
                    if (pageNum > 1) {
                        pageNum--
                    }
                }
            })

    }
}