package com.xizhu.qiyou.entity;

public class State {
    @Override
    public String toString() {
        return "StateBean{" +
                "code=" + code +
                ", msg='" + msg + '\'' +
                ", debugMsg='" + debugMsg + '\'' +
                ", url='" + url + '\'' +
                '}';
    }

    /**
     * code : 0
     * msg :
     * debugMsg :
     * url : Api/Home/getBigPicture
     */

    private int code;
    private String msg;
    private String debugMsg;
    private String url;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getDebugMsg() {
        return debugMsg;
    }

    public void setDebugMsg(String debugMsg) {
        this.debugMsg = debugMsg;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
