package com.xizhu.qiyou.apps;

/**
 * @ClassName UnzipEvent
 * @Description 解压缩进度
 * @Author guchu
 * @Date 2021/8/16 22:15
 * @Version 1.0
 */
public class UnzipEvent {
    public final String dstPath;
    public final long totalSize;
    public final long unzippedSize;
    public boolean isFail;

    public UnzipEvent(String dstPath, long totalSize, long unzippedSize) {
        this.dstPath = dstPath;
        this.totalSize = totalSize;
        this.unzippedSize = unzippedSize;
    }

    public UnzipEvent(String dstPath, long totalSize, long unzippedSize, boolean failed) {
        this.dstPath = dstPath;
        this.totalSize = totalSize;
        this.unzippedSize = unzippedSize;
        this.isFail = failed;
    }

    public String getDstPath() {
        return dstPath;
    }

    public long getTotalSize() {
        return totalSize;
    }

    public long getUnzippedSize() {
        return unzippedSize;
    }

    public boolean isFail() {
        return isFail;
    }
}
