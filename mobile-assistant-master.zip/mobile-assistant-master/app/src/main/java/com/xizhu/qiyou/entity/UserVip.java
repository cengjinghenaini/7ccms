package com.xizhu.qiyou.entity;

import java.util.List;

public class UserVip {


    /**
     * uid : 1
     * phone : 18254127300
     * email : 123@12.com
     * name :
     * wx_name :
     * qq :
     * head :
     * touxian_id :
     * touxian :
     * sex : 1
     * is_member :
     * age :
     * sign :
     * integral :
     * exp :
     * contribution :
     * grade_id :
     * grade_name :
     * member_start : 0
     * member_end : 0
     * member_price : 0
     */

    private String uid;
    private String phone;
    private String email;
    private String name;
    private String wx_name;
    private String qq;
    private String head;
    private String touxian_id;
    private String touxian;
    private String sex;
    private String is_member;
    private String age;
    private String sign;
    private String integral;
    private String exp;
    private String contribution;
    private String grade_id;
    private String grade_name;
    private String member_start;
    private String member_end;
    private String member_price;
    private List<Medal> medals;
    private String member_integral_price; // 0.交费购买，1.积分购买，2.交费+积分购买
    private String open_member_type;  //购买会员积分价格

    public String getMember_integral_price() {
        return member_integral_price;
    }

    public void setMember_integral_price(String member_integral_price) {
        this.member_integral_price = member_integral_price;
    }

    public String getOpen_member_type() {
        return open_member_type;
    }

    public void setOpen_member_type(String open_member_type) {
        this.open_member_type = open_member_type;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWx_name() {
        return wx_name;
    }

    public void setWx_name(String wx_name) {
        this.wx_name = wx_name;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public String getTouxian_id() {
        return touxian_id;
    }

    public void setTouxian_id(String touxian_id) {
        this.touxian_id = touxian_id;
    }

    public String getTouxian() {
        return touxian;
    }

    public void setTouxian(String touxian) {
        this.touxian = touxian;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getIs_member() {
        return is_member;
    }

    public void setIs_member(String is_member) {
        this.is_member = is_member;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getExp() {
        return exp;
    }

    public void setExp(String exp) {
        this.exp = exp;
    }

    public String getContribution() {
        return contribution;
    }

    public void setContribution(String contribution) {
        this.contribution = contribution;
    }

    public String getGrade_id() {
        return grade_id;
    }

    public void setGrade_id(String grade_id) {
        this.grade_id = grade_id;
    }

    public String getGrade_name() {
        return grade_name;
    }

    public void setGrade_name(String grade_name) {
        this.grade_name = grade_name;
    }

    public String getMember_start() {
        return member_start;
    }

    public void setMember_start(String member_start) {
        this.member_start = member_start;
    }

    public String getMember_end() {
        return member_end;
    }

    public void setMember_end(String member_end) {
        this.member_end = member_end;
    }

    public String getMember_price() {
        return member_price;
    }

    public void setMember_price(String member_price) {
        this.member_price = member_price;
    }

    public List<Medal> getMedals() {
        return medals;
    }

    public void setMedals(List<Medal> medals) {
        this.medals = medals;
    }
}
