package com.xizhu.qiyou.room.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.xizhu.qiyou.room.entity.ZipEntity;

import java.util.List;

@Dao
public interface ZipDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(ZipEntity zipEntity);

    @Query("select * from zips order by id desc")
    List<ZipEntity> queryAll();

    @Query("select * from zips where zipPath=(:zipPath)")
    ZipEntity findByZipPath(String zipPath);

    @Query("delete  from zips where zipPath=(:zipPath)")
    int deleteByZipPath(String zipPath);

    @Query("delete from zips")
    void delAll();

    @Update
    void update(ZipEntity zipEntity);
}
