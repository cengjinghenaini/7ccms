package com.xizhu.qiyou.entity;

public class MsgSystem {

    /**
     * id : value
     * uid : value
     * title : value
     * content : value
     * type : value
     * createtime : value
     * name : value
     * head : value
     * createtime_f : value
     */

    private String id;
    private String uid;
    private String title;
    private String content;
    private String type;
    private String createtime;
    private String name;
    private String head;
    private String createtime_f;


    @Override
    public String toString() {
        return "MsgSystem{" +
                "id='" + id + '\'' +
                ", uid='" + uid + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", type='" + type + '\'' +
                ", createtime='" + createtime + '\'' +
                ", name='" + name + '\'' +
                ", head='" + head + '\'' +
                ", createtime_f='" + createtime_f + '\'' +
                '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public String getCreatetime_f() {
        return createtime_f;
    }

    public void setCreatetime_f(String createtime_f) {
        this.createtime_f = createtime_f;
    }
}
