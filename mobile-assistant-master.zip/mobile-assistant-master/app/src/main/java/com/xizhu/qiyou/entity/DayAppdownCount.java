package com.xizhu.qiyou.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class DayAppdownCount implements Serializable, Parcelable {
    private int sum_count;
    private String usecount;

    protected DayAppdownCount(Parcel in) {
        sum_count = in.readInt();
        usecount = in.readString();
    }

    public static final Creator<DayAppdownCount> CREATOR = new Creator<DayAppdownCount>() {
        @Override
        public DayAppdownCount createFromParcel(Parcel in) {
            return new DayAppdownCount(in);
        }

        @Override
        public DayAppdownCount[] newArray(int size) {
            return new DayAppdownCount[size];
        }
    };

    public int getSum_count() {
        return sum_count;
    }

    public void setSum_count(int sum_count) {
        this.sum_count = sum_count;
    }

    public String getUsecount() {
        return usecount;
    }

    public void setUsecount(String usecount) {
        this.usecount = usecount;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(sum_count);
        dest.writeString(usecount);
    }
}
