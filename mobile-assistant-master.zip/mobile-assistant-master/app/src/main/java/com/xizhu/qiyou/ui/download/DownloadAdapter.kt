package com.xizhu.qiyou.ui.download

import android.view.View
import android.widget.ProgressBar
import androidx.core.content.ContextCompat
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.qmuiteam.qmui.layout.QMUIButton
import com.xizhu.qiyou.R
import com.xizhu.qiyou.room.entity.AppEntity
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.UnitUtil

class DownloadAdapter(private val shownUtil: GetShownMsg, private val type: Int) :
    BaseQuickAdapter<AppEntity, BaseViewHolder>(R.layout.item_recy_download_app) {
    override fun convert(holder: BaseViewHolder, item: AppEntity) {
        val tvInstall = holder.getView<QMUIButton>(R.id.tv_install)
        val gameProgress = holder.getView<ProgressBar>(R.id.pb_download)

        ImgLoadUtil.loadHead(holder.getView(R.id.iv_game_logo), item.icon)
        holder.setText(R.id.tv_game_name, item.name)
        holder.setText(
            R.id.tv_size,
            "${UnitUtil.zao(item.size.toString())}  评分${item.score ?: "暂无"}"
        )
        val shownMsgs: Array<String> = shownUtil.getShownMsg(item)
        gameProgress.visibility = if (type == 0) View.VISIBLE else View.GONE
        gameProgress.progress = shownMsgs[2].toInt()
        val statusInfo = shownMsgs[0]
        if (statusInfo == "下载中") {
            tvInstall.text = "${shownMsgs[2]}%"
        } else {
            tvInstall.text = shownMsgs[0]
        }
    }

    interface GetShownMsg {
        fun getShownMsg(appEntity: AppEntity?): Array<String>
    }
}