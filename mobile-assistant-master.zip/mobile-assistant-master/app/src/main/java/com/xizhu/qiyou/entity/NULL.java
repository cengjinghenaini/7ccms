package com.xizhu.qiyou.entity;

public class NULL {

}
