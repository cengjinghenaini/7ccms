package com.xizhu.qiyou.entity.Events;

import java.io.File;

public class FileRing {

    File file;
    int type;

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public FileRing(File file, int typeAlarm) {
        this.file = file;
        this.type = typeAlarm;
    }
}
