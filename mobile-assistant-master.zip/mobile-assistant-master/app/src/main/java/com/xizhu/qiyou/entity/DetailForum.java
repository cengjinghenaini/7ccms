package com.xizhu.qiyou.entity;

import java.util.List;

public class DetailForum {

    /**
     * forum : {"name":"1","id":"","icon":"","hot_count":"","gambit_count":"","is_attention":"","is_signin":""}
     * forum_host : [{"uid":"1","phone":"18254127300","email":"123@12.com","name":"","wx_name":"","qq":"","head":"","touxian_id":"","touxian":"","sex":"1","is_member":"","age":"","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":""}]
     * posts : [{"id":"","title":"","is_top":"","is_gonggao":""}]
     */

    private Forum forum;
    private List<ForumHost> forum_host;
    private List<Point> posts;

    public Forum getForum() {
        return forum;
    }

    public void setForum(Forum forum) {
        this.forum = forum;
    }

    public List<ForumHost> getForum_host() {
        return forum_host;
    }

    public void setForum_host(List<ForumHost> forum_host) {
        this.forum_host = forum_host;
    }

    public List<Point> getPosts() {
        return posts;
    }

    public void setPosts(List<Point> posts) {
        this.posts = posts;
    }


}
