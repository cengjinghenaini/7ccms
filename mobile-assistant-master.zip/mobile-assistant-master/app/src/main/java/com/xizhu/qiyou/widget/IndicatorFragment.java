package com.xizhu.qiyou.widget;

import androidx.fragment.app.Fragment;

public class IndicatorFragment {
    public String title;
    public Fragment fragment;

    public IndicatorFragment(String title, Fragment fragment) {
        this.title = title;
        this.fragment = fragment;
    }
}
