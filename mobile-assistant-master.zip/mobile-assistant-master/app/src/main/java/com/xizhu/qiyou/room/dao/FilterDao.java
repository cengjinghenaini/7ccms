package com.xizhu.qiyou.room.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.xizhu.qiyou.room.entity.Filter;

import java.util.List;

@Dao
public interface FilterDao {

    @Query("select * from filters order by id desc")
    List<Filter> queryAll();

    @Query("select * from filters where filter=(:filter)")
    Filter findByRaw(String filter);

    @Insert
    void insert(Filter filter);

    @Query("delete from filters where filter=(:raw)")
    void delByRaw(String raw);
    @Update
    void update(Filter filter);
}
