package com.xizhu.qiyou.http.request;

import android.text.TextUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import okhttp3.Request;


public class GetHelper extends ReqHelper {
    @Override
    public Request createReq() {
        StringBuilder param = new StringBuilder();
        for (String key : getParams().keySet()) {
            param.append(key)
                    .append("=")
                    .append(getParams().get(key))
                    .append("&");
        }

        String encode;
        try {
            encode = URLEncoder.encode(param.toString(), "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            encode = "";
        }
        String url = getUrl();
        if (!TextUtils.isEmpty(encode)) {
            url = getUrl() + "?" + encode;
        }
        return new Request.Builder()
                .get().url(url)
                .build();
    }


}
