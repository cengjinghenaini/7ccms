package com.xizhu.qiyou.room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.xizhu.qiyou.room.dao.AppDao;
import com.xizhu.qiyou.room.dao.ConfigDao;
import com.xizhu.qiyou.room.dao.FilterDao;
import com.xizhu.qiyou.room.dao.RecordDao;
import com.xizhu.qiyou.room.dao.ReplaceDao;
import com.xizhu.qiyou.room.dao.TranslateRecordDao;
import com.xizhu.qiyou.room.dao.ZipDao;
import com.xizhu.qiyou.room.entity.AppEntity;
import com.xizhu.qiyou.room.entity.Filter;
import com.xizhu.qiyou.room.entity.Replace;
import com.xizhu.qiyou.room.entity.SearchRecord;
import com.xizhu.qiyou.room.entity.TranslateRecord;
import com.xizhu.qiyou.room.entity.TranslationConfig;
import com.xizhu.qiyou.room.entity.ZipEntity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


@Database(entities = {SearchRecord.class, TranslationConfig.class, Replace.class, Filter.class, TranslateRecord.class, ZipEntity.class, AppEntity.class},
        version = 6, exportSchema = true)
public abstract class AppDataBase extends RoomDatabase {
    /**
     * copyProgress  大zip文件解压后，obb文件移动也是特别耗费时间
     */
    public static final String SQL_CREATE_APP =
            "CREATE TABLE IF NOT EXISTS apps (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                    "appDesc TEXT,downloadUrl TEXT,icon TEXT,name TEXT," +
                    "realPackage TEXT,webPackage TEXT," +
                    "size bigint NOT NULL," +
                    "realVersion TEXT,webVersion TEXT," +
                    "downPath TEXT,downloadProgress INTEGER NOT NULL," +
                    "downSpeed INTEGER," +
                    "unzipPath TEXT,unzipProgress INTEGER NOT NULL," +
                    "unzipSpeed INTEGER," +
                    "queueTimeInMill bigint NOT NULL," +  //入队时间毫秒数（完成一项工作，下一次调度的时候使用）
                    "isWorking INTEGER NOT NULL," +     //当前任务正在处理中(不是在等待处理的队列中)
                    "isManualPaused INTEGER NOT NULL,isInstalled INTEGER NOT NULL)";

    public static final String SQL_APPS_ADD_COLUMN = "ALTER TABLE apps ADD COLUMN score TEXT ";

    private static volatile AppDataBase INSTANCE;

    static final Migration MIGRATION_4_5 = new Migration(4, 5) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // Since we didn't alter the table, there's nothing else to do here.
            database.execSQL(SQL_CREATE_APP);
        }
    };


    static final Migration MIGRATION_5_6 = new Migration(5, 6) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // Since we didn't alter the table, there's nothing else to do here.
            database.execSQL(SQL_APPS_ADD_COLUMN);
        }
    };

    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    // TODO 在实例化 AppDatabase 对象时应遵循单例设计模式。每个 RoomDatabase 实例的成本相当高，几乎不需要在单个进程中访问多个实例。
    public static AppDataBase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDataBase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), AppDataBase.class, "qiyou_v2.db")
                            .addMigrations(MIGRATION_4_5, MIGRATION_5_6)
                            // 默认不允许在主线程中连接数据库
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    public abstract RecordDao getRecordDao();

    public abstract ConfigDao getConfigDao();

    public abstract ReplaceDao getReplaceDao();

    public abstract FilterDao getFilterDao();

    public abstract TranslateRecordDao getTranslateRecordDao();

    public abstract ZipDao getZipDap();

    public abstract AppDao getAppDao();
}
