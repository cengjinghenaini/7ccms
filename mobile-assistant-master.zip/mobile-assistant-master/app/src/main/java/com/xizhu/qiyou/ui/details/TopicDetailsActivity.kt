package com.xizhu.qiyou.ui.details

import android.content.Context
import android.content.Intent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.DetailSpecial
import com.xizhu.qiyou.entity.Special
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.ui.search.SearchAdapter
import com.xizhu.qiyou.widget.EmptyView
import kotlinx.android.synthetic.main.activity_topic_details.*
import kotlinx.android.synthetic.main.title_layout.*

class TopicDetailsActivity : BaseCompatActivity() {
    private var special: Special? = null
    private var adapter: SearchAdapter? = null

    companion object {
        fun start(context: Context, special: Special? = null) {
            val intent = Intent(context, TopicDetailsActivity::class.java)
            intent.putExtra("special", special)
            context.startActivity(intent)
        }
    }

    override fun getRes(): Int {
        return R.layout.activity_topic_details
    }

    override fun initView() {
        special = intent.getSerializableExtra("special") as? Special
        iv_back.setOnClickListener {
            finish()
        }
        tv_page_title.text = special?.name
        refresh_layout.setOnRefreshListener {
            getTopicInfo()
        }
        recycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        adapter = SearchAdapter().apply {
            setEmptyView(EmptyView(this@TopicDetailsActivity).setNoData())
            setOnItemClickListener { _, _, position ->
                val item = getItem(position)
                JumpUtils.jumpToGameDetailsPage(this@TopicDetailsActivity,item.id)
            }
        }
        recycler.adapter = adapter
        empty_view.setLoadListener {
            empty_view.setLoading()
            getTopicInfo()
        }
    }

    override fun initData() {
        super.initData()
        getTopicInfo()
    }

    private fun getTopicInfo() {
        HttpUtil.getInstance()
            .getTopicInfo(special?.id, object : ResultCallback<DetailSpecial>() {
                override fun onSuccess(s: ResultEntity<DetailSpecial>) {
                    adapter?.setNewInstance(s.data?.apps)
                    refresh_layout?.finishRefresh()
                    empty_view?.visibility = View.GONE
                }

                override fun onFailure(err: String?, code: Int) {
                    super.onFailure(err, code)
                    if (empty_view?.visibility == View.VISIBLE) {
                        empty_view?.setLoadFail()
                    }
                    refresh_layout?.finishRefresh(false)
                }
            })
    }
}