package com.xizhu.qiyou.room.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "zips")
public class ZipEntity {


    @PrimaryKey(autoGenerate = true)
    @ColumnInfo
    int id;
    @ColumnInfo
    String filePath;
    @ColumnInfo
    String zipPath;

    public ZipEntity(String filePath, String zipPath) {
        this.filePath = filePath;
        this.zipPath = zipPath;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    @Override
    public String toString() {
        return "ZipEntity{" +
                "id=" + id +
                ", filePath='" + filePath + '\'' +
                ", zipPath='" + zipPath + '\'' +
                '}';
    }

    public String getZipPath() {
        return zipPath;
    }

    public void setZipPath(String zipPath) {
        this.zipPath = zipPath;
    }
}
