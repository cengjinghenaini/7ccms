package com.xizhu.qiyou.room.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "searchRecord")
public class SearchRecord {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    public int id;
    @ColumnInfo(name = "uid")
    public String uid;
    @ColumnInfo(name = "key_word")
    public String keyWord;
}
