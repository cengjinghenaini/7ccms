package com.xizhu.qiyou.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.List;

public class User implements Serializable, Parcelable {


    /**
     * uid : 1
     * phone : 18254127300
     * email : 123@12.com
     * name :
     * wx_name :
     * qq :
     * head :
     * touxian_id :
     * touxian :
     * sex : 1
     * is_member :
     * age :
     * sign :
     * integral :
     * exp :
     * contribution :
     * grade_id :
     * grade_name :
     * isRegister : 1
     * is_pwd : 1   是否设置密码
     */


    private String password;
    private String birthday;
    private String uid;
    private String phone;
    private String email;
    private String name;
    private String wx_name;
    private String qq;
    private String head;
    private String touxian_id;
    private String touxian;
    private String sex;
    private String is_member;
    private String age;
    private String sign;
    private String integral;
    private String exp;
    private String contribution;
    private String grade_id;
    private String grade_name;
    private int isRegister;
    private String is_pwd;
    private List<Medal> medals;
    private int is_attention;
    private int is_bind_wx;
    private int is_bind_qq;
    private String sh_count;
    private String sign_count;
    private Dress dress;
    private int touxian2_id;
    private String touxian2;
    private int is_sign;
    private DayAppdownCount day_appdown;

    public User() {

    }


    protected User(Parcel in) {
        password = in.readString();
        birthday = in.readString();
        uid = in.readString();
        phone = in.readString();
        email = in.readString();
        name = in.readString();
        wx_name = in.readString();
        qq = in.readString();
        head = in.readString();
        touxian_id = in.readString();
        touxian = in.readString();
        sex = in.readString();
        is_member = in.readString();
        age = in.readString();
        sign = in.readString();
        integral = in.readString();
        exp = in.readString();
        contribution = in.readString();
        grade_id = in.readString();
        grade_name = in.readString();
        isRegister = in.readInt();
        is_pwd = in.readString();
        is_attention = in.readInt();
        is_bind_wx = in.readInt();
        is_bind_qq = in.readInt();
        sh_count = in.readString();
        sign_count = in.readString();
        touxian2_id = in.readInt();
        touxian2 = in.readString();
        is_sign = in.readInt();
        day_appdown = in.readParcelable(DayAppdownCount.class.getClassLoader());
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(password);
        dest.writeString(birthday);
        dest.writeString(uid);
        dest.writeString(phone);
        dest.writeString(email);
        dest.writeString(name);
        dest.writeString(wx_name);
        dest.writeString(qq);
        dest.writeString(head);
        dest.writeString(touxian_id);
        dest.writeString(touxian);
        dest.writeString(sex);
        dest.writeString(is_member);
        dest.writeString(age);
        dest.writeString(sign);
        dest.writeString(integral);
        dest.writeString(exp);
        dest.writeString(contribution);
        dest.writeString(grade_id);
        dest.writeString(grade_name);
        dest.writeInt(isRegister);
        dest.writeString(is_pwd);
        dest.writeInt(is_attention);
        dest.writeInt(is_bind_wx);
        dest.writeInt(is_bind_qq);
        dest.writeString(sh_count);
        dest.writeString(sign_count);
        dest.writeInt(touxian2_id);
        dest.writeString(touxian2);
        dest.writeInt(is_sign);
        dest.writeParcelable(day_appdown, flags);
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWx_name() {
        return wx_name;
    }

    public void setWx_name(String wx_name) {
        this.wx_name = wx_name;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public String getTouxian_id() {
        return touxian_id;
    }

    public void setTouxian_id(String touxian_id) {
        this.touxian_id = touxian_id;
    }

    public String getTouxian() {
        return touxian;
    }

    public void setTouxian(String touxian) {
        this.touxian = touxian;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getIs_member() {
        return is_member;
    }

    public void setIs_member(String is_member) {
        this.is_member = is_member;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getExp() {
        return exp;
    }

    public void setExp(String exp) {
        this.exp = exp;
    }

    public String getContribution() {
        return contribution;
    }

    public void setContribution(String contribution) {
        this.contribution = contribution;
    }

    public String getGrade_id() {
        return grade_id;
    }

    public void setGrade_id(String grade_id) {
        this.grade_id = grade_id;
    }

    public String getGrade_name() {
        return grade_name;
    }

    public void setGrade_name(String grade_name) {
        this.grade_name = grade_name;
    }

    public int getIsRegister() {
        return isRegister;
    }

    public void setIsRegister(int isRegister) {
        this.isRegister = isRegister;
    }

    public String getIs_pwd() {
        return is_pwd;
    }

    public void setIs_pwd(String is_pwd) {
        this.is_pwd = is_pwd;
    }

    public List<Medal> getMedals() {
        return medals;
    }

    public void setMedals(List<Medal> medals) {
        this.medals = medals;
    }

    public int getIs_attention() {
        return is_attention;
    }

    public void setIs_attention(int is_attention) {
        this.is_attention = is_attention;
    }

    public int getIs_bind_wx() {
        return is_bind_wx;
    }

    public void setIs_bind_wx(int is_bind_wx) {
        this.is_bind_wx = is_bind_wx;
    }

    public int getIs_bind_qq() {
        return is_bind_qq;
    }

    public void setIs_bind_qq(int is_bind_qq) {
        this.is_bind_qq = is_bind_qq;
    }

    public String getSh_count() {
        return sh_count;
    }

    public void setSh_count(String sh_count) {
        this.sh_count = sh_count;
    }

    public String getSign_count() {
        return sign_count;
    }

    public void setSign_count(String sign_count) {
        this.sign_count = sign_count;
    }

    public Dress getDress() {
        return dress;
    }

    public void setDress(Dress dress) {
        this.dress = dress;
    }

    public int getTouxian2_id() {
        return touxian2_id;
    }

    public void setTouxian2_id(int touxian2_id) {
        this.touxian2_id = touxian2_id;
    }

    public String getTouxian2() {
        return touxian2;
    }

    public void setTouxian2(String touxian2) {
        this.touxian2 = touxian2;
    }

    public int getIs_sign() {
        return is_sign;
    }

    public void setIs_sign(int is_sign) {
        this.is_sign = is_sign;
    }

    public DayAppdownCount getDay_appdown() {
        return day_appdown;
    }

    public void setDay_appdown(DayAppdownCount day_appdown) {
        this.day_appdown = day_appdown;
    }
}
