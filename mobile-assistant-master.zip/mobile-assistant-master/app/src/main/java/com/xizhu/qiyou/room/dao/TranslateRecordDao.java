package com.xizhu.qiyou.room.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.xizhu.qiyou.room.entity.TranslateRecord;

import java.util.List;

@Dao
public interface TranslateRecordDao {

    @Insert
    void insert(TranslateRecord record);

    @Query("select * from translateRecord order by id desc")
    List<TranslateRecord> queryAll();

    @Query("select * from translateRecord where id=(:id)")
    TranslateRecord findById(int id);

    @Query("delete from translateRecord")
    void delAll();

    @Query("delete from translateRecord where id=(:id)")
    void delById(int id);

    @Update
    void update(TranslateRecord replace);
}
