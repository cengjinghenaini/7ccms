package com.xizhu.qiyou.ui.translation.entity;

public class FyCount {

    /**
     * sy : 8
     * shiyong : 2
     * bili : 1:10
     */

    private String sy;
    private String shiyong;
    private String bili;

    public String getSy() {
        return sy;
    }

    public void setSy(String sy) {
        this.sy = sy;
    }

    public String getShiyong() {
        return shiyong;
    }

    public void setShiyong(String shiyong) {
        this.shiyong = shiyong;
    }

    public String getBili() {
        return bili;
    }

    public void setBili(String bili) {
        this.bili = bili;
    }
}
