package com.xizhu.qiyou.entity;

public class SendComment {

    /**
     * id : value
     * rec_id : value
     * uid : value
     * zan_count : value
     * reply_count : value
     * phone_type : value
     * content : value
     * reply_id : value
     * createtime : value
     * reply_uid : value
     * reply_name : value
     * is_me : value
     * user : {"uid":"value","phone":"value","email":"value","name":"value","wx_name":"value","qq":"value","head":"value","touxian_id":"value","touxian":"value","sex":"value","is_member":"value","age":"value","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":"","medals":[{"id":"value","pic":"value","name":"value"}]}
     * createtime_f :
     */

    private String id;
    private String rec_id;
    private String uid;
    private String zan_count;
    private String reply_count;
    private String phone_type;
    private String content;
    private String reply_id;
    private String createtime;
    private String reply_uid;
    private String reply_name;
    private String is_me;
    private User user;
    private String createtime_f;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRec_id() {
        return rec_id;
    }

    public void setRec_id(String rec_id) {
        this.rec_id = rec_id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getZan_count() {
        return zan_count;
    }

    public void setZan_count(String zan_count) {
        this.zan_count = zan_count;
    }

    public String getReply_count() {
        return reply_count;
    }

    public void setReply_count(String reply_count) {
        this.reply_count = reply_count;
    }

    public String getPhone_type() {
        return phone_type;
    }

    public void setPhone_type(String phone_type) {
        this.phone_type = phone_type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getReply_id() {
        return reply_id;
    }

    public void setReply_id(String reply_id) {
        this.reply_id = reply_id;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getReply_uid() {
        return reply_uid;
    }

    public void setReply_uid(String reply_uid) {
        this.reply_uid = reply_uid;
    }

    public String getReply_name() {
        return reply_name;
    }

    public void setReply_name(String reply_name) {
        this.reply_name = reply_name;
    }

    public String getIs_me() {
        return is_me;
    }

    public void setIs_me(String is_me) {
        this.is_me = is_me;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getCreatetime_f() {
        return createtime_f;
    }

    public void setCreatetime_f(String createtime_f) {
        this.createtime_f = createtime_f;
    }

}
