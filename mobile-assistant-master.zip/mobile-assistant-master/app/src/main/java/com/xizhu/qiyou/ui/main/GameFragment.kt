package com.xizhu.qiyou.ui.main

import android.content.Context
import android.content.Intent
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat
import com.pass.util.DisplayUtil
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.ui.search.NewSearchActivity
import com.xizhu.qiyou.util.UnitUtil
import com.xizhu.qiyou.widget.IndicatorFragment
import com.xizhu.qiyou.widget.IndicatorViewPagerAdapter
import kotlinx.android.synthetic.main.fragment_game.*
import net.lucode.hackware.magicindicator.ViewPagerHelper
import net.lucode.hackware.magicindicator.buildins.UIUtil
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView
import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.ColorTransitionPagerTitleView

class GameFragment : BaseFragment() {
    private var commonNavigator: CommonNavigator? = null
    private val indicatorFragmentList = mutableListOf<IndicatorFragment>()

    override fun getRes(): Int {
        return R.layout.fragment_game
    }

    override fun initView() {
        super.initView()
        statusBar?.layoutParams?.height = UnitUtil.getStatusBarHeight(activity)
        tv_search_box?.setOnClickListener {
            startActivity(Intent(activity, NewSearchActivity::class.java))
        }
        my_game?.setOnClickListener {
            JumpUtils.jumpToDownloadManagerPage(context)
        }
        initMagicIndicator()
        createFragment()
    }

    private fun initMagicIndicator() {
        commonNavigator = CommonNavigator(context)
        commonNavigator?.isSkimOver = true
        commonNavigator?.adapter = object : CommonNavigatorAdapter() {

            override fun getCount(): Int {
                return indicatorFragmentList.size
            }

            override fun getTitleView(context: Context?, index: Int): IPagerTitleView? {
                val simplePagerTitleView = ColorTransitionPagerTitleView(context)
                simplePagerTitleView.text = indicatorFragmentList[index].title
                simplePagerTitleView.setPadding(
                    DisplayUtil.dip2px(context, 12f),
                    0,
                    DisplayUtil.dip2px(context, 12f),
                    0
                )
                simplePagerTitleView.normalColor =
                    ContextCompat.getColor(context!!, R.color.color_7c7c7c)
                simplePagerTitleView.selectedColor =
                    ContextCompat.getColor(context, R.color.color_main_pink)
                simplePagerTitleView.textSize = 18F
                simplePagerTitleView.setOnClickListener { view_pager?.currentItem = index }
                return simplePagerTitleView
            }

            override fun getIndicator(context: Context?): IPagerIndicator {
                val indicator = LinePagerIndicator(context)
                indicator.mode = LinePagerIndicator.MODE_EXACTLY
                indicator.lineHeight = UIUtil.dip2px(context, 4.0).toFloat()
                indicator.lineWidth = UIUtil.dip2px(context, 22.0).toFloat()
                indicator.roundRadius = UIUtil.dip2px(context, 2.0).toFloat()
                indicator.startInterpolator = AccelerateInterpolator()
                indicator.endInterpolator = DecelerateInterpolator(2.0f)
                indicator.setColors(ContextCompat.getColor(context!!, R.color.color_main_pink))
                return indicator
            }
        }
        magic_indicator?.navigator = commonNavigator
        if (magic_indicator != null && view_pager != null) {
            ViewPagerHelper.bind(magic_indicator, view_pager)
        }
    }


    private fun createFragment() {
        view_pager?.removeAllViewsInLayout()
        indicatorFragmentList.clear()
        indicatorFragmentList.add(
            IndicatorFragment(
                "最新",
                LastFragment()
            )
        )
        indicatorFragmentList.add(
            IndicatorFragment(
                "排行榜",
                RankFragment()
            )
        )
        indicatorFragmentList.add(
            IndicatorFragment(
                "分类",
                CategoryFragment()
            )
        )

        val indicatorViewPagerAdapter =
            IndicatorViewPagerAdapter(childFragmentManager, commonNavigator) { _, _ -> }
        indicatorViewPagerAdapter.setData(indicatorFragmentList)
        view_pager?.adapter = indicatorViewPagerAdapter
        view_pager?.currentItem = 0
        magic_indicator?.onPageSelected(0)
    }
}