package com.xizhu.qiyou.helper;

import android.graphics.drawable.Drawable;
import android.text.Html;

import java.net.URL;

public class ImgGet implements Html.ImageGetter {
    @Override
    public Drawable getDrawable(String source) {
        Drawable drawable = null;
        URL url;
        try {
            url = new URL(source);
            drawable = Drawable.createFromStream(url.openStream(), "");  //获取网路图片
        } catch (Exception e) {
            return null;
        }
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable
                .getIntrinsicHeight());
        return drawable;
    }
}
