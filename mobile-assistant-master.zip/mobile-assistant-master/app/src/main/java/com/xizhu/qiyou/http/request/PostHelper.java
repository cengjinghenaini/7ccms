package com.xizhu.qiyou.http.request;

import okhttp3.FormBody;
import okhttp3.Request;

public class PostHelper extends ReqHelper {
    @Override
    public Request createReq() {
        FormBody.Builder builder = new FormBody.Builder();
        for (String key : getParams().keySet()) {
            if (key == null) {
                break;
            }
            String s = getParams().get(key);
            builder.add(key, s == null ? "" : s);
        }
        FormBody formBody = builder.build();
        return new Request.Builder()
                .post(formBody).url(getUrl())
                .build();
    }
}