package com.xizhu.qiyou.room.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.xizhu.qiyou.room.entity.TranslationConfig;

@Dao
public interface ConfigDao {
    @Insert
    void insert(TranslationConfig config);
    @Update
    void update(TranslationConfig config);

    @Query("select * from translationConfig where id=(:id)")
    TranslationConfig queryById(int id);
}
