package com.xizhu.qiyou.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

public class EncryptUtil {

    public static String generateShareCode(String code,String appName) {
        return "我正在7c助手下载{"+appName+"}，快来下载7c助手<7c0.com>，复制传输码一起来下载吧！传输码：" + code;
    }

    public static String parseCode(String str) {
        int i = str.indexOf("：QY");
        if (i == -1 || str.length() < 18) return null;
        return str.substring(i + 1);
    }

    public static String generateCode() {
        String s = UUID.randomUUID().toString();
        String replace = s.replace("-", "");
        //D8132929EC5B361C  我分享了一个好玩的应用，打开七友助手即可下载：QY1FE5DB6B9BAED359
        return "QY" + md5(replace).substring(8, 24).toUpperCase();
    }


    private static String md5(String data) {
        try {
            byte[] md5 = md5(data.getBytes("utf-8"));
            return toHexString(md5);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return "";
    }


    private static byte[] md5(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("md5");
            return md.digest(data);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return new byte[]{};
    }

    private static String toHexString(byte[] md5) {
        StringBuilder sb = new StringBuilder();
        System.out.println("md5.length: " + md5.length);
        for (byte b : md5) {
            sb.append(Integer.toHexString(b & 0xff));
        }
        return sb.toString();
    }
}
