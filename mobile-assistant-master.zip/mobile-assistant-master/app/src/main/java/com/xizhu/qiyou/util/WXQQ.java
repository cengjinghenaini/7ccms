package com.xizhu.qiyou.util;

import android.content.Context;

import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.tencent.tauth.Tencent;
import com.xizhu.qiyou.config.WXQQConfig;

public class WXQQ {
    public static final String QQ_MUSIC_IMAGE = "http://47.108.140.231/Uploads/Picture/20201124/b241e012f3fc5a05.jpg";
    private static IWXAPI wxapi;
    private static Tencent tencent;
    public static void init(Context context){
        wxapi = WXAPIFactory.createWXAPI(context, WXQQConfig.APP_ID, false);
        tencent = Tencent.createInstance(WXQQConfig.QQ_APP_ID, context);
    }
    public static IWXAPI getWXAPI(){
        return wxapi;
    }
    public static Tencent getQQ(){
        return tencent;
    }
}
