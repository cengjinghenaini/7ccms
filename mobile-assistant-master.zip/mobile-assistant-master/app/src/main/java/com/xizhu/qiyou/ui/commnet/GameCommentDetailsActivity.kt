package com.xizhu.qiyou.ui.commnet

import android.content.Context
import android.content.Intent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.Comment
import com.xizhu.qiyou.entity.DetailGame
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.PopupUtils
import com.xizhu.qiyou.util.UnitUtil
import kotlinx.android.synthetic.main.activity_game_comment_details.*
import kotlinx.android.synthetic.main.header_game_comment_details.view.*
import kotlinx.android.synthetic.main.title_layout.*

class GameCommentDetailsActivity : BaseCompatActivity() {
    private var headerView: View? = null
    private var detailsGame: DetailGame? = null
    private var comment: Comment? = null
    private var adapter: GameCommentReplyAdapter? = null


    companion object {
        fun start(context: Context, detailGame: DetailGame, comment: Comment) {
            val intent = Intent(context, GameCommentDetailsActivity::class.java)
            intent.putExtra("detailsGame", detailGame)
            intent.putExtra("comment", comment)
            context.startActivity(intent)
        }
    }

    override fun getRes(): Int {
        return R.layout.activity_game_comment_details
    }

    override fun initView() {
        detailsGame = intent.getSerializableExtra("detailsGame") as? DetailGame
        comment = intent.getSerializableExtra("comment") as? Comment

        iv_back?.setOnClickListener {
            finish()
        }
        tv_page_title?.text = "评论详细"

        recycler?.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        adapter = GameCommentReplyAdapter().apply {
            addChildClickViewIds(R.id.iv_head)
            setOnItemChildClickListener { _, view, position ->
                val item = getItem(position)
                when (view.id) {
                    R.id.iv_head -> {
                        PopupUtils.showUserInfo(item.user, view)
                    }
                    else -> {
                    }
                }
            }
        }
        initHeader()
        recycler?.adapter = adapter
    }

    private fun initHeader() {
        headerView = View.inflate(this, R.layout.header_game_comment_details, null)
        adapter?.addHeaderView(headerView!!)
        headerView?.apply {
            tv_install?.setOnClickListener {
                finish()
            }
            iv_head.setOnClickListener {
                PopupUtils.showUserInfo(detailsGame?.user, it)
            }
            ImgLoadUtil.loadHead(iv_game_logo, detailsGame?.icon)
            tv_game_name?.text = detailsGame?.name
            tv_size?.text = "${UnitUtil.zao(detailsGame?.size)}  评分${detailsGame?.score}"

            ImgLoadUtil.loadHead(iv_head, comment?.user?.head)
            tv_name.text = comment?.user?.name
            tv_date.text = UnitUtil.time(comment?.createtime)
            tv_content.text = comment?.content
            val score = (comment?.score ?: 0).toFloat()
            rating_bar.rating = score
        }
    }

    override fun initData() {
        super.initData()
        comment?.replys?.let {
            adapter?.setNewInstance(it)
        }
        empty_view?.visibility = View.GONE
    }

}