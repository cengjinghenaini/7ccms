package com.xizhu.qiyou.ui.integral

import com.chad.library.adapter.base.provider.BaseItemProvider
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R

class IntegralEmptyProvider : BaseItemProvider<Any>() {
    override val itemViewType: Int
        get() = IntegralListAdapter.TYPE_EMPTY
    override val layoutId: Int
        get() = R.layout.item_recy_integral_empty

    override fun convert(helper: BaseViewHolder, item: Any) {

    }
}