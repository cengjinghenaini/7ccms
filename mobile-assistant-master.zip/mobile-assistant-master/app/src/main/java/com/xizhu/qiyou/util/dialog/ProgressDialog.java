package com.xizhu.qiyou.util.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.xizhu.qiyou.R;


public class ProgressDialog extends Dialog {

    private TextView cp_tv;
    private TextView current_tv;
    private TextView file_name_tv;

    public ProgressDialog(@NonNull Context context) {
        super(context);
    }

    public ProgressDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    protected ProgressDialog(@NonNull Context context, boolean cancelable, @Nullable OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_progress);
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = 450;
        lp.height = 410;
        lp.gravity = Gravity.CENTER;
        getWindow().setAttributes(lp);
        getWindow().setBackgroundDrawable(new ColorDrawable(0x00000000));

        cp_tv = findViewById(R.id.cp_tv);
        current_tv = findViewById(R.id.current_tv);
        file_name_tv = findViewById(R.id.file_name_tv);
    }


    public void updateProgress(String progress, String currentName) {
        current_tv.setText("已解压："+progress);
        file_name_tv.setText("压缩大小："+currentName);
//        current_tv.setText(currentName);
//        if (currentName.contains("/")) {
//            String[] split = currentName.split("/");
//            file_name_tv.setText(split[split.length - 1]);
//        } else {
//            file_name_tv.setText(currentName);
//        }
    }
}
