package com.xizhu.qiyou.apps;

/**
 * @ClassName SetNetEvent
 * @Description 用户设置允许4g下载
 * @Author guchu
 * @Date 2021/8/18 22:42
 * @Version 1.0
 */
public class SetNetEvent {
    public final boolean allow4G;

    public SetNetEvent(boolean allow4G) {
        this.allow4G = allow4G;
    }

    public boolean isAllow4G() {
        return allow4G;
    }
}
