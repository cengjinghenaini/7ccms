package com.xizhu.qiyou.ui.translation.entity;

public class TencentTransErr {

    /**
     * Error : {"Code":"RequestLimitExceeded","Message":"Your current request times equals to `13` in a second, which exceeds the frequency limit `5` for a second. Please reduce the frequency of calls."}
     * RequestId : 93b4c7f9-381b-498a-bceb-f1a20bcf68cd
     */

    private Response Response;

    public Response getResponse() {
        return Response;
    }

    public void setResponse(Response Response) {
        this.Response = Response;
    }

    public static class Response {
        /**
         * Code : RequestLimitExceeded
         * Message : Your current request times equals to `13` in a second, which exceeds the frequency limit `5` for a second. Please reduce the frequency of calls.
         */

        private Error Error;
        private String RequestId;

        public Error getError() {
            return Error;
        }

        public void setError(Error Error) {
            this.Error = Error;
        }

        public String getRequestId() {
            return RequestId;
        }

        public void setRequestId(String RequestId) {
            this.RequestId = RequestId;
        }

        public static class Error {
            private String Code;
            private String Message;

            public String getCode() {
                return Code;
            }

            public void setCode(String Code) {
                this.Code = Code;
            }

            public String getMessage() {
                return Message;
            }

            public void setMessage(String Message) {
                this.Message = Message;
            }
        }
    }
}
