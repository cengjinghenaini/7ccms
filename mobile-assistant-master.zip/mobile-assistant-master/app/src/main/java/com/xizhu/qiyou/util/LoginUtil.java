package com.xizhu.qiyou.util;

import android.app.Activity;
import android.content.Intent;

import com.xizhu.qiyou.ui.account.LoginActivity;


/**
 * @ClassName LoginUtil
 * @Description 如果可以就先进行一键登录、否则就 跳转到登录页面.
 * @Author guchu
 * @Date 2021/9/12 18:09
 * @Version 1.0
 */
public class LoginUtil {
    public interface ILoginSuccess {
        void loginSuccess();
    }

    private ILoginSuccess iLoginSuccess;
    public static final String TAG = LoginActivity.class.getSimpleName();
    private static Activity mContext;
    private static LoginUtil instance;

    private LoginUtil() {

    }

    public static LoginUtil getInstance(Activity context) {
        if (null == mContext) {
            instance = new LoginUtil();
            mContext = context;
        } else if (mContext != context) {
            instance = new LoginUtil();
            mContext = context;
        }
        return instance;
    }

    public void toLogin(ILoginSuccess iLoginSuccess) {
        this.iLoginSuccess = iLoginSuccess;
        mContext.startActivity(new Intent(mContext, LoginActivity.class));
    }


}
