package com.xizhu.qiyou.apps;

/**
 * @ClassName CurrentNetEvent
 * @Description 当前联网状态已经发生变化
 * @Author guchu
 * @Date 2021/8/18 22:42
 * @Version 1.0
 */
public class CurrentNetEvent {
    public static final int TYPE_NONE = 0; //无网络
    public static final int TYPE_WIFI = 1; //wifi
    public static final int TYPE_4G = 2; //流量
    public static final int TYPE_ETHERNET = 3; //网线（手机基本不会用到）

    public final int netType;

    public CurrentNetEvent(int netType) {
        this.netType = netType;
    }

    public int getNetType() {
        return netType;
    }
}
