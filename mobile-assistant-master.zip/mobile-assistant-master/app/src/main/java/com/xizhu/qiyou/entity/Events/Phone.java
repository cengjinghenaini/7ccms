package com.xizhu.qiyou.entity.Events;

public class Phone {
    public Phone(String phone) {
        this.phone = phone;
    }

    private String phone;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
