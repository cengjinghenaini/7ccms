package com.xizhu.qiyou.util;

import android.annotation.SuppressLint;
import android.os.Environment;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogUtil {
    private static final int lineLimit = 1024;

    public static void d(String msg) {
        e(msg, false);
    }

    public static void e(String msg) {
        e(msg, true);
    }

    public static void e(String msg, boolean isError) {
        String space = "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        StackTraceElement[] stackTraces = Thread.currentThread().getStackTrace();
        StackTraceElement stackTrace = stackTraces[3];
        String methodName = stackTrace.getMethodName();
        String className = stackTrace.getClassName();
        String format = className + " | " + methodName + "=>:";
        long length = msg.length();
        long span = length / lineLimit;
//        for (int i = lineLimit; i <= span; i++) {
//            content.insert(lineLimit * i + i - 1, "\n");
//        }
//        int start = 0;
//        do {
//            if (length > start + lineLimit) {
//                if (start != 0) {
//                    Log.e("LogUtil", "\n" + msg.substring(start, start + lineLimit));
//                } else {
//                    Log.e("LogUtil", format + msg.substring(start, start + lineLimit));
//                }
//            } else {
//                Log.e("LogUtil", format + msg);
//            }
//            length = length - lineLimit;
//            start = start + lineLimit;
//        } while (length > 0);


        if (isError) {
            Log.e("LogUtil", msg);
        } else {
            Log.d("LogUtil", msg);
        }
        if (!className.contains("Logger")) {
            saveLog(format + msg);
        }
    }

    public static void saveLog(String log) {
        File downPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);

        File file = new File(downPath, "/log_err.txt");
        if (file.exists() && file.isFile()) {
            long limit = 1024 * 1024;
            if (file.length() > (limit)) {
                FileWriter fileWriter = null;
                try {
                    fileWriter = new FileWriter(file);
                    fileWriter.write("");
                    fileWriter.flush();
                    fileWriter.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        try {
            FileWriter fileWriter = new FileWriter(file, true);
            @SuppressLint("SimpleDateFormat") SimpleDateFormat sf = new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
            String format = sf.format(new Date());
            fileWriter.write(format + "-->" + log + "\n");
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * unicode 转换成 utf-8
     *
     * @param theString
     * @return
     * @author fanhui
     * 2007-3-15
     */
    public static String unicodeToUtf8(String theString) {
        char aChar;
        int len = theString.length();
        StringBuffer outBuffer = new StringBuffer(len);
        for (int x = 0; x < len; ) {
            aChar = theString.charAt(x++);
            if (aChar == '\\') {
                aChar = theString.charAt(x++);
                if (aChar == 'u') {
                    // Read the xxxx
                    int value = 0;
                    for (int i = 0; i < 4; i++) {
                        aChar = theString.charAt(x++);
                        switch (aChar) {
                            case '0':
                            case '1':
                            case '2':
                            case '3':
                            case '4':
                            case '5':
                            case '6':
                            case '7':
                            case '8':
                            case '9':
                                value = (value << 4) + aChar - '0';
                                break;
                            case 'a':
                            case 'b':
                            case 'c':
                            case 'd':
                            case 'e':
                            case 'f':
                                value = (value << 4) + 10 + aChar - 'a';
                                break;
                            case 'A':
                            case 'B':
                            case 'C':
                            case 'D':
                            case 'E':
                            case 'F':
                                value = (value << 4) + 10 + aChar - 'A';
                                break;
                            default:
                                throw new IllegalArgumentException(
                                        "Malformed    \\uxxxx   encoding.");
                        }
                    }
                    outBuffer.append((char) value);
                } else {
                    if (aChar == 't')
                        aChar = '\t';
                    else if (aChar == 'r')
                        aChar = '\r';
                    else if (aChar == 'n')
                        aChar = '\n';
                    else if (aChar == 'f')
                        aChar = '\f';
                    outBuffer.append(aChar);
                }
            } else
                outBuffer.append(aChar);
        }
        return outBuffer.toString();
    }
}