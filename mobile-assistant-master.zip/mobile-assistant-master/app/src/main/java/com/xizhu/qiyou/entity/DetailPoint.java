package com.xizhu.qiyou.entity;

import java.util.List;

public class DetailPoint {
    public static final String IS_LOOKED = "1";//展示
    public static final String IS_NOT_LOOKED = "0"; //隐藏

    /**
     * id : 2
     * uid : 7
     * forum_id : 1
     * title : ujgghhb
     * content : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.
     * pics : ["http://47.108.140.231/Uploads/Picture/20201204/0ae1d67d67b2d6f6.jpg","http://47.108.140.231/Uploads/Picture/20201204/0ae1d67d67b2d6f6.jpg","http://47.108.140.231/Uploads/Picture/20201204/0ae1d67d67b2d6f6.jpg"]
     * video :
     * zan_count : 0
     * comment_count : 0
     * collect_count : 0
     * look_count : 0
     * phone_type :
     * is_top : 0
     * is_gonggao : 0
     * is_look: 0
     * is_reward : 0
     * reward_integral : 1
     * cate_id : 1
     * reply_time : 0
     * createtime : 0
     * app_id : 0
     * tail_id : 0
     * user : {"uid":"7","phone":"12345678910","email":"","name":"123****8910","wx_name":"","qq":"","head":"http://47.108.140.231/Uploads/Picture/20201202/s_9858f58aa76a2d52.jpg","touxian_id":"","touxian":"","sex":"1","is_member":"","age":"1970","sign":"距办公家具估计会v干活","integral":"766","exp":"","contribution":"","grade_id":"","grade_name":"","medals":[],"is_attention":0}
     * forum : {"id":"1","name":"版块1","icon":""}
     * createtime_f : 1970-01-01 08:00:00
     * is_zan : 0
     * is_collect : 0
     * gambits : []
     * atuser : []
     * links : []
     * look_type: 0
     * look_intagral: 0
     */

    private String id;
    private String uid;
    private String forum_id;
    private String title;
    private String content;
    private String video;
    private String zan_count;
    private String comment_count;
    private String collect_count;
    private String look_count;
    private String phone_type;
    private String is_top;
    private String is_gonggao;
    private String is_reward;
    private String reward_integral;
    private String cate_id;
    private String reply_time;
    private String createtime;
    private String app_id;
    private String tail_id;
    private User user;
    private Forum forum;
    private String createtime_f;
    private int is_zan;
    private int is_collect;
    private List<String> pics;
    private List<Gambit> gambits;
    private List<Atuser> atuser;
    private List<Link> links;
    private int is_forum_host;
    private String posts_id;
    private int is_reward_complete;
    private String show_type;

    public String getIs_look() {
        return is_look;
    }

    public void setIs_look(String is_look) {
        this.is_look = is_look;
    }

    public String getLook_type() {
        return look_type;
    }

    public void setLook_type(String look_type) {
        this.look_type = look_type;
    }

    public String getLook_intagral() {
        return look_intagral;
    }

    public void setLook_intagral(String look_intagral) {
        this.look_intagral = look_intagral;
    }

    private String is_look;
    private String look_type;
    private String look_intagral;

    public String getShow_type() {
        return show_type;
    }

    public void setShow_type(String show_type) {
        this.show_type = show_type;
    }

    public int getIs_reward_complete() {
        return is_reward_complete;
    }

    public void setIs_reward_complete(int is_reward_complete) {
        this.is_reward_complete = is_reward_complete;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getForum_id() {
        return forum_id;
    }

    public void setForum_id(String forum_id) {
        this.forum_id = forum_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public String getZan_count() {
        return zan_count;
    }

    public void setZan_count(String zan_count) {
        this.zan_count = zan_count;
    }

    public String getComment_count() {
        return comment_count;
    }

    public void setComment_count(String comment_count) {
        this.comment_count = comment_count;
    }

    public String getCollect_count() {
        return collect_count;
    }

    public void setCollect_count(String collect_count) {
        this.collect_count = collect_count;
    }

    public String getLook_count() {
        return look_count;
    }

    public void setLook_count(String look_count) {
        this.look_count = look_count;
    }

    public String getPhone_type() {
        return phone_type;
    }

    public void setPhone_type(String phone_type) {
        this.phone_type = phone_type;
    }

    public String getIs_top() {
        return is_top;
    }

    public void setIs_top(String is_top) {
        this.is_top = is_top;
    }

    public String getIs_gonggao() {
        return is_gonggao;
    }

    public void setIs_gonggao(String is_gonggao) {
        this.is_gonggao = is_gonggao;
    }

    public String getIs_reward() {
        return is_reward;
    }

    public void setIs_reward(String is_reward) {
        this.is_reward = is_reward;
    }

    public String getReward_integral() {
        return reward_integral;
    }

    public void setReward_integral(String reward_integral) {
        this.reward_integral = reward_integral;
    }

    public String getCate_id() {
        return cate_id;
    }

    public void setCate_id(String cate_id) {
        this.cate_id = cate_id;
    }

    public String getReply_time() {
        return reply_time;
    }

    public void setReply_time(String reply_time) {
        this.reply_time = reply_time;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public String getTail_id() {
        return tail_id;
    }

    public void setTail_id(String tail_id) {
        this.tail_id = tail_id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Forum getForum() {
        return forum;
    }

    public void setForum(Forum forum) {
        this.forum = forum;
    }

    public String getCreatetime_f() {
        return createtime_f;
    }

    public void setCreatetime_f(String createtime_f) {
        this.createtime_f = createtime_f;
    }

    public int getIs_zan() {
        return is_zan;
    }

    public void setIs_zan(int is_zan) {
        this.is_zan = is_zan;
    }

    public int getIs_collect() {
        return is_collect;
    }

    public void setIs_collect(int is_collect) {
        this.is_collect = is_collect;
    }

    public List<String> getPics() {
        return pics;
    }

    public void setPics(List<String> pics) {
        this.pics = pics;
    }

    public List<Gambit> getGambits() {
        return gambits;
    }

    public void setGambits(List<Gambit> gambits) {
        this.gambits = gambits;
    }

    public List<Atuser> getAtuser() {
        return atuser;
    }

    public void setAtuser(List<Atuser> atuser) {
        this.atuser = atuser;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    public int getIs_forum_host() {
        return is_forum_host;
    }

    public void setIs_forum_host(int is_forum_host) {
        this.is_forum_host = is_forum_host;
    }

    public String getPosts_id() {
        return posts_id;
    }

    public void setPosts_id(String posts_id) {
        this.posts_id = posts_id;
    }
}
