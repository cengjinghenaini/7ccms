package com.xizhu.qiyou.entity;

public class AppUpdate {

    /**
     * apk_version : 1.1
     * apk_url :
     */

    private String apk_version;
    private String apk_url;
    private String apk_desc;

    public String getApk_version() {
        return apk_version;
    }

    public void setApk_version(String apk_version) {
        this.apk_version = apk_version;
    }

    public String getApk_url() {
        return apk_url;
    }

    public void setApk_url(String apk_url) {
        this.apk_url = apk_url;
    }

    public String getApk_desc() {
        return apk_desc;
    }

    public void setApk_desc(String apk_desc) {
        this.apk_desc = apk_desc;
    }
}
