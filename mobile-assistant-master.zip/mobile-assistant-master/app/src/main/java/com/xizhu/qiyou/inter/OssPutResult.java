package com.xizhu.qiyou.inter;

import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.alibaba.sdk.android.oss.model.PutObjectResult;

public interface OssPutResult {
    void onSuccess(PutObjectRequest request, PutObjectResult result);
}
