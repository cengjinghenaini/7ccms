package com.xizhu.qiyou.ui.translation.entity;

public class TencentTrans {

    /**
     * TargetText : 你好
     * Source : en
     * Target : zh
     * RequestId : 000ee211-f19e-4a34-a214-e2bb1122d248
     */

    private Response Response;

    public Response getResponse() {
        return Response;
    }

    public void setResponse(Response Response) {
        this.Response = Response;
    }

    public static class Response {
        private String TargetText;
        private String Source;
        private String Target;
        private String RequestId;

        public String getTargetText() {
            return TargetText;
        }

        public void setTargetText(String TargetText) {
            this.TargetText = TargetText;
        }

        public String getSource() {
            return Source;
        }

        public void setSource(String Source) {
            this.Source = Source;
        }

        public String getTarget() {
            return Target;
        }

        public void setTarget(String Target) {
            this.Target = Target;
        }

        public String getRequestId() {
            return RequestId;
        }

        public void setRequestId(String RequestId) {
            this.RequestId = RequestId;
        }
    }
}
