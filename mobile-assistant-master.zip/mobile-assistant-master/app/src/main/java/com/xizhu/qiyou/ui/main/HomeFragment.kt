package com.xizhu.qiyou.ui.main

import android.content.Intent
import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.scwang.smart.refresh.layout.api.RefreshLayout
import com.scwang.smart.refresh.layout.listener.OnRefreshLoadMoreListener
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.*
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.ui.search.NewSearchActivity
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.UnitUtil
import com.xizhu.qiyou.util.UserMgr
import io.reactivex.Observable
import kotlinx.android.synthetic.main.fragment_home.*
import java.util.*

class HomeFragment : BaseFragment() {
    private var likeAdapter: HomeLikeAdapter? = null
    private var adapter: HomeAdapter? = null
    private var bigPicture: GameBigPicture? = null
    private var pageNum = 1
    private var pageSize = 10

    override fun isUseButterKnife(): Boolean {
        return false
    }

    override fun getRes(): Int {
        return R.layout.fragment_home
    }

    override fun initView() {
        super.initView()
        statusBar?.layoutParams?.height = UnitUtil.getStatusBarHeight(activity)
        layout_empty?.setBackgroundResource(R.color.gray_bd)
        refresh_layout?.setOnRefreshLoadMoreListener(object : OnRefreshLoadMoreListener {
            override fun onRefresh(refreshLayout: RefreshLayout) {
                pageNum = 1
                getHomeData()
            }

            override fun onLoadMore(refreshLayout: RefreshLayout) {
                pageNum++
                getHomeGame()
            }
        })
        empty_view?.setLoadListener {
            getHomeData()
        }
        val layoutManager = GridLayoutManager(activity, 4, GridLayoutManager.VERTICAL, false)
        recycler_like?.layoutManager = layoutManager
        likeAdapter = HomeLikeAdapter().apply {
            setEmptyView(R.layout.item_recy_empty)
            setOnItemClickListener { _, _, position ->
                val item = getItem(position)
                JumpUtils.jumpToGameDetailsPage(context, item?.id)
            }
            recycler_like?.adapter = this
        }

        rc_choice_end?.layoutManager =
            LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        adapter = HomeAdapter().apply {
            setEmptyView(R.layout.item_recy_empty)
            setOnItemClickListener { _, _, position ->
                val item = getItem(position)
                JumpUtils.jumpToGameDetailsPage(context, item.id)
            }
            rc_choice_end?.adapter = this
        }
        tv_search_box?.setOnClickListener {
            startActivity(Intent(activity, NewSearchActivity::class.java))
        }
        my_game?.setOnClickListener {
            JumpUtils.jumpToDownloadManagerPage(context)
        }
        iv_game_cover?.setOnClickListener {
            bigPicture?.let {
                JumpUtils.jumpToGameDetailsPage(context, it.app?.id)
            }
        }
    }

    override fun initData() {
        super.initData()
        getHomeData()
    }

    private fun getHomeData() {
        val observable1 = getApiService().getBigPicture(
            hashMapOf(
                Pair("page", "1"),
                Pair("pageSize", Constant.PAGE_SIZE)
            )
        )
        val observable2 = getApiService().getHotGame(
            hashMapOf(
                Pair("uid", UserMgr.getUid())
            )
        )
        val observable3 = getApiService().getHomeGame(
            hashMapOf(
                Pair("page", "1"),
                Pair("pageSize", pageSize.toString())
            )
        )

        val disposable = Observable.zip(observable1, observable2, observable3, { t1, t2, t3 ->
            val array = arrayOfNulls<Any>(3)
            array[0] = t1.data
            array[1] = t2.data
            array[2] = t3.data
            return@zip array
        }).compose(IoMainScheduler())
            .subscribe({ resultList: Array<Any?> ->
                val bigPictureList = resultList[0] as? MutableList<GameBigPicture>
                val hotGameList = resultList[1] as? MutableList<BaseGame>
                val homeGameList = resultList[2] as? MutableList<HomeGame>
                showBigPicture(bigPictureList)
                showHotGame(hotGameList)
                showHomeGame(homeGameList)
            })
            {
                showHomeGame(null)
            }
        addObserver(disposable)
    }

    private fun showBigPicture(bigPictureList: MutableList<GameBigPicture>?) {
        if (bigPictureList != null && bigPictureList.isNotEmpty()) {
            val randomIndex = Random().nextInt(bigPictureList.size)
            bigPicture = bigPictureList[randomIndex]
            tv_game_name?.text = bigPicture?.title
            if (GameBigPicture.TYPE_APP == bigPicture?.type) {
                val baseApp = bigPicture?.app
                tv_game_size?.text = UnitUtil.zao(baseApp?.size)
                tv_game_des?.text = baseApp?.introduction
            } else {
                val topic = bigPicture?.topic
                tv_game_size?.text = ""
                tv_game_des?.text = topic?.desc
            }
            iv_game_cover?.let { ImgLoadUtil.load(it, bigPicture?.pic) }
            iv_game_logo?.let { ImgLoadUtil.load(it, bigPicture?.app?.icon) }
            layout_empty?.visibility = View.GONE
        } else {
            layout_empty?.visibility = View.VISIBLE
        }
    }

    private fun showHotGame(hotGameList: MutableList<BaseGame>?) {
        if (hotGameList?.isNotEmpty() == true) {
            val list = mutableListOf<BaseApp?>()
            val count = if (hotGameList.size > 8) 8 else hotGameList.size
            for (i in 0 until count) {
                val baseApp = hotGameList[i].app
                list.add(baseApp)
            }
            likeAdapter?.setNewInstance(list)
        }
    }

    private fun showHomeGame(hotGameList: MutableList<HomeGame>?) {
        hotGameList?.let {
            if (pageNum == 1) {
                adapter?.setNewInstance(it)
            } else {
                adapter?.addData(it)
            }
            if (it.size >= pageSize) {
                refresh_layout?.setEnableLoadMore(true)
            } else {
                refresh_layout?.setEnableLoadMore(false)
            }
            refresh_layout?.finishRefresh()
            refresh_layout?.finishLoadMore()
            empty_view?.visibility = View.GONE
        } ?: run {
            if (empty_view?.visibility == View.VISIBLE) {
                empty_view?.setLoadFail()
            }
            refresh_layout?.setEnableLoadMore(false)
            refresh_layout?.finishRefresh(false)
            refresh_layout?.finishLoadMore(false)
            if (pageNum > 1) {
                pageNum--
            }
        }
    }

    private fun getHomeGame() {
        val ids = StringBuffer()
        if (adapter?.data?.isNotEmpty() == true) {
            adapter?.data?.forEachIndexed { index, homeGame ->
                if (index != 0) {
                    ids.append(",")
                }
                ids.append(homeGame.id)
            }
        }
        val params = hashMapOf(
            Pair("ids", ids.toString()),
            Pair("pageSize", pageSize.toString())
        )
        getApiService()
            .getHomeGame(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<MutableList<HomeGame>>() {
                override fun success(t: MutableList<HomeGame>) {
                    showHomeGame(t)
                }

                override fun error(msg: String?, code: Int) {
                    showHomeGame(null)
                }
            })
    }

}