package com.xizhu.qiyou.entity;

import java.io.Serializable;

/**
 * Created by lin.woo on 2021/8/17.
 */
public class FileTransfeBean implements Serializable {
    public int status;
    public String msg;
    public String file_path;
    public int progress;
}
