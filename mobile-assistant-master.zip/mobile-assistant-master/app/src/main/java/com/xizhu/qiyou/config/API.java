package com.xizhu.qiyou.config;

public class API {


    public final static String MASTER = "https://www.7c0.com";

    //传输
    public final static String TRANSFE_FILE = "http://121.204.246.7/index.php/Api/Home/upload";
    public final static String BASE = "http://47.108.140.231";
    //        public final static String DOMAIN = "http://47.108.140.231/index.php/";
//    public final static String DOMAIN = "http://ce.7C0.com/index.php/";
//    public final static String DOMAIN = "https://api.7c0.com/index.php/";
    public final static String DOMAIN = "http://119.28.56.143/";
    public final static String HOME_PATH = "Api/Home/";
    public final static String NOVEL_PATH = "Api/Novel/";
    public final static String PUBLIC_PATH = "Api/Public/";
    public final static String USER_PATH = "Api/User/";
    public final static String Forum_PATH = "Api/Forum/";

    public final static String FileUpload = "admin/FileUpload/upload";

    public final static String getBigPicture = HOME_PATH + "getBigPicture"; //1
    public final static String getHotGame = HOME_PATH + "getHotGame"; //2
    public final static String getMonthRec = HOME_PATH + "getMonthRec";  //3
    public final static String getAllMonthRec = HOME_PATH + "allMonthRec";  //4
    public final static String getUserShare = HOME_PATH + "getUserShare";  //5
    public final static String getChoiceGame = HOME_PATH + "getHomeSheet";  //6
    public final static String getSheetLabel = HOME_PATH + "sheetLabel";  //7
    public final static String getSheetInfo = HOME_PATH + "sheetInfo";  //8
    public final static String sheetComment = HOME_PATH + "sheetComment"; //9
    public final static String getSheetComment = HOME_PATH + "getSheetComment"; //10
    public final static String getSheetCommentReply = HOME_PATH + "getSheetCommentReply"; //11
    public final static String deleteSheetComment = HOME_PATH + "deleteSheetComment"; //12
    public final static String getHomeGame = HOME_PATH + "getHomeGame";  // 13
    public final static String getSearchKeyword = HOME_PATH + "getSearchKeyword";
    public final static String getSearchResult = HOME_PATH + "getSearchResult"; // 15
    public final static String attention = HOME_PATH + "attention"; // 16
    public final static String collect = HOME_PATH + "collect"; // 17
    public final static String zan = HOME_PATH + "zan"; // 18
    public final static String getNoReadCount = HOME_PATH + "getNoReadCount";  //19
    public final static String getUserMessage = HOME_PATH + "getUserMessage";  //20
    public final static String getUserNotice = HOME_PATH + "getUserNotice";  //21
    public final static String gameIsUpdate = HOME_PATH + "gameIsUpdate";  //22
    public final static String gameReserve = HOME_PATH + "gameReserve";  //23
    public final static String getAppCate = HOME_PATH + "getAppCate"; //24
    public final static String getAppLabel = HOME_PATH + "getAppLabel"; //25
    public final static String getGame = HOME_PATH + "getGame";  //26
    public final static String getTopic = HOME_PATH + "getTopic";  //27
    public final static String getTopicInfo = HOME_PATH + "getTopicInfo";  //28
    public final static String getTopicComment = HOME_PATH + "getTopicComment"; // 29
    public final static String getTopicCommentReply = HOME_PATH + "getTopicCommentReply"; // 30
    public final static String deleteTopicComment = HOME_PATH + "deleteTopicComment"; // 31
    public final static String commentTopic = HOME_PATH + "commentTopic"; // 32
    public final static String getMoNiQi = HOME_PATH + "getMoNiQi"; //33
    public final static String ziyuanGongju = HOME_PATH + "ziyuanGongju"; //34
    public final static String getCateApp = HOME_PATH + "getCateApp"; // 35
    public final static String getNewApp = HOME_PATH + "getNewApp"; // 36
    public final static String getSoundCate = HOME_PATH + "getSoundCate"; // 37
    public final static String getSound = HOME_PATH + "getSound"; // 38
    public final static String downloadSound = HOME_PATH + "downloadSound"; // 39
    public final static String downSoundRecord = HOME_PATH + "downSoundRecord"; // 40
    public final static String downloadApp = HOME_PATH + "downloadApp"; // 41
    public final static String downAppRecord = HOME_PATH + "downAppRecord"; // 42
    public final static String xuYuan = HOME_PATH + "xuYuan"; // 43
    public final static String getShareRec = HOME_PATH + "getShareRec"; // 44
    public final static String addUserApp = HOME_PATH + "addUserApp"; // 45
    public final static String appInfo = HOME_PATH + "appInfo"; // 46
    public final static String rewardAppIntegral = HOME_PATH + "rewardAppIntegral"; // 47
    public final static String getAppComment = HOME_PATH + "getAppComment"; // 48
    public final static String getAppCommentReply = HOME_PATH + "getAppCommentReply";  // 49
    public final static String deleteAppComment = HOME_PATH + "deleteAppComment";  // 50
    public final static String commentApp = HOME_PATH + "commentApp";  // 51
    public final static String lijianQiangSheet = HOME_PATH + "lijianQiangSheet";  // 52
    public final static String getLookRecord = HOME_PATH + "getLookRecord";  // 53
    public final static String getCollectRecord = HOME_PATH + "getCollectRecord";  // 54
    public final static String searchApp = HOME_PATH + "searchApp";  // 55
    public final static String userRecApp = HOME_PATH + "userRecApp";  // 56
    public final static String userRecAppRelease = HOME_PATH + "userRecAppRelease";  //57
    public final static String userRecAppCaogao = HOME_PATH + "userRecAppCaogao";  //58
    public final static String userRecAppInfo = HOME_PATH + "userRecAppInfo";  //59
    public final static String getUserRecAppCommnet = HOME_PATH + "getUserRecAppCommnet";  //60
    public final static String userRecAppCommnet = HOME_PATH + "userRecAppCommnet";  //61
    public final static String getRecCommentReply = HOME_PATH + "getRecCommentReply";  //62
    public final static String deleteRecComment = HOME_PATH + "deleteRecComment";  //63
    public final static String userRecAppDelete = HOME_PATH + "userRecAppDelete";  //64
    public final static String lijianQiangGame = HOME_PATH + "lijianQiangGame";  //65
    public final static String lijianQiangUser = HOME_PATH + "lijianQiangUser";  //66
    public final static String getLabelApp = HOME_PATH + "getLabelApp";//67
    public final static String appRaiders = HOME_PATH + "appRaiders";  //68
    public final static String appRaidersInfo = HOME_PATH + "appRaidersInfo";  //69
    public final static String getAppCommentScore = HOME_PATH + "getAppCommentScore";  //70
    public final static String getAppGambit = HOME_PATH + "getAppGambit";  //72
    public final static String getLeaderboard = HOME_PATH + "getLeaderboard"; // 73
    public final static String gambitBang = HOME_PATH + "gambitBang"; // 74
    public final static String gambitBangDetail = HOME_PATH + "gambitBangDetail"; // 75

    public final static String leaderboardDesc = HOME_PATH + "leaderboardDesc"; // 78

    public final static String play_sound = HOME_PATH + "play_sound"; // 77

    public final static String TRANSFE_INFO = HOME_PATH + "transportUpload";
    public final static String TRANSFE_LIST = HOME_PATH + "uploadList";
    public final static String TRANSFE_FILE_CHECK = HOME_PATH + "codeSearchFile";
    public final static String TRANSFE_DOWNLOAD = HOME_PATH + "downTransportFile";
    public final static String TRANSFE_DOWNLOAD_COUNT = HOME_PATH + "getDownCount";
    public final static String TRANSFE_DEL_RECORD = HOME_PATH + "delUploadRecord";

    public final static String getReportType = PUBLIC_PATH + "getReportType"; // 76
    public final static String report = PUBLIC_PATH + "report"; // 77
    public final static String getConfigPlayTime = PUBLIC_PATH + "getSetting"; // 78


    /*=================================================================================*/
    /*=================================================================================*/
    /*=================================================================================*/
    public final static String getCate = NOVEL_PATH + "getCate";  //1
    public final static String getDressUp = NOVEL_PATH + "getDressUp";  //2
    public final static String getDressUpInfo = NOVEL_PATH + "getDressUpInfo";  //3
    public final static String buyDressUp = NOVEL_PATH + "buyDressUp";  //4
    public final static String getUserIntegral = NOVEL_PATH + "getUserIntegral";  //5
    public final static String addUserIntegral = NOVEL_PATH + "use_integral_card";  //5
    public final static String getIntegralGoods = NOVEL_PATH + "getIntegralGoods";  //6
    public final static String integralGoodsInfo = NOVEL_PATH + "integralGoodsInfo";  //7
    public final static String convertGoods = NOVEL_PATH + "convertGoods";  //8
    public final static String downGetIntegral = NOVEL_PATH + "downGetIntegral";  //9
    public final static String getTask = NOVEL_PATH + "getTask";  //10
    public final static String getMedal = NOVEL_PATH + "getMedal";  //11
    public final static String getMedalInfo = NOVEL_PATH + "getMedalInfo";  //12
    public final static String convertMedal = NOVEL_PATH + "convertMedal";  //13
    public final static String getActiveCate = NOVEL_PATH + "getActiveCate";  //14
    public final static String getActiveList = NOVEL_PATH + "getActiveList";  //15
    public final static String getActiveDetails = NOVEL_PATH + "getActiveDetail";  //15
    public final static String getThemLike = NOVEL_PATH + "getThemLike";  //16
    public final static String flagFinishPlayTime = NOVEL_PATH + "completeGameTask";  //17

    /*=================================================================================*/
    /*=================================================================================*/
    /*=================================================================================*/
    public final static String pageContent = PUBLIC_PATH + "pageContent";  //1
    public final static String uploadFile = PUBLIC_PATH + "uploadFile";  //2
    public final static String kf = PUBLIC_PATH + "kf";  //3
    public final static String version = PUBLIC_PATH + "version";  //4
    /*=================================================================================*/
    /*=================================================================================*/
    /*=================================================================================*/
    public final static String getCode = USER_PATH + "getCode";  //1
    public final static String getGrades = USER_PATH + "userIntegralLog";  //1
    public final static String getEmailCode = USER_PATH + "getEmailCode";  //2
    public final static String otherLoginCheck = USER_PATH + "otherLoginCheck";  //3
    public final static String otherLogin = USER_PATH + "otherLogin";  //4
    public final static String phoneLogin = USER_PATH + "phoneLogin";  //5
    public final static String phoneOnceLogin = USER_PATH + "one_key_login";  //5
    public final static String pwdLogin = USER_PATH + "pwdLogin";  //5
    public final static String pwdRegister = USER_PATH + "register";  //5
    public final static String forgetPassword = USER_PATH + "forgetPassword";  //5


    public final static String emailLogin = USER_PATH + "emailLogin";  //6
    public final static String updatePro = USER_PATH + "updatePro";  //7
    public final static String setPassword = USER_PATH + "setPassword";  //14

    public final static String getUserTotalCount = USER_PATH + "getUserTotalCount";  //8
    public final static String getUserHome = USER_PATH + "getUserHome";  //9
    public final static String getUserMedal = USER_PATH + "getUserMedal";  //10
    public final static String settingMedal = USER_PATH + "settingMedal";  //11
    public final static String getUserPhoto = USER_PATH + "getUserPhoto";  //12
    public final static String addUserPhoto = USER_PATH + "addUserPhoto";  //13
    public final static String delUserPhoto = USER_PATH + "delUserPhoto";  //14

    public final static String getUserApp = USER_PATH + "getUserApp";  //15
    public final static String getUserSheet = USER_PATH + "getUserSheet";  //16
    public final static String delUserSheetApp = USER_PATH + "delUserSheetApp";  //17
    public final static String addUserSheetApp = USER_PATH + "addUserSheetApp";  //18
    public final static String attentionList = USER_PATH + "attentionList";  //19
    public final static String fansList = USER_PATH + "fansList";  //20
    public final static String getUserPosts = USER_PATH + "getUserPosts";  //21
    public final static String delUserPosts = USER_PATH + "delUserPosts";  //22
    public final static String getInviteInfo = USER_PATH + "getInviteInfo";  //23
    public final static String setInviteCode = USER_PATH + "setInviteCode";  //24
    public final static String setQuestion = USER_PATH + "setQuestion";  //25
    public final static String getMemberData = USER_PATH + "getMemberData";  //26
    public final static String openMember = USER_PATH + "openMember";  //27
    public final static String bindWxQq = USER_PATH + "bindWxQq";  //28
    public final static String checkPhone = USER_PATH + "checkPhone";  //29
    public final static String updatePhone = USER_PATH + "updatePhone";  //30
    public final static String deleteUserApp = USER_PATH + "deleteUserApp";  //30
    public final static String delUserLook = USER_PATH + "delUserLook";  //30
    public final static String delUserMessage = USER_PATH + "delUserMessage";  //30

    public final static String homeData = Forum_PATH + "homeData";  //1
    public final static String getPostsList = Forum_PATH + "getPostsList";  //2
    public final static String getForumCate = Forum_PATH + "getForumCate";  //3
    public final static String getForumList = Forum_PATH + "getForumList";  //4
    public final static String forumOneKeySignIn = Forum_PATH + "forumOneKeySignIn";  //6

    public final static String forumSignIn = Forum_PATH + "forumSignIn";  //6
    public final static String getSearchPointKeyword = Forum_PATH + "getSearchKeyword";
    public final static String getPostsCate = Forum_PATH + "getPostsCate";  //7
    public final static String forumDetail = Forum_PATH + "forumDetail";  //8
    public final static String postsDetail = Forum_PATH + "postsDetail";  //9
    public final static String postPay = Forum_PATH + "payIntegral";
    public final static String rewardPosts = Forum_PATH + "rewardPosts";  //10
    public final static String getRewardRecord = Forum_PATH + "getRewardRecord";  //11
    public final static String getPostsComment = Forum_PATH + "getPostsComment";  //12
    public final static String getPostsCommentReply = Forum_PATH + "getPostsCommentReply";  //13
    public final static String deletePostsComment = Forum_PATH + "deletePostsComment";  //14
    public final static String commentPosts = Forum_PATH + "commentPosts"; // 15
    public final static String getForumDesc = Forum_PATH + "getForumDesc"; // 16
    public final static String signPaihang = Forum_PATH + "signPaihang";  //17
    public final static String rewardPaihang = Forum_PATH + "rewardPaihang";  //18
    public final static String setPosts = Forum_PATH + "setPosts";  //19
    public final static String getTailList = Forum_PATH + "getTailList";  //20
    public final static String saveTail = Forum_PATH + "saveTail";  //21
    public final static String delForumPosts = Forum_PATH + "delForumPosts";  //22
    public final static String topForumPosts = Forum_PATH + "topForumPosts";  //23
    public final static String checkForumPosts = Forum_PATH + "checkForumPosts";  //24
    public final static String compReward = Forum_PATH + "compReward";  //24
    public final static String delTail = Forum_PATH + "delTail";  //24

    //翻译

    public final static String getFySdk = HOME_PATH + "getFySdk"; //1 获取翻译和提取文字的sdk信息
    public final static String setFyRecord = HOME_PATH + "setFyRecord"; //1 添加翻译记录
    public final static String duihuanFyCount = HOME_PATH + "duihuanFyCount"; //1 积分兑换翻译次数
    public final static String getFyCount = HOME_PATH + "getFyCount"; //1 获取翻译可用次数


    public final static String generalBasic = "https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic";
    public final static String getBaiduAuth = "https://aip.baidubce.com/oauth/2.0/token";


}
