package com.xizhu.qiyou.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.makeramen.roundedimageview.RoundedImageView;
import com.xizhu.qiyou.R;

public class RoundImageView extends RoundedImageView {
    private float[] fectf;
    private Path mPath;
    private RectF mRectF;
    private Paint mPaint;
    private float radius;

    public RoundImageView(Context context) {
        this(context, null, 0);
    }

    public RoundImageView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
        init(context, attrs);
    }

    public RoundImageView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    void init(@NonNull Context context, @Nullable AttributeSet attrs) {

        // 通过属性获取 圆角值
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.RoundImageView);
        radius = typedArray.getDimension(R.styleable.RoundImageView_android_radius, 0f);
        typedArray.recycle();
        if (radius > 0) {
            setCornerRadius(radius);
        }
        setScaleType(ScaleType.CENTER_CROP);
    }
}