package com.xizhu.qiyou.entity.Events;

public class PayGrade {
    private String integral;

    public PayGrade(String integral) {
        this.integral = integral;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }
}
