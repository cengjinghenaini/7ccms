package com.xizhu.qiyou.util;

import android.text.TextUtils;

import com.tencent.mmkv.MMKV;
import com.xizhu.qiyou.config.KVConstants;
import com.xizhu.qiyou.entity.User;

public class UserMgr {

    public static User getUser() {
        MMKV kv = MMKV.defaultMMKV();
        return kv.decodeParcelable(KVConstants.LOGIN_USER_INFO, User.class);
    }

    public static void setUser(User user) {
        MMKV kv = MMKV.defaultMMKV();
        kv.encode(KVConstants.LOGIN_USER_INFO, user);
        if (user == null) {
            setUid("");
        } else {
            setUid(user.getUid());
        }
    }


    private UserMgr() {
    }


    public static String getUid() {
        MMKV kv = MMKV.defaultMMKV();
        return kv.decodeString(KVConstants.LOGIN_USER_ID, "");
    }

    public static void setUid(String uid) {
        MMKV kv = MMKV.defaultMMKV();
        kv.encode(KVConstants.LOGIN_USER_ID, uid);
    }

    public static boolean isLogin() {
        String uid = getUid();
        return !TextUtils.isEmpty(uid);
    }

    public static boolean isMember() {
        MMKV kv = MMKV.defaultMMKV();
        String uid = kv.decodeString(KVConstants.LOGIN_USER_ID, "");
        if (TextUtils.isEmpty(uid)) {
            return false;
        }
        String is_member = kv.decodeString(KVConstants.IS_MEMBER, "");
        return TextUtils.equals(is_member, "1");
    }

    public static void setIsMember(String is_member) {
        MMKV kv = MMKV.defaultMMKV();
        kv.encode(KVConstants.IS_MEMBER, is_member);
    }

    public static String getGradeId() {
        MMKV kv = MMKV.defaultMMKV();
        return kv.decodeString(KVConstants.GRADE_ID);
    }

    public static void setGradeId(String grade_id) {
        MMKV kv = MMKV.defaultMMKV();
        kv.encode(KVConstants.GRADE_ID, grade_id);
    }


}
