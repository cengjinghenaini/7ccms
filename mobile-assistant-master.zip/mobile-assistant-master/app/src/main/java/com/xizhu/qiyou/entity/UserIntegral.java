package com.xizhu.qiyou.entity;

public class UserIntegral {

    /**
     * integral : 1
     * contribution :
     */

    private String integral;
    private String contribution;

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getContribution() {
        return contribution;
    }

    public void setContribution(String contribution) {
        this.contribution = contribution;
    }
}
