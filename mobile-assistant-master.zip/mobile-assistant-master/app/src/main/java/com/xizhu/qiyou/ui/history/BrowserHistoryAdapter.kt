package com.xizhu.qiyou.ui.history

import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.BaseApp
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.UnitUtil

class BrowserHistoryAdapter :
    BaseQuickAdapter<BaseApp, BaseViewHolder>(R.layout.item_recy_browser_history) {
    override fun convert(holder: BaseViewHolder, item: BaseApp) {
        ImgLoadUtil.loadHead(holder.getView(R.id.iv_game_logo), item.icon)
        holder.setText(R.id.tv_game_name, item.name)
        holder.setText(R.id.tv_size, "${UnitUtil.zao(item.size)}  评分${item.score}")
    }
}