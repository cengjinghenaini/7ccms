package com.xizhu.qiyou.util;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.fragment.app.Fragment;

public class StatusX {
    public static void initStatusBar(Fragment fragment, boolean light, boolean fullscreen, int color) {
        initStatusBar(fragment.getActivity(), light, fullscreen, color);
    }

    public static void initStatusBar(Activity activity, boolean light, boolean fullscreen, int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = activity.getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            int systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (light && fullscreen) {
                    systemUiVisibility = systemUiVisibility | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                } else if (light) {
                    systemUiVisibility = systemUiVisibility | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                } else if (fullscreen) {
                    systemUiVisibility = systemUiVisibility | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
                }
                window.setStatusBarColor(color);
            } else {
                if (fullscreen) {
                    systemUiVisibility = systemUiVisibility| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
                }
                if (light) {
                    window.setStatusBarColor(Color.BLACK);
                } else {
                    window.setStatusBarColor(color);
                }
            }

            window.getDecorView().setSystemUiVisibility(systemUiVisibility);
        } else {
            // 4.4背景为渐变半透明
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    }
}
