package com.xizhu.qiyou.service;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;

import androidx.annotation.Nullable;

import com.xizhu.qiyou.util.LogUtil;

import java.io.IOException;

public class MusicService extends Service {
    private static final String TAG = "MusicService";
    private MediaPlayer mp;
    private String currUrl;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        LogUtil.e("onStartCommand: ");
        return super.onStartCommand(intent, flags, startId);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        LogUtil.e("onBind: ");
        return new MusicAgent();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        LogUtil.e("onUnbind: ");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        LogUtil.e("onDestroy: ");
        super.onDestroy();
        if (mp != null) {
            mp.stop();
            mp.release();
        }
    }

    private void start(String musicPath) {
        if (mp == null || !musicPath.equals(currUrl)) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    initMediaPlayer(musicPath);
                    mp.start();
                }
            }).start();
        }
    }

    private void pause() {
        if (mp != null) {
            mp.pause();
        }
    }

    private void reset() {
        if (mp != null) {
            mp.reset();
        }
    }

    private void stop() {
        if (mp != null) {
            mp.stop();
            mp.release();
            mp = null;
        }
    }

    private void initMediaPlayer(String musicPath) {
        try {
            mp = new MediaPlayer();
            mp.setDataSource(musicPath);
            mp.prepare();
            currUrl = musicPath;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public class MusicAgent extends Binder {
        public void start(String musicPath) {
            MusicService.this.start(musicPath);
        }

        public void pause() {
            MusicService.this.pause();
        }

        public void stop() {
            MusicService.this.stop();
        }
    }
}
