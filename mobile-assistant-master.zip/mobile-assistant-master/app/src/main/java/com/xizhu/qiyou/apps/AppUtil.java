package com.xizhu.qiyou.apps;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;

import com.xizhu.qiyou.room.entity.AppEntity;
import com.xizhu.qiyou.ui.details.GameDetailsActivity;
import com.xizhu.qiyou.ui.download.DownloadManagerActivity;
import com.xizhu.qiyou.util.FileUtil;
import com.xizhu.qiyou.util.PhoneUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * @ClassName AppUtil
 * @Description TODO
 * @Author guchu
 * @Date 2021/8/18 21:22
 * @Version 1.0
 */
public class AppUtil {
    public static final String TAG = AppUtil.class.getSimpleName();
    public static final String KEY_FILE = "appInstall"; //文件位置
    public static final String KEY_GAME_ID = "game_id"; //通过这个字段判断当前activity是哪一个游戏.

    /**
     * 判断当前应用程序处于前台还是后台
     */
    public static String getTopActivity(final Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
        if (!tasks.isEmpty()) {
            ComponentName topActivity = tasks.get(0).topActivity;
            if (topActivity.getPackageName().equals(context.getPackageName())) {
                return topActivity.getClassName();
            }
        }
        return null;
    }

    public static void saveGameId(Context context, String gameId) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_FILE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_GAME_ID, gameId);
        editor.commit();
    }

    public static void clearGameId(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_FILE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }

    private static boolean ok4Install(Context context, AppEntity appEntity) {
        String activityName = AppUtil.getTopActivity(context);
        if (null == activityName) {
            return false;
        }
        String[] okActivities = new String[]{GameDetailsActivity.class.getName(), GameDetailsActivity.class.getName(),
                DownloadManagerActivity.class.getName()};
        List<String> okList = new ArrayList(Arrays.asList(okActivities));
        if (okList.indexOf(activityName) < 0) {
            return false;
        }
        SharedPreferences sp = context.getSharedPreferences(KEY_FILE, Context.MODE_PRIVATE);
        String gameId = sp.getString(KEY_GAME_ID, "");
        if (TextUtils.isEmpty(gameId)) {
            return false;
        }
        if ("all".equals(gameId)) {
            return true;
        }
        if (appEntity.getId() == Integer.parseInt(gameId)) {
            return true;
        }
        return false;
    }


    /**
     * 安装App,如果已经安装返回true. 否则返回false.
     */
    public static boolean install(Context context, AppEntity appEntity) {
        if (!ok4Install(context, appEntity)) {
            return false;
        }

        //如果是apk 那一定是可以安装
        if (appEntity.getDownPath().endsWith(".apk")) {
            FileUtil.installApk(context, appEntity.getDownPath());
            return false;
        }
        String versionName = PhoneUtil.getAppVersionName(context, appEntity.getRealPackage());
        boolean needUpdate = PhoneUtil.needUpdate(appEntity.getRealVersion(), versionName);
        if (!needUpdate) {
            appEntity.setIsInstalled(AppEntity.TYPE_INSTALLED);
            return true;
        }

        File unzippedDir = new File(appEntity.getUnzipPath());
        File[] unzippedFiles = unzippedDir.listFiles();
        File apkFile = null;
        for (File file : unzippedFiles) {
            if (file.isFile()) {
                apkFile = file;
            }
        }
        FileUtil.installApk(context, apkFile.getAbsolutePath());
        return false;
    }

    /**
     * 获取apk包的信息：版本号，名称，图标等
     *
     * @param absPath apk包的绝对路径
     * @param context
     */
    public static SimpleRealApp apkInfo(String absPath, Context context) {
        PackageManager pm = context.getPackageManager();
        PackageInfo pkgInfo = pm.getPackageArchiveInfo(absPath, PackageManager.GET_ACTIVITIES);
        if (pkgInfo != null) {
            ApplicationInfo appInfo = pkgInfo.applicationInfo;
            /* 必须加这两句，不然下面icon获取是default icon而不是应用包的icon */
            appInfo.sourceDir = absPath;
            appInfo.publicSourceDir = absPath;
            String appName = pm.getApplicationLabel(appInfo).toString();// 得到应用名
            String packageName = appInfo.packageName; // 得到包名
            String version = pkgInfo.versionName; // 得到版本信息
            /* icon1和icon2其实是一样的 */
            Drawable icon1 = pm.getApplicationIcon(appInfo);// 得到图标信息
            Drawable icon2 = appInfo.loadIcon(pm);
            String pkgInfoStr = String.format("PackageName:%s, Vesion: %s, AppName: %s", packageName, version, appName);
//            Log.i(appInfo, String.format("PkgInfo: %s", pkgInfoStr));
            return new SimpleRealApp(absPath, packageName, version, icon1);
        }
        return null;
    }

}
