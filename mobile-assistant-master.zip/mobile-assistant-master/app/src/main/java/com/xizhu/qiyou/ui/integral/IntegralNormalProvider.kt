package com.xizhu.qiyou.ui.integral

import com.chad.library.adapter.base.provider.BaseItemProvider
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.GradeBean
import com.xizhu.qiyou.util.UnitUtil

class IntegralNormalProvider : BaseItemProvider<Any>() {
    override val itemViewType: Int
        get() = IntegralListAdapter.TYPE_NORMAL
    override val layoutId: Int
        get() = R.layout.item_recy_integral

    override fun convert(helper: BaseViewHolder, item: Any) {
        val data = item as? GradeBean
        helper.setText(R.id.tv_type_name, data?.desc)
        helper.setText(R.id.tv_date, UnitUtil.time(data?.createtime.toString()))
        if ((data?.integral ?: 0) > 0) {
            helper.setText(R.id.tv_des, "+${data?.integral}")
        } else {
            helper.setText(R.id.tv_des, data?.integral.toString())
        }
    }
}