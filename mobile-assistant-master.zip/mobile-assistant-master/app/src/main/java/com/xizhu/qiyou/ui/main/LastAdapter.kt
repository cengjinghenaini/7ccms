package com.xizhu.qiyou.ui.main

import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.Special
import com.xizhu.qiyou.util.JumpUtils

class LastAdapter :
    BaseQuickAdapter<Special, BaseViewHolder>(R.layout.item_recy_game_last_topic) {


    override fun convert(holder: BaseViewHolder, item: Special) {
        val tvTitle: TextView = holder.getView(R.id.tv_title)
        tvTitle.text = item.name

        val recycler = holder.getView<RecyclerView>(R.id.recycler_topic)
        val newList = if (item.apps.size > 8) item.apps.subList(0, 8) else item.apps
        if (recycler.adapter is HomeLikeAdapter) {
            val adapter = recycler.adapter as? HomeLikeAdapter
            adapter?.setNewInstance(newList)
        } else {
            recycler.layoutManager =
                GridLayoutManager(context, 4, GridLayoutManager.VERTICAL, false)
            val adapter = HomeLikeAdapter()
            adapter.setOnItemClickListener { _, _, position ->
                val childItem = adapter.getItem(position)
                JumpUtils.jumpToGameDetailsPage(context, childItem?.id)
            }

            adapter.setNewInstance(newList)
            recycler.adapter = adapter
        }
    }


}