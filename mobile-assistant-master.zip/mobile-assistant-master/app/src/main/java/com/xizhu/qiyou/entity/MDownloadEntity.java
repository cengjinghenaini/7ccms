package com.xizhu.qiyou.entity;

import com.arialyy.aria.core.download.DownloadEntity;

public class MDownloadEntity {
    private DownloadEntity downloadEntity;
    private String speed;

    public DownloadEntity getDownloadEntity() {
        return downloadEntity;
    }

    public void setDownloadEntity(DownloadEntity downloadEntity) {
        this.downloadEntity = downloadEntity;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }
}
