package com.xizhu.qiyou.entity.Events;

public class LijianSheet {

    /**
     * id : value
     * pic : value
     * uid : value
     * title : value
     * zan_count : value
     * collect_count : value
     * comment_count : value
     * name : value
     * head : value
     */

    private String id;
    private String pic;
    private String uid;
    private String title;
    private String zan_count;
    private String collect_count;
    private String comment_count;
    private String name;
    private String head;
    private String desc;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getZan_count() {
        return zan_count;
    }

    public void setZan_count(String zan_count) {
        this.zan_count = zan_count;
    }

    public String getCollect_count() {
        return collect_count;
    }

    public void setCollect_count(String collect_count) {
        this.collect_count = collect_count;
    }

    public String getComment_count() {
        return comment_count;
    }

    public void setComment_count(String comment_count) {
        this.comment_count = comment_count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
