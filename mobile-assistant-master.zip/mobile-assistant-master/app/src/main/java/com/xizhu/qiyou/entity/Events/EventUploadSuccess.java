package com.xizhu.qiyou.entity.Events;

public class EventUploadSuccess {
    public String code;
}
