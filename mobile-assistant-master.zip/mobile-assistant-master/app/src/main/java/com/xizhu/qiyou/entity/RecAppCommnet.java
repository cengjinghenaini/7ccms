package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class RecAppCommnet extends Comment implements Serializable {


    /**
     * id : value
     * rec_id : value
     * uid : value
     * zan_count : value
     * reply_count : value
     * phone_type : value
     * content : value
     * reply_id : value
     * createtime : value
     * reply_uid : value
     * is_me : value
     * user : {"uid":"value","phone":"value","email":"value","name":"value","wx_name":"value","qq":"value","head":"value","touxian_id":"value","touxian":"value","sex":"value","is_member":"value","age":"value","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":"","medals":[{"id":"value","pic":"value","name":"value"}]}
     * replys : [{"id":"value","rec_id":"value","uid":"value","zan_count":"value","reply_count":"value","phone_type":"value","content":"value","reply_id":"value","createtime":"value","reply_uid":"value","reply_name":"value"}]
     * createtime_f : value
     */
}
