package com.xizhu.qiyou.entity.Events;

public class Gambit {
    private final String gambit;

    public Gambit(String gambit) {
        this.gambit = gambit;
    }

    public String getGambit() {
        return gambit;
    }
}
