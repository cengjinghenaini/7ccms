package com.xizhu.qiyou.http.request;

import com.xizhu.qiyou.config.API;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;

public class FileHelper extends ReqHelper {
    @Override
    public Request createReq() {
        MultipartBody.Builder builder = new MultipartBody.Builder()
                .setType(MultipartBody.FORM);

        for (int i = 0; i < getFiles().size(); i++) {
            File file = getFiles().get(i);
            builder.addFormDataPart("file",
                    file.getName(),
                    RequestBody.create(MediaType.parse("multipart/form-data"),
                            file));
        }

        for (String key : getParams().keySet()) {
            if (key == null) {
                break;
            }
            String s = getParams().get(key);
            builder.addFormDataPart(key, s == null ? "" : s);
        }


        MultipartBody requestBody = builder.build();
        return new Request.Builder()
                .url(API.DOMAIN + API.FileUpload)
                .post(requestBody)
                .build();
    }
}
