package com.xizhu.qiyou.util;

import android.os.Build;

import androidx.annotation.RequiresApi;

import com.xizhu.qiyou.util.zip.ZipUtils;

import java.beans.PropertyChangeEvent;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipUtil {
    static int fakeProgress = 0;
    private static ZipUtil instance;
    private final List<ZipProgressListener> listeners = new ArrayList<>();
    public static int SUCCESS = 0x123456;

    public static ZipUtil getInstance() {
        if (instance == null) {
            synchronized (ZipUtil.class) {
                if (instance == null) {
                    instance = new ZipUtil();
                }
            }
        }
        return instance;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void zip(String folderPath, String zipPath, String charset, ZipProgressListener zipProgressListener) {
        long totalSize = getTotalSize(new File(folderPath));
        try (ZipOutputStream zipOutput = new ZipOutputStream(new FileOutputStream(zipPath), Charset.forName(charset)); BufferedOutputStream output = new BufferedOutputStream(zipOutput)) {
            File folder = new File(folderPath);
            zip(zipOutput, output, folder, folder.getName(), totalSize, 0, zipPath, zipProgressListener);
        } catch (Exception e) {
            zipProgressListener.onError(e);
        }
    }

    private long zip(ZipOutputStream zipOutput, BufferedOutputStream output, File source, String sourceName, long totalSize, long readSize, String zipPath,
                     ZipProgressListener zipProgressListener) throws IOException {
        if (source.isDirectory()) {
            File[] flist = source.listFiles();
            if (flist.length == 0) {
                zipOutput.putNextEntry(new ZipEntry(sourceName + "/"));
            } else {
                for (File file : flist) {
                    readSize = zip(zipOutput, output, file, sourceName + "/" + file.getName(), totalSize, readSize, zipPath, zipProgressListener);
                }
            }
        } else {
            zipOutput.putNextEntry(new ZipEntry(sourceName));
            try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(source))) {
                byte[] b = new byte[1024];
                for (int len = input.read(b); len > 0; len = input.read(b)) {
                    output.write(b, 0, len);
                }
            } catch (Exception e) {
                zipProgressListener.onError(e);
            }
            Integer oldValue = (int) ((readSize * 1.0 / totalSize) * 100);// 已压缩的字节大小占总字节的大小的百分比
            readSize += source.length();// 累加字节长度
            Integer newValue = (int) ((readSize * 1.0 / totalSize) * 100);// 已压缩的字节大小占总字节的大小的百分比
            if (zipProgressListener != null) {// 通知调用者压缩进度发生改变
                zipProgressListener.onProgressChanged(new PropertyChangeEvent(zipPath, "progress", oldValue, newValue));
            }
        }
        return readSize;
    }

    private long getTotalSize(File file) {
        if (file.isFile()) {
            return file.length();
        }
        File[] list = file.listFiles();
        long total = 0;
        if (list != null) {
            for (File f : list) {
                total += getTotalSize(f);
            }
        }
        return total;
    }

    /**
     * 解压
     *
     * @param zipPath    要解压的zip文件路径
     * @param targetPath 存放解压后文件的目录
     * @param charset    字符编码，解决中文名称乱码
     * @throws Exception
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void unzip(String zipPath, String targetPath, String charset, String tag) {
        fakeProgress = 0;
        new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    File dstFile = new File(targetPath);
                    if (!dstFile.exists()) {
                        dstFile.mkdirs();
                    }
                    ZipUtils.unzipFile(zipPath, targetPath);
                    fakeProgress = 100;
                    for (int i = 0; i < listeners.size(); i++) {
                        listeners.get(i).onProgressChanged(new PropertyChangeEvent(zipPath, targetPath, ZipUtil.SUCCESS, ZipUtil.SUCCESS));
                    }
                } catch (Exception e) {
                    fakeProgress = 100;
                    e.printStackTrace();
                    for (int i = 0; i < listeners.size(); i++) {
                        listeners.get(i).onError(e);
                    }
                }
            }
        }.start();

        new Thread() {
            @Override
            public void run() {
                while (fakeProgress < 100) {
                    try {
                        Thread.currentThread().sleep(1500);
                        fakeProgress += 1;
                        if (fakeProgress >= 100) {
                            break;
                        }
                        if (fakeProgress > 90) {
                            fakeProgress = 50;
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    for (int i = 0; i < listeners.size(); i++) {
                        listeners.get(i).onProgressChanged(new PropertyChangeEvent(zipPath, targetPath, fakeProgress - 1, fakeProgress));
                    }
                }
            }
        }.start();

    }

    public void register(ZipProgressListener listener) {
        listeners.add(listener);
    }

    public void unregister(ZipProgressListener listener) {
        listeners.remove(listener);
    }

    public interface ZipProgressListener {
        void onProgressChanged(PropertyChangeEvent propertyChangeEvent);

        void onError(Exception e);
    }
}
