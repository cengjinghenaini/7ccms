package com.xizhu.qiyou.entity;

import java.util.List;

public class AllMonth {

    private List<BaseApp> now;
    private List<BaseApp> prev;

    public List<BaseApp> getNow() {
        return now;
    }

    public void setNow(List<BaseApp> now) {
        this.now = now;
    }

    public List<BaseApp> getPrev() {
        return prev;
    }

    public void setPrev(List<BaseApp> prev) {
        this.prev = prev;
    }
}
