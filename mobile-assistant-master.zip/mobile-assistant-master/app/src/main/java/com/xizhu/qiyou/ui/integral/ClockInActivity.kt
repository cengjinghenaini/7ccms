package com.xizhu.qiyou.ui.integral

import android.text.Html
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import androidx.core.content.ContextCompat
import com.haibin.calendarview.Calendar
import com.haibin.calendarview.CalendarView.OnCalendarSelectListener
import com.haibin.calendarview.CalendarView.OnYearChangeListener
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.SignInInfo
import com.xizhu.qiyou.entity.UserHome
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.util.DateUtils
import com.xizhu.qiyou.util.DialogUtils
import com.xizhu.qiyou.util.UserMgr
import kotlinx.android.synthetic.main.activity_clock_in.*
import kotlinx.android.synthetic.main.title_layout.*

class ClockInActivity : BaseCompatActivity(), OnCalendarSelectListener,
    OnYearChangeListener {
    private var currentYear = 0
    private var currentMonth = 0

    override fun getRes(): Int {
        return R.layout.activity_clock_in
    }

    override fun initView() {
        iv_back.setOnClickListener {
            finish()
        }
        tv_page_title.text = "打卡"
        calendarView.setOnYearChangeListener(this)
        calendarView.setOnCalendarSelectListener(this)
        tv_clock_in.setOnClickListener {
            signIn()
        }
    }

    override fun initData() {
        super.initData()
        currentYear = calendarView.curYear
        currentMonth = calendarView.curMonth
        getPageContent()
        updateDate()
        updateClockInStatus()
        getUserHome()
        getSignInDate()
    }

    private fun setSchemeDate(data: MutableList<String>) {
        val schemeDateMap = hashMapOf<String, Calendar>()
        data.forEach {
            val date = DateUtils.stringToDate(it, DateUtils.DatePattern.ONLY_DAY)
            val calendar = java.util.Calendar.getInstance()
            calendar.time = date
            val calendarInfo = getSchemeCalendar(
                calendar.get(java.util.Calendar.YEAR),
                calendar.get(java.util.Calendar.MONTH) + 1,
                calendar.get(java.util.Calendar.DAY_OF_MONTH)
            )
            schemeDateMap[calendarInfo.toString()] = calendarInfo
        }
        calendarView.setSchemeDate(schemeDateMap)
    }

    private fun updateDate() {
        val date = "${currentYear}-${currentMonth}"
        tv_date?.text = date
    }

    override fun onCalendarOutOfRange(calendar: Calendar?) {

    }

    override fun onCalendarSelect(calendar: Calendar?, isClick: Boolean) {
        calendar?.let {
            currentMonth = it.month
        }
        updateDate()
    }

    override fun onYearChange(year: Int) {
        currentYear = year
        updateDate()
    }

    private fun updateClockInStatus() {
        val user = UserMgr.getUser()
        tv_clock_in?.isEnabled = user?.is_sign == 0
        if (user.is_sign == 1) {
            tv_clock_in.text = "已打卡"
            tv_clock_in.isEnabled = false
        } else {
            tv_clock_in.text = "打卡"
            tv_clock_in.isEnabled = true
        }
    }

    private fun getSchemeCalendar(
        year: Int,
        month: Int,
        day: Int,
    ): Calendar {
        val calendar = Calendar()
        calendar.year = year
        calendar.month = month
        calendar.day = day
        return calendar
    }

    private fun getUserHome() {
        if (UserMgr.isLogin()) {
            val uid = UserMgr.getUid()
            HttpUtil.getInstance().getUserHome(uid, uid, object : ResultCallback<UserHome>() {
                override fun onSuccess(s: ResultEntity<UserHome>) {
                    val user = s.data.user
                    UserMgr.setUser(user)
                    updateClockInStatus()
                }
            })
        }
    }

    private fun getSignInDate() {
        val params = hashMapOf<String, Any>()
        params["uid"] = UserMgr.getUid()
        getApiService()
            .getSignInDate(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<MutableList<String>>() {
                override fun success(t: MutableList<String>) {
                    tv_clock_in_day?.text = t.size.toString()
                    setSchemeDate(t)
                }
            })
    }

    private fun signIn() {
        val params = hashMapOf<String, Any>()
        params["uid"] = UserMgr.getUid()
        getApiService()
            .signIn(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<SignInInfo>() {
                override fun success(t: SignInInfo) {
                    getUserHome()
                    getSignInDate()
                    val integralStr = "${t.integral}积分"
                    val experienceStr = "${t.exp}经验"
                    val message = "已获取${integralStr}、${experienceStr} ，连续签到有更多奖励。"
                    val spannable = SpannableString(message)
                    val pinkColor =
                        ContextCompat.getColor(this@ClockInActivity, R.color.color_main_pink)
                    spannable.setSpan(
                        ForegroundColorSpan(pinkColor),
                        spannable.indexOf(integralStr),
                        spannable.indexOf(integralStr) + integralStr.length,
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                    spannable.setSpan(
                        ForegroundColorSpan(pinkColor),
                        spannable.indexOf(experienceStr),
                        spannable.indexOf(experienceStr) + experienceStr.length,
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                    DialogUtils.showTipsDialog(this@ClockInActivity, message = spannable)
                }
            })
    }

    private fun getPageContent() {
        val params = hashMapOf<String, Any>()
        params["type"] = "10"
        getApiService()
            .getPageContent(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<Map<String, String>>() {
                override fun success(t: Map<String, String>) {
                    val content = t["content"]
                    tv_des.text = Html.fromHtml(content, Html.FROM_HTML_MODE_LEGACY)
                }
            })
    }
}