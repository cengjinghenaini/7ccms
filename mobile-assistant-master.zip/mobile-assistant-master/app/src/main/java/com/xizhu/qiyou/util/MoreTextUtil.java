package com.xizhu.qiyou.util;


import android.graphics.Color;
import android.text.Layout;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.xizhu.qiyou.helper.MyLinkedMovementMethod;

public class MoreTextUtil {
    private SpannableString eclipseString;    //收起的文字
    private SpannableString notEclipseString; //展开的文字
    private TextView textView;


    public static MoreTextUtil getInstance() {
        return new MoreTextUtil();
    }

    public void getLastIndexForLimit(TextView tv, int maxLine, String content) {
        if (TextUtils.isEmpty(content) || tv==null) {
            return;
        }
        this.textView = tv;
        //获取TextView的画笔对象
        TextPaint paint = textView.getPaint();
        //每行文本的布局宽度
        int width = AppConfig.getApplication().getResources().getDisplayMetrics().widthPixels - UnitUtil.dip2px(AppConfig.getApplication(), 40);
        //实例化StaticLayout 传入相应参数
        StaticLayout staticLayout = new StaticLayout(content, paint, width, Layout.Alignment.ALIGN_NORMAL, 1, 0, false);
        //判断content是行数是否超过最大限制行数3行

        if (staticLayout.getLineCount() > maxLine && content.length() > 70) {
            //定义展开后的文本内容
            String string1 = content + "    收起";
            notEclipseString = new SpannableString(string1);
            //给收起两个字设成蓝色
            notEclipseString.setSpan(new ForegroundColorSpan(Color.parseColor("#2ab67f")), string1.length() - 2, string1.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            //获取到第三行最后一个文字的下标
            int index = staticLayout.getLineStart(maxLine) - 1;

            String substring = content.substring(0, index-4) + "..." + "查看全部";
            eclipseString = new SpannableString(substring);
            //给查看全部设成蓝色
            eclipseString.setSpan(new ForegroundColorSpan(Color.parseColor("#2ab67f")), substring.length() - 4, substring.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            //设置收起后的文本内容
            tv.setText(eclipseString);
            tv.setOnClickListener(v -> {
                if (v.isSelected()) {
                    //如果是收起的状态
                    textView.setText(notEclipseString);
                    textView.setSelected(false);
                } else {
                    //如果是展开的状态
                    textView.setText(eclipseString);
                    textView.setSelected(true);
                }
            });
            //将textView设成选中状态 true用来表示文本未展示完全的状态,false表示完全展示状态，用于点击时的判断
            tv.setSelected(true);
        } else {
            //没有超过 直接设置文本
            tv.setText(content);
            tv.setOnClickListener(null);
        }
    }

    public void getLastIndexForLimitLength(TextView tv, int count, String content) {
        this.textView = tv;
        //#2ab67f
        if (content.length() > count) {
            less(tv, content, count);
        } else {
            //没有超过 直接设置文本
            tv.setText(content);
            tv.setOnClickListener(null);
        }
    }

    private void less(TextView tv, String content, int limit) {
        //定义收起的文本内容
        String string1 = content.substring(0, limit);
        notEclipseString = new SpannableString(string1 + "...展开");
        notEclipseString.setSpan(new ClickableSpan() {
                                     @Override
                                     public void onClick(@NonNull View widget) {
                                         more(tv, content, limit);
                                     }

                                     @Override
                                     public void updateDrawState(@NonNull TextPaint ds) {
                                         ds.setColor(Color.parseColor("#2ab67f"));
                                     }
                                 },
                string1.length() + 3, notEclipseString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv.setMovementMethod(MyLinkedMovementMethod.getInstance());
        tv.setText(notEclipseString);
    }

    private void more(TextView tv, String content, int limit) {
        //定义展开后的文本内容
        notEclipseString = new SpannableString(content + "  收起");
        notEclipseString.setSpan(new ClickableSpan() {
                                     @Override
                                     public void onClick(@NonNull View widget) {
                                         less(tv, content, limit);
                                     }

                                     @Override
                                     public void updateDrawState(@NonNull TextPaint ds) {
                                         ds.setColor(Color.parseColor("#2ab67f"));
                                     }
                                 },
                content.length(), notEclipseString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv.setMovementMethod(MyLinkedMovementMethod.getInstance());
        tv.setText(notEclipseString);
    }
}
