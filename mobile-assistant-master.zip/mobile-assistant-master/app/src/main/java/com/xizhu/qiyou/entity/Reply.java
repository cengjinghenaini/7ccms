package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class Reply extends Comment implements Serializable {

    /**
     * id : value
     * sheet_id : value
     * uid : value
     * zan_count : value
     * reply_count : value
     * phone_type : value
     * content : value
     * reply_id : value
     * createtime : value
     * reply_uid : value
     * score : value
     * reply_name : value
     */


    private String reply_name;


    public String getReply_name() {
        return reply_name;
    }

    public void setReply_name(String reply_name) {
        this.reply_name = reply_name;
    }
}
