package com.xizhu.qiyou.util;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;

import com.xizhu.qiyou.entity.AppInfo;
import com.xizhu.qiyou.util.dialog.ToastUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class PhoneUtil {
    public static final String phone_type = android.os.Build.MANUFACTURER;

    public static PackageInfo getPkgInfo(Context context, String pkg) {
        PackageManager packageManager = context.getPackageManager();
        try {
            return packageManager.getPackageInfo(pkg, 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean isUpdate(Context context, String packageX, String currentVersion) {
        Log.e("TAG", "isUpdate: " + currentVersion);
        if (packageX == null) {
            return false;
        }
        PackageInfo pkgInfo = getPkgInfo(context, packageX);
        if (pkgInfo != null && !TextUtils.isEmpty(currentVersion)) {
            try {
                String local = pkgInfo.versionName.replaceAll("\\.", "");
                String inter = currentVersion.replaceAll("\\.", "");
                return Integer.parseInt(inter) > Integer.parseInt(local);
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }

    public static String getState(Context context, String packageX, String currentVersion) {
        boolean isUpdate = isUpdate(context, packageX, currentVersion);
        if (isUpdate) {
            return "更新";
        } else {
            PackageInfo pkgInfo = getPkgInfo(context, packageX);
            if (pkgInfo == null) {
                return "下载";
            } else {
                return "打开";
            }
        }
    }

    public static List<AppInfo> getUserApps(Context context) {
        final PackageManager packageManager = context.getPackageManager();
        // 获取已经安装的所有应用, PackageInfo　系统类，包含应用信息
        List<PackageInfo> packages = packageManager.getInstalledPackages(0);
        ArrayList<AppInfo> userApps = new ArrayList<>();
        for (PackageInfo pak : packages) {
            AppInfo appInfo = new AppInfo();
            appInfo.setAppName(pak.applicationInfo.loadLabel(packageManager).toString());//获取应用名称
            appInfo.setPackageName(pak.packageName); //获取应用包名，可用于卸载和启动应用
            appInfo.setVersionName(pak.versionName);//获取应用版本名
            appInfo.setVersionCode(pak.versionCode);//获取应用版本号
            appInfo.setSourceDir(pak.applicationInfo.sourceDir); // apk源路径
            appInfo.setAppIcon(pak.applicationInfo.loadIcon(packageManager));//获取应用图标
            appInfo.setSize(String.valueOf(new File(pak.applicationInfo.sourceDir).length()));  //大小B

            if ((pak.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                userApps.add(appInfo);
            }
        }
        return userApps;
    }

    public static List<AppInfo> getSystemApps(Context context) {
        final PackageManager packageManager = context.getPackageManager();
        // 获取已经安装的所有应用, PackageInfo　系统类，包含应用信息
        List<PackageInfo> packages = packageManager.getInstalledPackages(0);
        ArrayList<AppInfo> systemApps = new ArrayList<>();
        for (PackageInfo pak : packages) {
            AppInfo appInfo = new AppInfo();
            appInfo.setAppName(pak.applicationInfo.loadLabel(packageManager).toString());//获取应用名称
            appInfo.setPackageName(pak.packageName); //获取应用包名，可用于卸载和启动应用
            appInfo.setVersionName(pak.versionName);//获取应用版本名
            appInfo.setVersionCode(pak.versionCode);//获取应用版本号
            appInfo.setSourceDir(pak.applicationInfo.sourceDir); // apk源路径
            appInfo.setAppIcon(pak.applicationInfo.loadIcon(packageManager));//获取应用图标
            if ((pak.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) {
                systemApps.add(appInfo);
            }
        }
        return systemApps;
    }

    public static boolean hasApp(Context context, String packageName) {
        final PackageManager packageManager = context.getPackageManager();// 获取packagemanager
        List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);// 获取所有已安装程序的包信息
        if (pinfo != null) {
            for (int i = 0; i < pinfo.size(); i++) {
                String pn = pinfo.get(i).packageName;
                if (pn.equals(packageName)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static String getAppVersionName(Context context, String packageName) {
        final PackageManager packageManager = context.getPackageManager();// 获取packagemanager
        List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);// 获取所有已安装程序的包信息
        if (pinfo != null) {
            for (int i = 0; i < pinfo.size(); i++) {
                String pn = pinfo.get(i).packageName;
                if (pn.equals(packageName)) {
                    return pinfo.get(i).versionName;
                }
            }
        }
        return "";
    }

    public static boolean needUpdate(String newVersion, String oldVersion) {
        if (TextUtils.isEmpty(oldVersion)) {
            return true;
        }
        if (TextUtils.isEmpty(newVersion)) {
            return false;
        }
        if (newVersion.equals(oldVersion)) {
            return false;
        }
        String[] newArr = newVersion.split("\\.");
        String[] oldArr = oldVersion.split("\\.");
        int lessLength = Math.min(newArr.length, oldArr.length);
        for (int i = 0; i < lessLength; i++) {
            int newItem = Integer.parseInt(newArr[i]);
            int oldItem = Integer.parseInt(oldArr[i]);
            if (newItem > oldItem) {
                return true;
            } else if (newItem < oldItem) {
                return false;
            }
        }
        if (newArr.length > oldArr.length) {
            return true;
        }
        return false;
    }


    public static boolean hasWX(Context context) {
        final PackageManager packageManager = context.getPackageManager();// 获取packagemanager
        List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);// 获取所有已安装程序的包信息
        if (pinfo != null) {
            for (int i = 0; i < pinfo.size(); i++) {
                String pn = pinfo.get(i).packageName;
                if (pn.equals("com.tencent.mm")) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean hasQQ(Context context) {
        final PackageManager packageManager = context.getPackageManager();
        List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);
        if (pinfo != null) {
            for (int i = 0; i < pinfo.size(); i++) {
                String pn = pinfo.get(i).packageName;
                if (pn.equals("com.tencent.mobileqq") || pn.equals("com.tencent.tim")) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void launchApp(Context context, String pag) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(pag);
        if (intent == null) {
            ToastUtil.show("组件应用无法直接启动");
        } else {
            context.startActivity(intent);
        }
    }

    public static boolean checkPermission(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.System.canWrite(context)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                intent.setData(Uri.parse("package:" + context.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return false;
            }
            return true;
        }
        return true;
    }

    public static void setRing(Context context, int type, String path, String title) {

        File sdfile = new File(path);
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DATA, sdfile.getAbsolutePath());
        values.put(MediaStore.MediaColumns.TITLE, title);
        values.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp3");
        values.put(MediaStore.Audio.Media.IS_RINGTONE, true);
        values.put(MediaStore.Audio.Media.IS_NOTIFICATION, true);
        values.put(MediaStore.Audio.Media.IS_ALARM, true);
        values.put(MediaStore.Audio.Media.IS_MUSIC, true);


        //得到铃声uri对象
        Uri uri = MediaStore.Audio.Media.getContentUriForPath(sdfile.getAbsolutePath());
        //删除之前的记录
        context.getContentResolver().delete(uri, null, null);
//        context.getContentResolver().delete(uri, MediaStore.MediaColumns.DATA + "=\"" + sdfile.getAbsolutePath() + "\"", null);


        //插入数据库
        Uri newUri = context.getContentResolver().insert(uri, values);

        switch (type) {
            case RingtoneManager.TYPE_RINGTONE:
                RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, newUri);
                ToastUtil.show("设置来电铃声成功！");
                break;
            case RingtoneManager.TYPE_NOTIFICATION:
                RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION, newUri);
                ToastUtil.show("设置通知铃声成功！");
                break;
            case RingtoneManager.TYPE_ALARM:
                RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM, newUri);
                ToastUtil.show("设置闹钟铃声成功！");
                break;
            default:
                RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALL, newUri);
                ToastUtil.show("设置铃声成功！");
                break;
        }
    }

    public static void openBrowser(Context context, String url) {
        if (!url.contains("https://") && !url.contains("http://")) {
            url = "http://" + url;
        }
        Intent intent = new Intent();
        intent.setAction("android.intent.action.VIEW");
        Uri content_url = Uri.parse(url);
        intent.setData(content_url);
        context.startActivity(intent);
    }

    public static void putSpDesc(Context context, String desc) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("desc", desc);
        edit.apply();
    }

    public static String getSpDesc(Context context) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        return sp.getString("desc", null);
    }

    public static void putSpPath(Context context, String path) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("path", path);
        edit.apply();
    }

    public static String getSpPath(Context context) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        return sp.getString("path", null);
    }

    public static String getSpVersion(Context context) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        return sp.getString("version", null);
    }

    public static void putSpVersion(Context context, String version) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("version", version);
        edit.apply();
    }

    public static void putSpTail(Context context, String tail_id) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString(UserMgr.getUid(), tail_id);
        edit.apply();
    }

    public static void putSpTailName(Context context, String name) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString(UserMgr.getUid() + "name", name);
        edit.apply();
    }

    public static String getSpTailName(Context context) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        return sp.getString(UserMgr.getUid() + "name", null);
    }

    public static String getSpTail(Context context) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        return sp.getString(UserMgr.getUid(), null);
    }

    public static void putSpUid(Context context, String uid) {
        SharedPreferences sp = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("uid", uid);
        edit.apply();
    }

    public static String getSpUid(Context context) {
        SharedPreferences user = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        return user.getString("uid", null);
    }

    public static boolean getSpMode(Context context) {
        SharedPreferences sp = context.getSharedPreferences("day_mode", Context.MODE_PRIVATE);
        return sp.getBoolean("day", false);
    }

    public static void putSpMode(Context context, boolean isday) {
        SharedPreferences sp = context.getSharedPreferences("day_mode", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putBoolean("day", isday);
        edit.apply();
    }

    public static String getVersionName() {
        // 获取packagemanager的实例
        PackageManager packageManager = AppConfig.getApplication().getPackageManager();
        // getPackageName()是你当前类的包名，0代表是获取版本信息
        PackageInfo packInfo = null;
        try {
            packInfo = packageManager.getPackageInfo(AppConfig.getApplication().getPackageName(), 0);
            return packInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return "1.0.0";
        }
    }
}
