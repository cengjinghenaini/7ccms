package com.xizhu.qiyou.ui.download

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.pass.util.NetUtil
import com.pass.util.NetUtil.NET_TYPE
import com.xizhu.qiyou.R
import com.xizhu.qiyou.apps.AppModel
import com.xizhu.qiyou.apps.AppStatus
import com.xizhu.qiyou.apps.DownloadService
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.room.entity.AppEntity
import com.xizhu.qiyou.util.PhoneUtil
import com.xizhu.qiyou.util.dialog.DialogUtil
import com.xizhu.qiyou.util.dialog.ToastUtil
import com.xizhu.qiyou.widget.EmptyView
import kotlinx.android.synthetic.main.fragment_download.*
import java.util.*

class DownloadFragment : BaseFragment(), DownloadAdapter.GetShownMsg {
    private var mAppModel: AppModel? = null
    private var type = 0//0 正在下载 1 等待安装
    private var adapter: DownloadAdapter? = null
    private var allAppList = mutableListOf<AppEntity>()

    companion object {
        fun instance(type: Int): DownloadFragment {
            val fragment = DownloadFragment()
            fragment.type = type
            return fragment
        }
    }

    override fun getRes(): Int {
        return R.layout.fragment_download
    }

    override fun initView() {
        super.initView()
        mAppModel = ViewModelProviders.of(this).get(AppModel::class.java)
        recycler.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        adapter = activity?.let {
            DownloadAdapter(this, type).apply {
                setEmptyView(EmptyView(it).setNoData("这里什么也没有，快去下载吧！"))
                addChildClickViewIds(R.id.tv_install)
                setOnItemChildClickListener { _, _, position ->
                    val item = getItem(position)
                    btnEvent(item)
                }
                setOnItemLongClickListener { _, _, position ->
                    val item = getItem(position)
                    val builder =
                        AlertDialog.Builder(activity)
                    builder.setTitle("确定删除记录")
                    builder.setNegativeButton(
                        "取消"
                    ) { dialog: DialogInterface, _: Int -> dialog.dismiss() }
                    builder.setPositiveButton(
                        "确定"
                    ) { _: DialogInterface?, _: Int ->
                        mAppModel?.pauseInstallProcess(item.downloadUrl)
                        mAppModel?.deleteAppEntity(item.downloadUrl)
                    }
                    builder.create().show()
                    return@setOnItemLongClickListener true
                }
            }
        }
        recycler.adapter = adapter
        mAppModel?.liveList?.observe(this, { appEntities: List<AppEntity> ->
            allAppList.clear()
            val downloadList = mutableListOf<AppEntity>()
            val waitingInstallList = mutableListOf<AppEntity>()
            for (appEntity in appEntities) {
                if (appEntity.isInstalled == AppEntity.TYPE_INSTALLED) {
                    continue
                }
                allAppList.add(appEntity)
                when (mAppModel!!.getStatus(appEntity)) {
                    AppStatus.WAIT_4_INSTALL, AppStatus.PAUSED_INSTALLED -> {
                        waitingInstallList.add(appEntity)
                    }
                    else -> {
                        downloadList.add(appEntity)
                    }
                }
            }
            if (type == 0) {
                adapter?.setNewInstance(downloadList)
            } else {
                adapter?.setNewInstance(waitingInstallList)
            }
        })
    }

    override fun getShownMsg(appEntity: AppEntity?): Array<String> {
        return shownStrArr(appEntity)
    }

    private fun shownStrArr(appEntity: AppEntity?): Array<String> {
        if (appEntity == null) {
            return arrayOf("", "", "", "")
        }
        var shownStr = ""
        var progressStr = ""
        var progressInt = 0
        val totalStr = String.format("%.2f", appEntity.size * 1.0 / (1024 * 1024)) + "M"
        val downloadStr = String.format(
            "%.2f",
            appEntity.downloadProgress * appEntity.size * 1.0 / 100 / (1024 * 1024)
        )
        val unzippedStr = String.format(
            "%.2f",
            1.0 * appEntity.unzipProgress * appEntity.size / 100 / (1024 * 1024)
        )
        var speedStr = ""
        when (mAppModel!!.getStatus(appEntity)) {
            AppStatus.NOT_INSTALLED -> {
                shownStr = "下载"
                progressInt = 0
                progressStr = "0/$totalStr"
                speedStr = "0kb/s"
            }
            AppStatus.NOT_UPDATED -> {
                shownStr = "更新"
                progressInt = 0
                progressStr = "0/$totalStr"
                speedStr = "0kb/s"
            }
            AppStatus.WAIT_4_DOWNLOAD -> {
                shownStr = "等待中"
                progressInt = appEntity.downloadProgress
                progressStr = "$downloadStr/$totalStr"
                speedStr = "0kb/s"
            }
            AppStatus.DOWNLOADING -> {
                val netType = NetUtil.getNetType(activity)
                when (netType!!) {
                    NET_TYPE.TYPE_NONE -> {
                        shownStr = "已暂停"
                        progressInt = appEntity.downloadProgress
                        progressStr = "$downloadStr/$totalStr"
                        speedStr = "0kb/s"
                    }
                    NET_TYPE.TYPE_ETHERNET, NET_TYPE.TYPE_4G, NET_TYPE.TYPE_WIFI -> {
                        shownStr = "下载中"
                        progressInt = appEntity.downloadProgress
                        progressStr = "$downloadStr/$totalStr"
                        speedStr = String.format("%.2f", appEntity.downSpeed * 1.0 / 1024) + "kb/s"
                    }
                }
            }
            AppStatus.WAIT_4_UNZIP -> {
                shownStr = "等待中"
                progressInt = 0
                progressStr = "0/$totalStr"
                speedStr = "0kb/s"
            }
            AppStatus.UNZIPPING -> {
                shownStr = "解压中"
                progressInt = appEntity.unzipProgress
                progressStr = "$unzippedStr/$totalStr"
                speedStr =
                    String.format("%.2f", appEntity.unzipSpeed * 1.0 / (1024 * 1024)) + "Mb/s"
            }
            AppStatus.WAIT_4_INSTALL, AppStatus.PAUSED_INSTALLED -> {
                shownStr = "安装"
                progressInt = 100
                progressStr = "$downloadStr/$totalStr"
                speedStr = "0kb/s"
            }
            AppStatus.INSTALLED -> {
                shownStr = "打开"
                progressInt = 100
                progressStr = "$downloadStr/$totalStr"
                speedStr = "0kb/s"
            }
            else -> {
                shownStr = "已暂停"
                if (appEntity.downloadProgress < 100) {
                    progressStr = "$downloadStr/$totalStr"
                    progressInt = appEntity.downloadProgress
                } else {
                    progressStr = "0/$totalStr"
                }
                speedStr = "0kb/s"
            }
        }
        return arrayOf(shownStr, progressStr, "" + progressInt, speedStr)
    }

    private fun btnEvent(appEntity: AppEntity?) {
        if (appEntity == null) {
            return
        }
        when (mAppModel?.getStatus(appEntity)) {
            AppStatus.NOT_INSTALLED, AppStatus.NOT_UPDATED -> {
            }
            AppStatus.WAIT_4_DOWNLOAD, AppStatus.WAIT_4_UNZIP -> {
                mAppModel?.pauseInstallProcess(appEntity.downloadUrl)
            }
            AppStatus.WAIT_4_INSTALL, AppStatus.PAUSED_NOT_DOWNLOAD, AppStatus.PAUSED_DOWNLOADING,
            AppStatus.PAUSED_NOT_UNZIP, AppStatus.PAUSED_UNZIPPING, AppStatus.PAUSED_INSTALLED -> {
                mAppModel?.continueInstallProcess(appEntity.downloadUrl)
            }
            AppStatus.DOWNLOADING -> {
                val netType = NetUtil.getNetType(activity?.applicationContext)
                when (netType!!) {
                    NET_TYPE.TYPE_NONE -> ToastUtil.show("当前无网络连接，无法下载")
                    NET_TYPE.TYPE_WIFI, NET_TYPE.TYPE_4G, NET_TYPE.TYPE_ETHERNET -> {
                        val intent = Intent(
                            activity,
                            DownloadService::class.java
                        )
                        intent.putExtra("bean", appEntity)
                        intent.putExtra("paused", true) //进行暂停
                        activity?.startService(intent)
                    }
                }
            }
            AppStatus.UNZIPPING -> {
                DialogUtil.simpleInfoDialog(
                    activity,
                    "解压缩过程无法暂停，只能取消重新解压缩。取消解压缩？",
                    object : DialogUtil.CallBack<String> {
                        override fun success(s: String) {
                            mAppModel?.pauseInstallProcess(appEntity.downloadUrl)
                        }

                        override fun failure(err: String) {}
                    })
            }
            AppStatus.INSTALLED -> {
                PhoneUtil.launchApp(activity, appEntity.realPackage)
            }
            else -> {
            }
        }
    }

}