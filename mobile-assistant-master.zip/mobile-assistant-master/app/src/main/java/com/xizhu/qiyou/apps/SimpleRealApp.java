package com.xizhu.qiyou.apps;

import android.graphics.drawable.Drawable;

/**
 * @ClassName SimpleRealApp
 * @Description 解析安装包，获取简单信息
 * @Author guchu
 * @Date 2021/8/22 7:51
 * @Version 1.0
 */
public class SimpleRealApp {
    private String appPath;
    private String packageName;
    private String versionName;
    private Drawable icon1;

    public String getAppPath() {
        return appPath;
    }

    public void setAppPath(String appPath) {
        this.appPath = appPath;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public Drawable getIcon1() {
        return icon1;
    }

    public void setIcon1(Drawable icon1) {
        this.icon1 = icon1;
    }

    public SimpleRealApp(String appPath, String packageName, String versionName, Drawable icon1) {
        this.appPath = appPath;
        this.packageName = packageName;
        this.versionName = versionName;
        this.icon1 = icon1;
    }
}
