package com.xizhu.qiyou.util;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.xizhu.qiyou.ui.details.GameDetailsActivity;
import com.xizhu.qiyou.ui.download.DownloadManagerActivity;

public class JumpUtils {

    public static void jumpToGameDetailsPage(Context context, String appId) {
        Intent intent = new Intent(context, GameDetailsActivity.class);
        intent.putExtra("appId", appId);
        context.startActivity(intent);
    }

    public static void jumpToDownloadManagerPage(Context context) {
        Intent intent = new Intent(context, DownloadManagerActivity.class);
        context.startActivity(intent);
    }

    public static void jumpToWeb(Context context, String url) {
        try {
            Uri uri = Uri.parse(url);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
