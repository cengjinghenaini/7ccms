package com.xizhu.qiyou.ui.details;

import android.content.Context;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.luck.picture.lib.photoview.PhotoView;
import com.xizhu.qiyou.R;
import com.xizhu.qiyou.util.PicSelectUtil;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class PreviewImageAdapter extends PagerAdapter {
    private final List<String> data = new ArrayList<>();
    private final PreviewImageAdapter.OnCallBackActivity onBackPressed;
    private Context context;
    /**
     * Maximum number of cached images
     */
    private static final int MAX_CACHE_SIZE = 20;
    /**
     * To cache the view
     */
    private final SparseArray<View> mCacheView = new SparseArray<>();

    public void clear() {
        mCacheView.clear();
    }

    public void removeCacheView(int position) {
        if (position < mCacheView.size()) {
            mCacheView.removeAt(position);
        }
    }

    public interface OnCallBackActivity {
        /**
         * Close Activity
         */
        void onActivityBackPressed();
    }

    public PreviewImageAdapter(Context context, PreviewImageAdapter.OnCallBackActivity onBackPressed) {
        super();
        this.context = context;
        this.onBackPressed = onBackPressed;
    }

    /**
     * bind data
     *
     * @param data
     */
    public void bindData(List<String> data) {
        if (data != null) {
            this.data.clear();
            this.data.addAll(data);
        }
    }

    /**
     * get data
     *
     * @return
     */
    public List<String> getData() {
        return data;
    }

    public int getSize() {
        return data.size();
    }

    public void remove(int currentItem) {
        if (getSize() > currentItem) {
            data.remove(currentItem);
        }
    }

    public String getItem(int position) {
        return getSize() > 0 && position < getSize() ? data.get(position) : null;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        (container).removeView((View) object);
        if (mCacheView.size() > MAX_CACHE_SIZE) {
            mCacheView.remove(position);
        }
    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }

    @Override
    public boolean isViewFromObject(@NotNull View view, @NotNull Object object) {
        return view == object;
    }

    @NotNull
    @Override
    public Object instantiateItem(@NotNull ViewGroup container, int position) {
        View contentView = mCacheView.get(position);
        if (contentView == null) {
            contentView = LayoutInflater.from(context).inflate(R.layout.item_preview_image, container, false);
            mCacheView.put(position, contentView);
        }
        PhotoView photoView = contentView.findViewById(R.id.preview_image);
        String media = getItem(position);


        photoView.setOnViewTapListener((view, x, y) -> {
            if (onBackPressed != null) {
                onBackPressed.onActivityBackPressed();
            }
        });

        PicSelectUtil.loadImage(context, media, photoView);
        (container).addView(contentView, 0);
        return contentView;
    }

}