package com.xizhu.qiyou.ui.details

import android.view.View
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseBottomDialogFragment
import kotlinx.android.synthetic.main.fragment_download_select.*

class DownloadSelectFragment : BaseBottomDialogFragment() {
    private var isNormal = false
    private var isQuick = false
    private var block: ((isQuick: Boolean) -> Unit)? = null

    companion object {
        fun instance(
            isNormal: Boolean,
            isQuick: Boolean,
            block: (isQuick: Boolean) -> Unit
        ): DownloadSelectFragment {
            val fragment = DownloadSelectFragment()
            fragment.isNormal = isNormal
            fragment.isQuick = isQuick
            fragment.block = block
            return fragment
        }
    }

    override fun getLayoutId(): Int {
        return R.layout.fragment_download_select
    }

    override fun initView() {
        if (!isNormal && !isQuick) {
            tv_normal.visibility = View.INVISIBLE
            tv_quick.visibility = View.INVISIBLE
            no_data.visibility = View.VISIBLE
        } else {
            no_data.visibility = View.GONE
            tv_normal.visibility = if (isNormal) View.VISIBLE else View.GONE
            tv_quick.visibility = if (isQuick) View.VISIBLE else View.GONE
        }
        iv_close.setOnClickListener {
            dismissAllowingStateLoss()
        }
        tv_normal.setOnClickListener {
            block?.invoke(false)
            dismissAllowingStateLoss()
        }
        tv_quick.setOnClickListener {
            block?.invoke(true)
            dismissAllowingStateLoss()
        }
    }

    override fun initData() {

    }
}