package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class WebGame implements Serializable {

    /**
     * id : 1
     * name : 页游
     * sort : 0
     * createtime : 1614786651
     */

    private String id;
    private String name;
    private String sort;
    private String createtime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    @Override
    public String toString() {
        return "WebGame{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", sort='" + sort + '\'' +
                ", createtime='" + createtime + '\'' +
                '}';
    }
}
