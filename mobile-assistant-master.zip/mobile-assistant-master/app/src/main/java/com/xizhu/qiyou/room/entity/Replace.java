package com.xizhu.qiyou.room.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "replaces")
public class Replace {
    @ColumnInfo
    @PrimaryKey(autoGenerate = true)
    int id;
    @ColumnInfo
    String target;
    @ColumnInfo
    String replace;

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getReplace() {
        return replace;
    }

    public void setReplace(String replace) {
        this.replace = replace;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
