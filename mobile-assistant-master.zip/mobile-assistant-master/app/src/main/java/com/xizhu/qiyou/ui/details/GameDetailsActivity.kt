package com.xizhu.qiyou.ui.details

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProviders
import com.arialyy.aria.core.Aria
import com.google.android.material.appbar.AppBarLayout.OnOffsetChangedListener
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.pass.util.DisplayUtil
import com.pass.util.NetUtil
import com.pass.util.NetUtil.NET_TYPE
import com.qmuiteam.qmui.util.QMUIDisplayHelper
import com.xizhu.qiyou.R
import com.xizhu.qiyou.apps.AppModel
import com.xizhu.qiyou.apps.AppStatus
import com.xizhu.qiyou.apps.AppUtil
import com.xizhu.qiyou.apps.DownloadService
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.DetailGame
import com.xizhu.qiyou.entity.DownloadInfo
import com.xizhu.qiyou.entity.Label
import com.xizhu.qiyou.entity.NULL
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.room.entity.AppEntity
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.ui.download.DownloadManagerActivity
import com.xizhu.qiyou.ui.integral.RechargeIntegralActivity
import com.xizhu.qiyou.ui.main.GameListActivity
import com.xizhu.qiyou.ui.search.NewSearchActivity
import com.xizhu.qiyou.util.*
import com.xizhu.qiyou.util.dialog.DialogUtil
import com.xizhu.qiyou.util.dialog.ToastUtil
import com.xizhu.qiyou.widget.IndicatorFragment
import com.xizhu.qiyou.widget.IndicatorViewPagerAdapter
import com.xizhu.qiyou.widget.QMUIFloatLayout
import kotlinx.android.synthetic.main.activity_game_details.*
import net.lucode.hackware.magicindicator.ViewPagerHelper
import net.lucode.hackware.magicindicator.buildins.UIUtil
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView
import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.ColorTransitionPagerTitleView
import kotlin.math.abs


class GameDetailsActivity : BaseCompatActivity() {
    private var commonNavigator: CommonNavigator? = null
    private val indicatorFragmentList = mutableListOf<IndicatorFragment>()
    private var dp10 = 0
    private var dp2 = 0
    private var textColor1 = Color.parseColor("#1C73FE")
    private var textColor2 = Color.parseColor("#FF5A5A")
    private var textColor3 = Color.parseColor("#CE5AFF")
    private var appId = ""
    private var data: DetailGame? = null
    private var mAppModel: AppModel? = null


    override fun getStatusColorRes(): Int {
        return R.color.C_00000000
    }

    override fun isLight(): Boolean {
        return false
    }

    override fun fitWindow(): Boolean {
        return false
    }

    override fun getRes(): Int {
        return R.layout.activity_game_details
    }

    override fun initView() {
        Aria.download(this).register()
        mAppModel = ViewModelProviders.of(this).get(AppModel::class.java)
        appId = intent.getStringExtra("appId") ?: appId
        dp10 = DisplayUtil.dip2px(this, 10f)
        dp2 = DisplayUtil.dip2px(this, 2f)
        val paddingTop = QMUIDisplayHelper.getStatusBarHeight(this)
        val layoutParams = toolbar?.layoutParams as? CollapsingToolbarLayout.LayoutParams
        layoutParams?.height = DisplayUtil.dip2px(this, 50f) + paddingTop
        toolbar?.layoutParams = layoutParams
        toolbar?.setPadding(0, paddingTop, 0, 0)
        title_layout?.setPadding(0, paddingTop, 0, 0)
        app_bar?.addOnOffsetChangedListener(OnOffsetChangedListener { appBarLayout, verticalOffset ->
            if (iv_game_cover?.visibility != View.VISIBLE) {
                return@OnOffsetChangedListener
            }
            val toolbarHeight = appBarLayout.totalScrollRange
            val dy = abs(verticalOffset)
            if (dy <= toolbarHeight) {
                val scale = dy.toFloat() / toolbarHeight
                val alpha = scale * 255
                toolbar?.setBackgroundColor(Color.argb(alpha.toInt(), 229, 123, 153))
            }
        })
        iv_back?.setOnClickListener { finish() }
        iv_search?.setOnClickListener {
            startActivity(Intent(activity, NewSearchActivity::class.java))
        }
        iv_download?.setOnClickListener {
            startActivity(Intent(this, DownloadManagerActivity::class.java))
        }
        empty_view?.setLoadListener {
            getAppInfo()
        }
        iv_share.setOnClickListener {
            showShareDialog()
        }
        tv_download.setOnClickListener {
            if (tv_download.text.toString() == "下载") {
                showDownloadSelectDialog()
            } else {
                download()
            }
        }
        iv_collect.setOnClickListener {
            collect()
        }
        iv_collect2.setOnClickListener {
            collect()
        }
        iv_unfold.setOnClickListener {
            if ((fl_tag?.measuredChildCount ?: 0) < (data?.labels?.size ?: 0)) {
                fl_tag?.maxLines = 10
                iv_unfold?.setImageResource(R.mipmap.icon_arrow_up_pink)
            } else {
                fl_tag?.maxLines = 1
                iv_unfold?.setImageResource(R.mipmap.icon_arrow_down_pink)
            }
        }
        initMagicIndicator()
        mAppModel?.liveList?.observe(this, { _: List<AppEntity?>? -> updateShownText() })
    }

    //收藏
    private fun collect() {
        if (data == null) return
        if (!UserMgr.isLogin()) {
            DialogUtil.showGotoLoginActivity(activity)
            return
        }
        val uid = UserMgr.getUid()
        HttpUtil.getInstance()
            .collect(uid, data!!.id, Constant.Collect_app, object : ResultCallback<NULL>() {
                override fun onSuccess(s: ResultEntity<NULL>) {
                    iv_collect.isSelected = !iv_collect.isSelected
                    iv_collect2.isSelected = !iv_collect2.isSelected
                }
            })
    }

    private fun initMagicIndicator() {
        commonNavigator = CommonNavigator(this)
        commonNavigator?.isSkimOver = true
        commonNavigator?.adapter = object : CommonNavigatorAdapter() {

            override fun getCount(): Int {
                return indicatorFragmentList.size
            }

            override fun getTitleView(context: Context?, index: Int): IPagerTitleView? {
                val simplePagerTitleView = ColorTransitionPagerTitleView(context)
                simplePagerTitleView.text = indicatorFragmentList[index].title
                simplePagerTitleView.setPadding(
                    DisplayUtil.dip2px(context, 12f),
                    0,
                    DisplayUtil.dip2px(context, 12f),
                    0
                )
                simplePagerTitleView.normalColor =
                    ContextCompat.getColor(context!!, R.color.color_7c7c7c)
                simplePagerTitleView.selectedColor =
                    ContextCompat.getColor(context, R.color.color_main_pink)
                simplePagerTitleView.textSize = 18F
                simplePagerTitleView.setOnClickListener { view_pager?.currentItem = index }
                return simplePagerTitleView
            }

            override fun getIndicator(context: Context?): IPagerIndicator {
                val indicator = LinePagerIndicator(context)
                indicator.mode = LinePagerIndicator.MODE_EXACTLY
                indicator.lineHeight = UIUtil.dip2px(context, 4.0).toFloat()
                indicator.lineWidth = UIUtil.dip2px(context, 22.0).toFloat()
                indicator.roundRadius = UIUtil.dip2px(context, 2.0).toFloat()
                indicator.startInterpolator = AccelerateInterpolator()
                indicator.endInterpolator = DecelerateInterpolator(2.0f)
                indicator.setColors(ContextCompat.getColor(context!!, R.color.color_main_pink))
                return indicator
            }
        }
        magic_indicator?.navigator = commonNavigator
        if (magic_indicator != null && view_pager != null) {
            ViewPagerHelper.bind(magic_indicator, view_pager)
        }
    }


    private fun createFragment(detailGame: DetailGame) {
        view_pager?.removeAllViewsInLayout()
        indicatorFragmentList.clear()
        indicatorFragmentList.add(IndicatorFragment("详细", GameDetailsFragment.instance(detailGame)))
        indicatorFragmentList.add(IndicatorFragment("评论", GameCommentFragment.instance(detailGame)))

        val indicatorViewPagerAdapter =
            IndicatorViewPagerAdapter(supportFragmentManager, commonNavigator) { _, _ -> }
        indicatorViewPagerAdapter.setData(indicatorFragmentList)
        view_pager?.adapter = indicatorViewPagerAdapter
        view_pager?.currentItem = 0
        magic_indicator?.onPageSelected(0)
    }

    override fun initData() {
        super.initData()
        getAppInfo()
    }


    //应用详情
    private fun getAppInfo() {
        HttpUtil.getInstance()
            .appInfo(UserMgr.getUid(), appId, object : ResultCallback<DetailGame>() {
                override fun onSuccess(s: ResultEntity<DetailGame>) {
                    data = s.data
                    val appEntity = mAppModel?.getAppByWebPackage(data?.packageX)
                    if (!TextUtils.isEmpty(appEntity?.downloadUrl)) {
                        data?.download_url = appEntity?.downloadUrl
                    }
                    AppUtil.saveGameId(this@GameDetailsActivity, data?.id)
                    showAppInfo()
                }

                override fun onFailure(err: String?, code: Int) {
                    super.onFailure(err, code)
                    showAppInfo()
                }
            })
    }

    private fun showAppInfo() {
        data?.let { it ->
            createFragment(it)
            tv_page_title?.text = it.name
            if (TextUtils.isEmpty(it.pic)) {
                iv_game_cover?.visibility = View.GONE
                iv_game_cover?.setImageResource(R.color.gray_bd)
                title_layout?.setBackgroundResource(R.color.color_main_pink)
                val params = coordinator?.layoutParams as? ViewGroup.MarginLayoutParams
                params?.let {
                    val statusBarHeight = QMUIDisplayHelper.getStatusBarHeight(this)
                    val marginTop = DisplayUtil.dip2px(this, 50f) + statusBarHeight
                    it.setMargins(0, marginTop, 0, 0)
                    coordinator?.layoutParams = it
                }
            } else {
                iv_game_cover?.visibility = View.VISIBLE
                title_layout?.setBackgroundColor(Color.TRANSPARENT)
                ImgLoadUtil.load(iv_game_cover, it.pic)
            }
            iv_collect?.isSelected = it.is_collect != 0
            iv_collect2?.isSelected = it.is_collect != 0
            ImgLoadUtil.load(iv_game_logo, it.icon)
            tv_game_name?.text = it.name
            tv_size?.text = UnitUtil.zao(it.size)
            updateTagView(fl_tag, it.labels)
            tv_score?.text = it.score
            tv_download_count?.text = it.down_count
            if (TextUtils.isEmpty(it.down_integral) || "0" == it.down_integral) {
                tv_integral_num?.visibility = View.GONE
                iv_collect2?.visibility = View.GONE
                iv_collect?.visibility = View.VISIBLE
            } else {
                val integralSp = SpannableString("积分 ${it.down_integral}")
                val pinkColor =
                    ContextCompat.getColor(this, R.color.color_main_pink)
                integralSp.setSpan(
                    ForegroundColorSpan(pinkColor),
                    integralSp.indexOf(it.down_integral),
                    integralSp.indexOf(it.down_integral) + it.down_integral.length,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                tv_integral_num?.text = integralSp
                tv_integral_num?.visibility = View.VISIBLE
                iv_collect2?.visibility = View.VISIBLE
                iv_collect?.visibility = View.GONE
            }
            empty_view?.visibility = View.GONE
            updateShownText()
        } ?: kotlin.run {
            empty_view?.setLoadFail()
        }
    }


    private fun updateTagView(fl_tag: QMUIFloatLayout?, cateList: List<Label>?) {
        fl_tag?.removeAllViews()
        cateList?.forEachIndexed { index, label ->
            val position = index % 4
            val textView = TextView(this)
            val textColor: Int
            val bgRes: Int
            when (position) {
                0 -> {
                    textColor = textColor1
                    bgRes = R.drawable.shape_game_blue_tag
                }
                2 -> {
                    textColor = textColor3
                    bgRes = R.drawable.shape_game_purple_tag
                }
                else -> {
                    textColor = textColor2
                    bgRes = R.drawable.shape_game_red_tag
                }
            }
            textView.textSize = 14f
            textView.setTextColor(textColor)
            textView.setBackgroundResource(bgRes)
            textView.setPadding(dp10, dp2, dp10, dp2)
            textView.text = label.name
            textView.setOnClickListener {
                GameListActivity.start(this, "", label.id, label.name)
            }
            fl_tag?.addView(textView)
        }
        fl_tag?.post {
            iv_unfold?.visibility = if (fl_tag.measuredChildCount < (cateList?.size ?: 0)
            ) View.VISIBLE else View.GONE
        }
    }

    private fun getDownloadUrl() {
        if (data == null) {
            return
        }
        showProgress()
        val params = hashMapOf<String, Any>()
        params["id"] = data!!.id
        params["uid"] = UserMgr.getUid()
        getApiService()
            .downloadApp(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<DownloadInfo>() {
                override fun success(t: DownloadInfo) {
                    dismissProgress()
                    data?.download_url = t.down_url
                    download(false)
                }

                override fun error(msg: String?, code: Int) {
                    dismissProgress()
                    when {
                        msg?.contains("积分") == true -> {
                            showRechargeDialog()
                        }
                        msg?.contains("次数") == true -> {
                            showShareDialog()
                            super.error(msg, code)
                        }
                        else -> {
                            super.error(msg, code)
                        }
                    }
                }
            })
    }

    private fun showDownloadSelectDialog() {
        val downloadSelectFragment = DownloadSelectFragment.instance(
            "1" == data?.is_gratis_down, "1" == data?.is_speed_down
        ) {
            if (it) {
                download()
            } else {
                addAppDownCount()
                JumpUtils.jumpToWeb(this, data?.down_url)
            }
        }
        try {
            downloadSelectFragment.showNow(supportFragmentManager, "DownloadSelectFragment")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showRechargeDialog() {
        val highlightStr1 = "充值积分"
        val highlightStr2 = "获取积分"
        val message = "您的积分已不足，请${highlightStr1}或${highlightStr2}再下载。"
        val spannable = SpannableString(message)
        val pinkColor =
            ContextCompat.getColor(this, R.color.color_main_pink)
        spannable.setSpan(
            ForegroundColorSpan(pinkColor),
            spannable.indexOf(highlightStr1),
            spannable.indexOf(highlightStr1) + highlightStr1.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        spannable.setSpan(
            ForegroundColorSpan(pinkColor),
            spannable.indexOf(highlightStr2),
            spannable.indexOf(highlightStr2) + highlightStr2.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        DialogUtils.showTipsDialog(
            this,
            message = spannable,
            cancelText = "去充值",
            onclickListener = {
                startActivity(Intent(this, RechargeIntegralActivity::class.java))
            })
    }

    private fun showShareDialog() {
        if (!UserMgr.isLogin()) {
            DialogUtil.showGotoLoginActivity(activity)
            return
        }
        try {
            val shareFragment = ShareFragment.instance(data) {
                shareAddDownCount()
            }
            shareFragment.showNow(supportFragmentManager, "ShareFragment")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun shareAddDownCount() {
        if (!UserMgr.isLogin()) {
            DialogUtil.showGotoLoginActivity(activity)
            return
        }
        val params = hashMapOf<String, Any>()
        params["uid"] = UserMgr.getUid()
        getApiService()
            .shareAddDownCount(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<Any>() {
                override fun success(t: Any) {
                }
            })
    }

    private fun addAppDownCount() {
        if (!UserMgr.isLogin()) {
            DialogUtil.showGotoLoginActivity(activity)
            return
        }
        if (data == null) {
            return
        }
        val params = hashMapOf<String, Any>()
        params["uid"] = UserMgr.getUid()
        params["appid"] = data!!.id
        getApiService()
            .shareAddDownCount(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<Any>() {
                override fun success(t: Any) {
                }
            })
    }

    private fun download(isFirst: Boolean = true) {
        if (data == null) {
            return
        }
        if (!UserMgr.isLogin()) {
            DialogUtil.showGotoLoginActivity(activity)
            return
        }
        if (TextUtils.isEmpty(data?.download_url)) {
            if (isFirst) {
                getDownloadUrl()
            } else {
                ToastUtil.show("未获取到下载地址")
            }
            return
        }
        val appStatus = mAppModel?.getStatus(data)
        val netType = NetUtil.getNetType(applicationContext)
        when (appStatus) {
            AppStatus.NOT_INSTALLED, AppStatus.NOT_UPDATED -> {
                when (netType!!) {
                    NET_TYPE.TYPE_NONE -> ToastUtil.show("当前无网络，请检查网络设置")
                    NET_TYPE.TYPE_ETHERNET, NET_TYPE.TYPE_4G, NET_TYPE.TYPE_WIFI -> {
                        mAppModel?.startDownload(data)
                    }
                }
            }
            AppStatus.WAIT_4_DOWNLOAD, AppStatus.WAIT_4_UNZIP -> {
                mAppModel?.pauseInstallProcess(data!!.download_url)
            }
            AppStatus.DOWNLOADING -> {
                when (netType!!) {
                    NET_TYPE.TYPE_NONE -> ToastUtil.show("当前无网络连接，无法下载")
                    NET_TYPE.TYPE_WIFI, NET_TYPE.TYPE_4G, NET_TYPE.TYPE_ETHERNET -> {
                        val intent = Intent(
                            this,
                            DownloadService::class.java
                        )
                        val appEntity = mAppModel?.getAppByWebPackage(data?.packageX)
                        appEntity?.let {
                            data?.download_url = it.downloadUrl
                        }
                        intent.putExtra(
                            "bean",
                            mAppModel?.getAppEntityByDownloadUrl(data?.download_url)
                        )
                        intent.putExtra("paused", true) //进行暂停
                        startService(intent)
                    }
                }
            }
            AppStatus.UNZIPPING -> {
                DialogUtil.simpleInfoDialog(
                    this,
                    "解压缩过程无法暂停，只能取消重新解压缩。取消解压缩？",
                    object : DialogUtil.CallBack<String> {
                        override fun success(s: String) {
                            mAppModel?.pauseInstallProcess(data?.download_url)
                        }

                        override fun failure(err: String) {}
                    })
            }
            AppStatus.INSTALLED -> {
                val appEntity = mAppModel?.getAppEntityByDownloadUrl(data?.download_url)
                if (null != appEntity) {
                    PhoneUtil.launchApp(this, appEntity.realPackage)
                } else {
                    PhoneUtil.launchApp(this, data?.packageX)
                }
            }
            AppStatus.PAUSED_NOT_DOWNLOAD, AppStatus.PAUSED_DOWNLOADING, AppStatus.PAUSED_NOT_UNZIP, AppStatus.PAUSED_UNZIPPING, AppStatus.WAIT_4_INSTALL, AppStatus.PAUSED_INSTALLED -> {
                mAppModel?.continueInstallProcess(data?.download_url)
            }
            else -> {
            }
        }
    }

    private fun updateShownText() {
        if (null == data) {
            tv_download.text = "下载"
            return
        }
        val shownStr: String
        val appStatus = mAppModel?.getStatus(data)
        val appEntity = if (TextUtils.isEmpty(data?.download_url))
            mAppModel?.getAppByWebPackage(data?.packageX) else
            mAppModel?.getAppEntityByDownloadUrl(data?.download_url)
        when (appStatus) {
            AppStatus.NOT_INSTALLED -> {
                shownStr = "下载"
            }
            AppStatus.NOT_UPDATED -> {
                shownStr = "更新"
            }
            AppStatus.WAIT_4_DOWNLOAD -> {
                shownStr = "等待中"
            }
            AppStatus.DOWNLOADING -> {
                val netType = NetUtil.getNetType(this)
                shownStr = when (netType!!) {
                    NET_TYPE.TYPE_NONE -> "已暂停"
                    NET_TYPE.TYPE_ETHERNET, NET_TYPE.TYPE_4G, NET_TYPE.TYPE_WIFI -> {
                        "下载中:" + appEntity?.downloadProgress + "%"
                    }
                }
            }
            AppStatus.WAIT_4_UNZIP -> shownStr = "等待中"
            AppStatus.UNZIPPING -> {
                shownStr = "解压中:" + appEntity?.unzipProgress + "%"
            }
            AppStatus.WAIT_4_INSTALL -> {
                shownStr = "安装"
            }
            AppStatus.INSTALLED -> {
                shownStr = "打开"
            }
            else -> shownStr = "已暂停"
        }
        tv_download.text = shownStr
    }

    override fun onResume() {
        super.onResume()
        updateShownText()
        if (data != null) {
            AppUtil.saveGameId(this, data!!.id)
        }
    }
}