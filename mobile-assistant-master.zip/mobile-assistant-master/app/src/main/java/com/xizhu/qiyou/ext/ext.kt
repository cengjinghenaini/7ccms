package com.xizhu.qiyou.ext

import com.xizhu.qiyou.http.retrofit.ApiServer
import com.xizhu.qiyou.http.retrofit.RetrofitUtil

fun getApiService(): ApiServer {
    return RetrofitUtil.instance().server()
}