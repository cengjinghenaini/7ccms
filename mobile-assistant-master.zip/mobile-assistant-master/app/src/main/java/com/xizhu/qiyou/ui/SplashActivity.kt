package com.xizhu.qiyou.ui

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.permissionx.guolindev.PermissionX
import com.xizhu.qiyou.R
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.ui.main.MainActivity
import com.xizhu.qiyou.util.dialog.ToastUtil
import kotlinx.android.synthetic.main.activity_splash.*

class SplashActivity : AppCompatActivity() {
    private val mHandler = Handler()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        PermissionX.init(this)
            .permissions(
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
            .request { allGranted: Boolean, _, deniedList: List<String?> ->
                if (allGranted) {
                    getSplashImage()
                } else {
                    Log.e("TAG", "onCreate: $deniedList")
                    ToastUtil.show("请授予权限")
                    finish()
                }
            }
    }

    private fun getSplashImage() {
        val params = hashMapOf<String, Any>()
        val key = "picture_link"
        params["fields"] = key
        getApiService()
            .getH5Url(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<Map<String, String>>() {
                override fun success(t: Map<String, String>) {
                    val imageUrl = t[key]
                    showImage(imageUrl)
                }

                override fun error(msg: String?, code: Int) {
                    showImage(null)
                }
            })
    }

    private fun showImage(imageUrl: String? = null) {
        if (!TextUtils.isEmpty(imageUrl)) {
            Glide.with(this).load(imageUrl).into(iv_splash)
        }
        mHandler.postDelayed({
            Log.e("startActivity", "init: ")
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, if (TextUtils.isEmpty(imageUrl)) 1500 else 5000)
    }

    override fun onDestroy() {
        mHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBackPressed() {

    }
}