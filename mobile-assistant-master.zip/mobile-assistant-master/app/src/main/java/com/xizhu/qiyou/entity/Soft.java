package com.xizhu.qiyou.entity;

import android.os.Parcel;
import android.os.Parcelable;

public class Soft extends Label implements Parcelable {
    private String app_type;
    private String type;
    private String createtime;

    protected Soft(Parcel in) {
        super(in);
    }

    public String getApp_type() {
        return app_type;
    }

    public void setApp_type(String app_type) {
        this.app_type = app_type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }
}
