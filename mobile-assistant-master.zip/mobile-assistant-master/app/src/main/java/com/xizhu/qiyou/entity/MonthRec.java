package com.xizhu.qiyou.entity;

import java.util.List;

public class MonthRec {

    /**
     * id : value
     * month : 09
     * app_ids : value
     * createtime : value
     * apps : [{"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value"}]
     */

    private String id;
    private String month;
    private String app_ids;
    private String createtime;
    private List<BaseApp> apps;



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getApp_ids() {
        return app_ids;
    }

    public void setApp_ids(String app_ids) {
        this.app_ids = app_ids;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public List<BaseApp> getApps() {
        return apps;
    }

    public void setApps(List<BaseApp> apps) {
        this.apps = apps;
    }

}
