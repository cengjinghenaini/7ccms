package com.xizhu.qiyou.entity;

import java.io.Serializable;
import java.util.List;

public class Comment extends BaseComment implements Serializable {

    /**
     * id : value
     * sheet_id : value
     * uid : value
     * zan_count : value
     * reply_count : value
     * phone_type : value
     * content : value
     * reply_id : value
     * createtime : value
     * reply_uid : value
     * score : value
     * user : {"uid":"value","phone":"value","email":"value","name":"value","wx_name":"value","qq":"value","head":"value","touxian_id":"value","touxian":"value","sex":"value","is_member":"value","age":"value","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":""}
     */

    private List<Reply> replys;
    protected String bill;

    public String getBill() {
        return bill;
    }

    public void setBill(String bill) {
        this.bill = bill;
    }
    public List<Reply> getReplys() {
        return replys;
    }
    public void setReplys(List<Reply> replys) {
        this.replys = replys;
    }


}
