package com.xizhu.qiyou.entity;

public class Gambit {

    private String name;
    /**
     * id : 2
     * pic :
     * posts_count : 0
     * look_count : 0
     * createtime : 1607433436
     * posts_title :
     */

    private String id;
    private String pic;
    private String posts_count;
    private String look_count;
    private String createtime;
    private String posts_title;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getPosts_count() {
        return posts_count;
    }

    public void setPosts_count(String posts_count) {
        this.posts_count = posts_count;
    }

    public String getLook_count() {
        return look_count;
    }

    public void setLook_count(String look_count) {
        this.look_count = look_count;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getPosts_title() {
        return posts_title;
    }

    public void setPosts_title(String posts_title) {
        this.posts_title = posts_title;
    }
}
