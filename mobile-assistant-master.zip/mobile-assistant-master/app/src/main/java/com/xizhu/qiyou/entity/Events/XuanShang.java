package com.xizhu.qiyou.entity.Events;

public class XuanShang {
    private String integral;

    public XuanShang(String integral) {
        this.integral = integral;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }
}
