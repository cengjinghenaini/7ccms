package com.xizhu.qiyou.ui.details

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.Shaky
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.util.UnitUtil
import com.xizhu.qiyou.util.UserMgr
import kotlinx.android.synthetic.main.activity_message_details.*
import kotlinx.android.synthetic.main.title_layout.*

class MessageDetailsActivity : BaseCompatActivity() {
    private var mShaky: Shaky? = null

    companion object {
        fun start(context: Context?, shaky: Shaky) {
            val intent = Intent(context, MessageDetailsActivity::class.java)
            intent.putExtra("shaky", shaky)
            context?.startActivity(intent)
        }
    }

    override fun getRes(): Int {
        return R.layout.activity_message_details
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun initView() {
        mShaky = intent?.getSerializableExtra("shaky") as? Shaky
        iv_back?.setOnClickListener {
            finish()
        }
        val webSettings = web_view.settings
        webSettings.allowFileAccess = true
        webSettings.layoutAlgorithm = WebSettings.LayoutAlgorithm.NARROW_COLUMNS
        webSettings.setSupportZoom(false)
        webSettings.builtInZoomControls = false
        webSettings.useWideViewPort = false
        webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        webSettings.blockNetworkImage = false
        webSettings.setSupportMultipleWindows(false)
        webSettings.setAppCacheEnabled(true)
        webSettings.databaseEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.javaScriptEnabled = true
        webSettings.setGeolocationEnabled(true)
        webSettings.loadWithOverviewMode = true
        webSettings.setNeedInitialFocus(true)
        webSettings.javaScriptCanOpenWindowsAutomatically = true
        webSettings.loadsImagesAutomatically = true
        webSettings.defaultTextEncodingName = "utf-8"
        web_view.webChromeClient = WebChromeClient()
    }

    override fun initData() {
        super.initData()
        showContent()
        getActiveDetails()
    }

    private fun showContent() {
        tv_title?.text = mShaky?.name
        tv_date?.text = UnitUtil.time(mShaky?.createtime)
        web_view.loadDataWithBaseURL(null, mShaky?.content ?: "", "text/html", "utf-8", null)
    }

    private fun getActiveDetails() {
        showProgress()
        val params = hashMapOf<String, String?>()
        params["uid"] = UserMgr.getUid()
        params["id"] = mShaky?.id
        getApiService()
            .getActiveDetails(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<Shaky>() {
                override fun success(t: Shaky) {
                    mShaky = t
                    showContent()
                    dismissProgress()
                }

                override fun error(msg: String?, code: Int) {
                    super.error(msg, code)
                    dismissProgress()
                }
            })
    }
}