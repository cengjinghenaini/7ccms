package com.xizhu.qiyou.entity;

import android.os.Parcel;

public class RingCate extends Cate{
    /**
     * type : 1
     * createtime : 0
     */

    private String type;
    private String createtime;

    protected RingCate(Parcel in) {
        super(in);
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }
}
