package com.xizhu.qiyou.util

import android.view.View
import com.qmuiteam.qmui.skin.QMUISkinManager
import com.qmuiteam.qmui.util.QMUIDisplayHelper
import com.qmuiteam.qmui.widget.popup.QMUIPopup
import com.qmuiteam.qmui.widget.popup.QMUIPopups
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.User
import kotlinx.android.synthetic.main.pop_user_info.view.*

object PopupUtils {
    fun showUserInfo(user: User?, v: View?) {
        if (user == null || v == null) {
            return
        }
        val headerView = View.inflate(v.context, R.layout.pop_user_info, null)
        ImgLoadUtil.loadHead(headerView.iv_head, user.head)
        headerView.tv_name.text = user.name
        headerView.tv_sign.text = user.sign
        QMUIPopups.popup(v.context, QMUIDisplayHelper.dp2px(v.context, 250))
            .preferredDirection(QMUIPopup.DIRECTION_BOTTOM)
            .view(headerView)
            .skinManager(QMUISkinManager.defaultInstance(v.context))
            .edgeProtection(QMUIDisplayHelper.dp2px(v.context, 10))
            .offsetX(QMUIDisplayHelper.dp2px(v.context, 20))
            .offsetYIfBottom(QMUIDisplayHelper.dp2px(v.context, 5))
            .shadow(true)
            .arrow(true)
            .animStyle(QMUIPopup.ANIM_GROW_FROM_CENTER)
            .show(v)
    }
}