package com.xizhu.qiyou.entity;

public class MsgUser {

    /**
     * id : 40
     * uid : 2
     * fuid : 7
     * type : 3
     * value_id : 217
     * is_read : 0
     * createtime : 1608694677
     * fuser : {"uid":"7","phone":"12345678910","email":"ddddggg@dd.com","name":"hh","wx_name":"","qq":"","head":"https://7you-1304371138.cos.ap-nanjing.myqcloud.com/1608296087867Screenshot_20201211-120852.jpg","touxian_id":"1","touxian":"版主","sex":"2","is_member":"1","age":"","sign":"kdjflk","integral":"2147483647","exp":"800","contribution":"49","grade_id":"1","grade_name":"1","medals":[{"id":"1","pic":"http://47.108.140.231/Uploads/Picture/20201204/0ae1d67d67b2d6f6.jpg","name":"勋章1"}],"is_pwd":0,"is_bind_wx":1,"is_bind_qq":1,"touxian2_id":0,"touxian2":""}
     * posts : {"id":"217","title":"复古"}
     * createtime_f : 2020-12-23 11:37:57
     */

    private String id;
    private String uid;
    private String fuid;
    private String type;
    private String value_id;
    private String is_read;
    private String createtime;
    private User fuser;
    private Point posts;
    private String createtime_f;
    private String content;

    @Override
    public String toString() {
        return "MsgUser{" +
                "id='" + id + '\'' +
                ", uid='" + uid + '\'' +
                ", fuid='" + fuid + '\'' +
                ", type='" + type + '\'' +
                ", value_id='" + value_id + '\'' +
                ", is_read='" + is_read + '\'' +
                ", createtime='" + createtime + '\'' +
                ", fuser=" + fuser +
                ", posts=" + posts +
                ", createtime_f='" + createtime_f + '\'' +
                ", content='" + content + '\'' +
                '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getFuid() {
        return fuid;
    }

    public void setFuid(String fuid) {
        this.fuid = fuid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue_id() {
        return value_id;
    }

    public void setValue_id(String value_id) {
        this.value_id = value_id;
    }

    public String getIs_read() {
        return is_read;
    }

    public void setIs_read(String is_read) {
        this.is_read = is_read;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public User getFuser() {
        return fuser;
    }

    public void setFuser(User fuser) {
        this.fuser = fuser;
    }

    public Point getPosts() {
        return posts;
    }

    public void setPosts(Point posts) {
        this.posts = posts;
    }

    public String getCreatetime_f() {
        return createtime_f;
    }

    public void setCreatetime_f(String createtime_f) {
        this.createtime_f = createtime_f;
    }


    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
