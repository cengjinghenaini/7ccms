package com.xizhu.qiyou.util.dialog;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;

public class CustomProgressDialog extends ProgressDialog {

    private View mLoadingTv;
    private View mImageView;

    public CustomProgressDialog(Context context) {
        super(context);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initView();
        initData();
    }

    private void initData() {

    }


    private void initView() {
//        setContentView(R.layout.progress_dialog);
//        mLoadingTv = findViewById(R.id.loadingTv);
//        mImageView = findViewById(R.id.loadingIv);
    }


}
