package com.xizhu.qiyou.ui.main.provider

import com.chad.library.adapter.base.provider.BaseItemProvider
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.BaseApp
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.UnitUtil

class RankPageTopThreeProvider(override val itemViewType: Int, override val layoutId: Int) :
    BaseItemProvider<Any>() {


    override fun convert(helper: BaseViewHolder, item: Any) {
        val data = item as? BaseApp
        ImgLoadUtil.load(helper.getView(R.id.iv_game_logo), data?.icon)
        helper.setText(R.id.tv_game_name, data?.name)
        helper.setText(R.id.tv_download_count, UnitUtil.zao(data?.size))
    }

}