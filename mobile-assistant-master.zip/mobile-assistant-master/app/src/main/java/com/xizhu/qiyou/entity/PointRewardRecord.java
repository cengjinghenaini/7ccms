package com.xizhu.qiyou.entity;

public class PointRewardRecord {


    /**
     * id : 1
     * uid : 1
     * post_id :
     * integral :
     * createtime :
     * user : {"uid":"1","phone":"18254127300","email":"123@12.com","name":"","wx_name":"","qq":"","head":"","touxian_id":"","touxian":"","sex":"1","is_member":"","age":"","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":""}
     */

    private String id;
    private String uid;
    private String post_id;
    private String integral;
    private String createtime;
    private User user;



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPost_id() {
        return post_id;
    }

    public void setPost_id(String post_id) {
        this.post_id = post_id;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

}
