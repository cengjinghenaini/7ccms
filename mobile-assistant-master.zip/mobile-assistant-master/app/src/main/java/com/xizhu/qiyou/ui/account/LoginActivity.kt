package com.xizhu.qiyou.ui.account

import android.content.Intent
import com.xizhu.qiyou.BuildConfig
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.User
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.AppUtils
import com.xizhu.qiyou.util.PhoneUtil
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.util.dialog.ToastUtil
import kotlinx.android.synthetic.main.activity_new_login.*

class LoginActivity : BaseCompatActivity() {

    override fun fitWindow(): Boolean {
        return false
    }

    override fun isLight(): Boolean {
        return false
    }

    override fun getStatusColorRes(): Int {
        return R.color.C_00000000
    }

    override fun getRes(): Int {
        return R.layout.activity_new_login
    }

    override fun initView() {
        val welcomeText = tv_welcome.text.toString()
        tv_welcome.text = welcomeText.replace("XXX", AppUtils.getAppName(this))
        tv_action_1.setOnClickListener {
            login()
        }
        tv_action_2.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            finish()
        }
        tv_find_password.setOnClickListener {
            val intent = Intent(this, RetrievePasswordActivity::class.java)
            startActivity(intent)
        }
        if (!BuildConfig.DEBUG) {
            et_account.text = null
            et_pwd.text = null
        }
    }


    //检测是否非法输入
    private fun illegal(): Boolean {
        val phone = et_account.text.toString()

        if (phone.length != 11) {
            ToastUtil.show("请输入正确的手机号")
            return true
        }

        val pwd: String = et_pwd.text.toString().trim { it <= ' ' }
        if (pwd.length < 6) {
            ToastUtil.show("密码至少6位")
            return true
        }
        return false
    }

    private fun login() {
        if (illegal()) {
            return
        }

        val phone: String = et_account.text.toString()
        val pwd: String = et_pwd.text.toString()
        showProgress()
        HttpUtil.getInstance().pwdLogin(phone, pwd, object : ResultCallback<User?>() {
            override fun onSuccess(s: ResultEntity<User?>) {
                loginSuccess(s)
            }

            override fun onFailure(err: String?, code: Int) {
                super.onFailure(err, code)
                dismissProgress()
            }
        })
    }


    private fun loginSuccess(s: ResultEntity<User?>) {
        dismissProgress()
        ToastUtil.show("登录成功")
        UserMgr.setUser(s.data)
        PhoneUtil.putSpUid(activity, s.data?.uid)
        finish()
    }

}