package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class Medal implements Serializable {

    /**
     * id : 1
     * pic :
     * name :
     * is_convert :
     * contribution :
     * desc :
     * createtime :
     */

    private String id;
    private String pic;
    private String name;
    private String is_convert;
    private String contribution;
    private String desc;
    private String createtime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIs_convert() {
        return is_convert;
    }

    public void setIs_convert(String is_convert) {
        this.is_convert = is_convert;
    }

    public String getContribution() {
        return contribution;
    }

    public void setContribution(String contribution) {
        this.contribution = contribution;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }
}
