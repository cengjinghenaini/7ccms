package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class QQUser1 implements Serializable {


    /**
     * nameValuePairs : {"ret":0,"openid":"B34935C23F80619A23CC54E826B67CB0","access_token":"229C5ADA4D704319184DAD514BD02FF7","pay_token":"0C9E64DD8E0B88FEB3604BBFDFFF938A","expires_in":7776000,"code":"","proxy_code":"","proxy_expires_in":0,"pf":"desktop_m_qq-10000144-android-2002-","pfkey":"d1a097e3ebd529fe3391b056ecb21cc6","msg":"","login_cost":28,"query_authority_cost":-203855265,"authority_cost":0,"expires_time":1615197462869}
     */

    private QQUser nameValuePairs;
    public QQUser getNameValuePairs() {
        return nameValuePairs;
    }
    public void setNameValuePairs(QQUser nameValuePairs) {
        this.nameValuePairs = nameValuePairs;
    }

}
