package com.xizhu.qiyou.entity;

public class DownLoad {

    /**
     * down_url : http://0
     */

    private String down_url;

    public String getDown_url() {
        return down_url;
    }

    public void setDown_url(String down_url) {
        this.down_url = down_url;
    }
}
