package com.xizhu.qiyou.entity;

public class AliOrderInfo {

    /**
     * orderString : alipay_sdk=alipay-sdk-php-20200415&amp;app_id=2021002111680423&amp;biz_content=%7B%22total_amount%22%3A100%2C%22out_trade_no%22%3A%22201219034599521001%22%2C%22subject%22%3A%22%5Cu8d2d%5Cu4e70%5Cu4f1a%5Cu5458%22%7D&amp;charset=utf-8&amp;format=json&amp;method=alipay.trade.app.pay&amp;notify_url=http%3A%2F%2F47.108.140.231%2Findex.php%2FApi%2FUser%2FaliNotify&amp;sign_type=RSA2&amp;timestamp=2020-12-19+15%3A45%3A48&amp;version=1.0&amp;sign=Y08%2F7Rjm4Pv5NywOeFz6%2BWLj1XeD%2B9OWZcOd1VyF%2FJTU6uyeZ54vMwzBcLGIA8RQsbTu5zSft9TYiFhuJIeuMAOrxdjekTH7R8nyXRUP8oiwtSQltFvkK8cY3JHQnS%2FTC1fqFJYGGCEY%2FHO%2BXXXjeK5F0WXACtDEN%2B3%2BE2ql%2BDjee%2BVEE2EEa%2FdwrJ702O5vnZuRSslQasyhK4MimPU74tvy%2BRopzl2czS1%2F%2B3EADmnbvmPOMFM9Q3baqd4rVs24%2F06hUz1bDkkz2VnmcykpsoT3EA8AQsEkrf0UmH0sM8gZO%2FptAOqrkKdCgpS335MDQ6fZANONxTjISrmg%2Fzc1UA%3D%3D
     */

    private String orderString;

    public String getOrderString() {
        return orderString;
    }

    public void setOrderString(String orderString) {
        this.orderString = orderString;
    }
}
