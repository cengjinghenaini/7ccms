package com.xizhu.qiyou.ui.account

import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.XieYi
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import kotlinx.android.synthetic.main.activity_level.*
import kotlinx.android.synthetic.main.title_layout.*

class LevelActivity : BaseCompatActivity() {
    override fun getRes(): Int {
        return R.layout.activity_level
    }

    override fun initView() {
        iv_back.setOnClickListener { finish() }
        tv_page_title.text = "等级"
    }

    override fun initData() {
        super.initData()
        HttpUtil.getInstance().pageContent(Constant.DENGJI, object : ResultCallback<XieYi>() {
            override fun onSuccess(s: ResultEntity<XieYi>) {
                web_view.settings.defaultTextEncodingName = "utf-8"
                web_view.loadDataWithBaseURL(null, s.data.content, "text/html", "utf-8", null)
            }
        })
    }
}