package com.xizhu.qiyou.entity;

import java.io.Serializable;

/**
 * 传输列表信息
 * Created by lin.woo on 2021/8/18.
 */
public class TransfeList implements Serializable {

    public String id;
    public String uid;
    public String name;
    public String code;
    public String size;
    public String integral;
    public String url;
    public String status;
    public String createtime;
    public String icon;
    public int sum_integral;
    public String sum_count;
}
