package com.xizhu.qiyou.entity;

import android.os.Parcel;

public class DownGame extends BaseApp{

    /**
     * id : value
     * pic : value
     * title : value
     * name : value
     * icon : value
     * introduction : value
     * score : value
     * comment_count : value
     * version : value
     * size : value
     * down_time : value
     * rec_reason : value
     * cate_name : value
     */


    private String cate_name;

    protected DownGame(Parcel in) {
        super(in);
    }
    public String getCate_name() {
        return cate_name;
    }

    public void setCate_name(String cate_name) {
        this.cate_name = cate_name;
    }
}
