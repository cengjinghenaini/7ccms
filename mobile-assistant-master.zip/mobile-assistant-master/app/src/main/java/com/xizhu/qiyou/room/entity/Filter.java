package com.xizhu.qiyou.room.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "filters")
public class Filter {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo
    int id;
    @ColumnInfo
    String filter;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }
}
