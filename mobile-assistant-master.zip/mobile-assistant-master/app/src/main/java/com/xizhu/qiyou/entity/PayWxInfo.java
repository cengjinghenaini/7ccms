package com.xizhu.qiyou.entity;

import com.google.gson.annotations.SerializedName;

public class PayWxInfo {

    /**
     * appid : wxc5c2487a83de57bb
     * partnerid : 1604514320
     * prepayid : wx191643135793420eb2d0ed763d00d20000
     * package : Sign=WXPay
     * noncestr : 0e67abb2409fffbb5f88f50b4cf77503
     * timestamp : 1608367393
     * sign : 02535CABBFE33F41E0DD216A8C0B3661E71FC7B45F0E1D924B0BD7F85838D2BF
     */

    private String appid;
    private String partnerid;
    private String prepayid;
    @SerializedName("package")
    private String packageX;
    private String noncestr;
    private int timestamp;
    private String sign;
    private String sign_type;

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getPartnerid() {
        return partnerid;
    }

    public void setPartnerid(String partnerid) {
        this.partnerid = partnerid;
    }

    public String getPrepayid() {
        return prepayid;
    }

    public void setPrepayid(String prepayid) {
        this.prepayid = prepayid;
    }

    public String getPackageX() {
        return packageX;
    }

    public void setPackageX(String packageX) {
        this.packageX = packageX;
    }

    public String getNoncestr() {
        return noncestr;
    }

    public void setNoncestr(String noncestr) {
        this.noncestr = noncestr;
    }

    public int getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(int timestamp) {
        this.timestamp = timestamp;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }
}
