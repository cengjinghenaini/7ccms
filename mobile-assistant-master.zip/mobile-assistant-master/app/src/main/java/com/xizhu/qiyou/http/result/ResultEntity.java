package com.xizhu.qiyou.http.result;


import com.xizhu.qiyou.entity.PageInfo;
import com.xizhu.qiyou.entity.State;

public class ResultEntity<B> {
    private State state;
    private PageInfo pageInfo;
    private B data;


    public int getCode(){
        return state.getCode();
    }

    public String getMsg(){
        return state.getMsg();
    }
    public B getData() {
        return data;
    }

    public void setData(B data) {
        this.data = data;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public PageInfo getPageInfo() {
        return pageInfo;
    }

    public void setPageInfo(PageInfo pageInfo) {
        this.pageInfo = pageInfo;
    }
}
