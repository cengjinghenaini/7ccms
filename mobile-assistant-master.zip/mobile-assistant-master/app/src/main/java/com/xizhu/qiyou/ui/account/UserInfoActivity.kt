package com.xizhu.qiyou.ui.account

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.TextUtils
import android.view.View
import android.widget.*
import com.luck.picture.lib.PictureSelector
import com.luck.picture.lib.config.PictureConfig
import com.qmuiteam.qmui.skin.QMUISkinManager
import com.qmuiteam.qmui.util.QMUIKeyboardHelper
import com.qmuiteam.qmui.widget.dialog.QMUIDialog
import com.qmuiteam.qmui.widget.dialog.QMUIDialog.AutoResizeDialogBuilder
import com.qmuiteam.qmui.widget.dialog.QMUIDialogAction
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.Events.Exit
import com.xizhu.qiyou.entity.NULL
import com.xizhu.qiyou.entity.UploadFile
import com.xizhu.qiyou.entity.User
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.PhoneUtil
import com.xizhu.qiyou.util.PicSelectUtil
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.util.dialog.ToastUtil
import kotlinx.android.synthetic.main.activity_user_info.*
import kotlinx.android.synthetic.main.title_layout.*
import org.greenrobot.eventbus.EventBus
import java.io.File

class UserInfoActivity : BaseCompatActivity() {
    private var user: User? = null

    override fun getRes(): Int {
        return R.layout.activity_user_info
    }

    override fun initView() {
        iv_back.setOnClickListener { finish() }
        tv_page_title.text = "设置"
        iv_head.setOnClickListener {
            PicSelectUtil.selectPic(this, true)
        }
        tv_up_head.setOnClickListener {
            PicSelectUtil.selectPic(this, true)
        }
        layout_name.setOnClickListener {
            showEditNameDialog()
        }
        layout_level.setOnClickListener {
            startActivity(Intent(this, LevelActivity::class.java))
        }
        layout_gender.setOnClickListener {
            showChangeGenderDialog()
        }
        layout_sign.setOnClickListener {
            showChangeSignDialog()
        }
        tv_edit.setOnClickListener {
            startActivity(Intent(this, EditPasswordActivity::class.java))
        }
        tv_exit_login.setOnClickListener {
            UserMgr.setUser(null)
            EventBus.getDefault().post(Exit())
            PhoneUtil.putSpUid(activity, null)
            finish()
        }
    }

    override fun initData() {
        super.initData()
        user = UserMgr.getUser()
        showUserInfo()
    }

    private fun showUserInfo() {
        if (user != null) {
            ImgLoadUtil.loadHead(iv_head, user?.head)
            tv_name.text = user?.name
            tv_level.text = user?.grade_id
            tv_gender.text = if ("1" == user?.sex) "男" else "女"
            tv_sign.text = user?.sign
        } else {
            ToastUtil.show("请先登录")
            finish()
            return
        }
    }

    private fun showEditNameDialog() {
        val contentView = View.inflate(this, R.layout.dialog_change_name, null)
        val etContent = contentView.findViewById<EditText>(R.id.et_content)
        etContent.setText(user?.name)
        if (!TextUtils.isEmpty(user?.name)) {
            etContent.setSelection(user!!.name.length)
        }
        CustomDialogBuilder(
            activity, contentView
        ).setSkinManager(QMUISkinManager.defaultInstance(this))
            .setTitle("昵称输入")
            .addAction(0, "确定", QMUIDialogAction.ACTION_PROP_NEGATIVE) { dialog, _ ->
                val name = etContent.text.toString().trim()
                if (TextUtils.isEmpty(name)) {
                    ToastUtil.show(etContent.hint.toString())
                    return@addAction
                }
                user?.name = name
                tv_name.text = user?.sign
                updateUserInfo(user!!.uid, null, name, null, null)
                dialog.dismiss()
            }
            .create(R.style.DialogTheme2)
            .show()
        QMUIKeyboardHelper.showKeyboard(etContent, true)
    }

    private fun showChangeGenderDialog() {
        val contentView = View.inflate(this, R.layout.dialog_change_gender, null)
        val rbMale = contentView.findViewById<RadioButton>(R.id.rb_male)
        val rbFemale = contentView.findViewById<RadioButton>(R.id.rb_female)
        var gender = user?.sex ?: "1"
        fun updateGender(gender: String) {
            if (gender == "1") {
                rbMale.isChecked = true
                rbFemale.isChecked = false
            } else {
                rbMale.isChecked = false
                rbFemale.isChecked = true
            }
        }
        updateGender(gender)

        rbMale.setOnClickListener {
            gender = "1"
            updateGender(gender)
        }
        rbFemale.setOnClickListener {
            gender = "2"
            updateGender(gender)
        }
        CustomDialogBuilder(
            activity, contentView
        ).setSkinManager(QMUISkinManager.defaultInstance(this))
            .setTitle("性别选择")
            .addAction(0, "确定", QMUIDialogAction.ACTION_PROP_NEGATIVE) { dialog, _ ->
                user?.sex = gender
                if ("2" == user?.sex) {
                    tv_gender.text = "女"
                } else {
                    tv_gender.text = "男"
                }
                updateUserInfo(user!!.uid, null, null, null, gender)
                dialog.dismiss()
            }
            .create(R.style.DialogTheme2)
            .show()
    }

    private fun showChangeSignDialog() {
        val contentView = View.inflate(this, R.layout.dialog_change_sign, null)
        val etContent = contentView.findViewById<EditText>(R.id.et_content)
        etContent.setText(user?.sign)
        if (!TextUtils.isEmpty(user?.sign)) {
            etContent.setSelection(user!!.sign.length)
        }
        CustomDialogBuilder(
            activity, contentView
        ).setSkinManager(QMUISkinManager.defaultInstance(this))
            .setTitle("签名输入")
            .addAction(0, "确定", QMUIDialogAction.ACTION_PROP_NEGATIVE) { dialog, _ ->
                val sign = etContent.text.toString().trim()
                if (TextUtils.isEmpty(sign)) {
                    ToastUtil.show(etContent.hint.toString())
                    return@addAction
                }
                user?.sign = sign
                tv_sign.text = user?.sign
                updateUserInfo(user!!.uid, null, null, sign, null)
                dialog.dismiss()
            }
            .create(R.style.DialogTheme2)
            .show()
        QMUIKeyboardHelper.showKeyboard(etContent, true)
    }


    private fun updateUserInfo(
        uid: String,
        head: String?,
        name: String?,
        sign: String?,
        sex: String?,
    ) {
        HttpUtil.getInstance().updatePro(
            uid,
            head,
            name,
            sign,
            sex,
            null,
            null,
            null,
            object : ResultCallback<NULL>() {
                override fun onSuccess(s: ResultEntity<NULL>) {
                    dismissProgress()
                    ToastUtil.show("更新成功")
                    EventBus.getDefault().post(user)
                }
            })
    }

    internal class CustomDialogBuilder(context: Context?, private val contentView: View) :
        AutoResizeDialogBuilder(context) {

        override fun onBuildContent(dialog: QMUIDialog, context: Context): View {
            return contentView
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == PictureConfig.CHOOSE_REQUEST) {
            val localMedia = PictureSelector.obtainMultipleResult(data)
            var path = localMedia[0].cutPath
            if (path == null) {
                path = localMedia[0].compressPath
            }
            val uri = Uri.fromFile(File(path))
            iv_head.setImageURI(uri)
            HttpUtil.getInstance()
                .upload(File(path), UserMgr.getUid(), object : ResultCallback<UploadFile>() {
                    override fun onSuccess(result: ResultEntity<UploadFile>) {
                        user?.head = result.data.url
                        showUserInfo()
                        dismissProgress()
                        updateUserInfo(
                            user!!.uid,
                            result.data.url,
                            null,
                            null,
                            null
                        )
                    }

                    override fun onFailure(err: String, code: Int) {
                        super.onFailure(err, code)
                        dismissProgress()
                    }
                }
                )
        }
    }
}