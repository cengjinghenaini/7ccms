package com.xizhu.qiyou.entity;

import android.os.Parcel;
import android.os.Parcelable;

public class Game extends Label implements Parcelable {

    private String is_update;

    protected Game(Parcel in) {
        super(in);
        is_update = in.readString();
    }

    public String getIs_update() {
        return is_update;
    }
    public void setIs_update(String is_update) {
        this.is_update = is_update;
    }

}
