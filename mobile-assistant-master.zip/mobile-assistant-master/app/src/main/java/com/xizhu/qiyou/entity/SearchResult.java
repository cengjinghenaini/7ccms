package com.xizhu.qiyou.entity;

import java.util.List;

public class SearchResult {

    private List<BaseSheet> sheets;
    private List<BaseApp> apps;
    private List<User> users;

    public List<BaseSheet> getSheets() {
        return sheets;
    }

    public void setSheets(List<BaseSheet> sheets) {
        this.sheets = sheets;
    }

    public List<BaseApp> getApps() {
        return apps;
    }

    public void setApps(List<BaseApp> apps) {
        this.apps = apps;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }


}
