package com.xizhu.qiyou.apps;

/**
 * @ClassName 下载状态
 * @Description 游戏详情页面的状态
 * @Author guchu
 * @Date 2021/8/13 20:49
 * @Version 1.0  NOT_INSTALLED 本地尚未安装  NOT_UPDATED  需要但是尚未进行更新
 */
public enum AppStatus {
    NOT_INSTALLED, NOT_UPDATED, WAIT_4_DOWNLOAD, DOWNLOADING, WAIT_4_UNZIP, UNZIPPING, WAIT_4_INSTALL, INSTALLED,
    PAUSED_NOT_DOWNLOAD, PAUSED_DOWNLOADING, PAUSED_NOT_UNZIP, PAUSED_UNZIPPING, PAUSED_INSTALLED
}
