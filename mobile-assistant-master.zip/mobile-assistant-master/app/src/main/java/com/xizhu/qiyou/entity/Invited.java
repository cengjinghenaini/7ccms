package com.xizhu.qiyou.entity;

public class Invited {

    /**
     * invite_code : MQ==
     * today_count : 0
     * sum_count : 0
     * sum_integral : 0
     */

    private String invite_code;
    private String today_count;
    private String sum_count;
    private int sum_integral;

    public String getInvite_code() {
        return invite_code;
    }

    public void setInvite_code(String invite_code) {
        this.invite_code = invite_code;
    }

    public String getToday_count() {
        return today_count;
    }

    public void setToday_count(String today_count) {
        this.today_count = today_count;
    }

    public String getSum_count() {
        return sum_count;
    }

    public void setSum_count(String sum_count) {
        this.sum_count = sum_count;
    }

    public int getSum_integral() {
        return sum_integral;
    }

    public void setSum_integral(int sum_integral) {
        this.sum_integral = sum_integral;
    }
}

