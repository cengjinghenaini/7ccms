package com.xizhu.qiyou.ui.collect

import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.Collect
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.widget.EmptyView
import kotlinx.android.synthetic.main.activity_browser_history.*
import kotlinx.android.synthetic.main.title_layout.*

class CollectListActivity : BaseCompatActivity() {
    private var adapter: CollectListAdapter? = null

    override fun getRes(): Int {
        return R.layout.activity_browser_history
    }

    override fun initView() {
        iv_back.setOnClickListener {
            finish()
        }
        tv_page_title.text = "收藏"
        refresh_layout?.setOnRefreshListener {
            getCollectList()
        }
        empty_view?.setLoadListener {
            getCollectList()
        }
        recycler.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        adapter = CollectListAdapter().apply {
            setEmptyView(EmptyView(this@CollectListActivity).setNoData())
            setOnItemClickListener { _, _, position ->
                val item = getItem(position)
                JumpUtils.jumpToGameDetailsPage(this@CollectListActivity,item.id)
            }
        }
        recycler.adapter = adapter
    }


    override fun onResume() {
        super.onResume()
        getCollectList()
    }

    private fun getCollectList() {
        val uid = UserMgr.getUid()
        HttpUtil.getInstance().getCollectRecord(
            uid,
            Constant.Collect_app,
            object : ResultCallback<MutableList<Collect>>() {
                override fun onSuccess(s: ResultEntity<MutableList<Collect>>) {
                    val data = s.data
                    adapter?.setNewInstance(data)
                    refresh_layout?.finishRefresh()
                    empty_view?.visibility = View.GONE
                }

                override fun onFailure(err: String?, code: Int) {
                    super.onFailure(err, code)
                    refresh_layout?.finishRefresh(false)
                    if (empty_view?.visibility == View.VISIBLE) {
                        empty_view?.setLoadFail()
                    }
                }
            })
    }
}