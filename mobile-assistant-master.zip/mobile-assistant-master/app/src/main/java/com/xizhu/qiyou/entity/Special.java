package com.xizhu.qiyou.entity;

import java.io.Serializable;
import java.util.List;

public class Special implements Serializable {

    /**
     * "id": "3",
     * "type": "0",
     * "pic": "https:%/%/7you-1304371138.file.myqcloud.com%/application%/Special%/202101211127%/6008f493ba729.jpg",
     * "name": "双人游戏",
     * "desc": "<p>游戏的魅力不单单只在于精美的画面，优秀的剧情，动听的音乐，有趣的玩法，通过互动的方式与朋友分享游戏的乐趣这也是游戏的一大魅力，这种魅力除了常见的多人联网游戏可以展现外，本地双人游戏也能很好的展现~（孤狼痛哭中……）<%/p>",
     * "app_ids": "2036",
     * "createtime": "1611199810"
     */

    private String id;
    protected String type;
    private String pic;
    private String name;
    private String desc;
    private String app_ids;
    private String createtime;
    private List<BaseApp> apps;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<BaseApp> getApps() {
        return apps;
    }

    public void setApps(List<BaseApp> apps) {
        this.apps = apps;
    }
}
