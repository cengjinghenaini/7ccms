package com.xizhu.qiyou.util.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.xizhu.qiyou.R;


public class UnzipProgressDialog extends Dialog {

    private TextView cp_tv;
    private TextView current_tv;
    private TextView file_name_tv;

    public UnzipProgressDialog(@NonNull Context context) {
        super(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_progress);
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.width = 450;
        lp.height = 260;
        lp.gravity = Gravity.CENTER;
        getWindow().setAttributes(lp);
        getWindow().setBackgroundDrawable(new ColorDrawable(0x00000000));

        cp_tv = findViewById(R.id.cp_tv);
        cp_tv.setTextSize(20);
        current_tv = findViewById(R.id.current_tv);
        file_name_tv = findViewById(R.id.file_name_tv);
        current_tv.setVisibility(View.GONE);
        file_name_tv.setVisibility(View.GONE);
        cp_tv.setText("正在解压中，请稍后...");

    }

}
