package com.xizhu.qiyou.entity;

/**
 * @ClassName GradeBean
 * @Description TODO
 * @Author guchu
 * @Date 2021/8/30 21:26
 * @Version 1.0
 */
public class GradeBean {
    private long createtime;
    private String createtime_text;
    private String desc;

    public long getCreatetime() {
        return createtime;
    }

    public void setCreatetime(long createtime) {
        this.createtime = createtime;
    }

    public String getCreatetime_text() {
        return createtime_text;
    }

    public void setCreatetime_text(String createtime_text) {
        this.createtime_text = createtime_text;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIntegral() {
        return integral;
    }

    public void setIntegral(int integral) {
        this.integral = integral;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getType_text() {
        return type_text;
    }

    public void setType_text(String type_text) {
        this.type_text = type_text;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public int getValue_id() {
        return value_id;
    }

    public void setValue_id(int value_id) {
        this.value_id = value_id;
    }

    private int id;
    private int integral;
    private int type;
    private String type_text;
    private String uid;
    private String user_name;
    private int value_id;

}
