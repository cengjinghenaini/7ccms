package com.xizhu.qiyou.entity;

public class BillDesc {

    /**
     * id : 1
     * cate : 0
     * icon : http://7you-1304371138.cos.ap-nanjing.myqcloud.com/1
     * content : 1
     */

    private String id;
    private String cate;
    private String icon;
    private String content;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCate() {
        return cate;
    }

    public void setCate(String cate) {
        this.cate = cate;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
