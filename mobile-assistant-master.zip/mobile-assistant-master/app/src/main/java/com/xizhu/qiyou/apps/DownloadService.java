package com.xizhu.qiyou.apps;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import com.liulishuo.filedownloader.BaseDownloadTask;
import com.liulishuo.filedownloader.FileDownloadSampleListener;
import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.util.FileDownloadUtils;
import com.pass.util.NetUtil;
import com.xizhu.qiyou.room.entity.AppEntity;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @ClassName DownloadService
 * @Description
 * @Author guchu
 * @Date 2021/8/16 16:28
 * @Version 1.0
 */

public class DownloadService extends Service {

    class TempBean {
        int taskId;
        String downloadUrl;
        String downloadPath;

        public TempBean(int taskId, String downloadUrl, String downloadPath) {
            this.taskId = taskId;
            this.downloadUrl = downloadUrl;
            this.downloadPath = downloadPath;
        }
    }

    public static final String TAG = DownloadService.class.getSimpleName();
    private MyBinder mBinder = new MyBinder();
    private AppRepository mAppRepository;
    private Map<String, TempBean> mMaps = new HashMap<>();   //仅仅在UI线程进行访问. 仅仅添加一个.

    public class MyBinder extends Binder {
        public DownloadService getService() {
            return DownloadService.this;
        }
    }

    /**
     * App新启动
     */
    private void appStart() {
        //可能会有isWorking的.
        //然后再是inQueue.
        List<AppEntity> downloadingList = mAppRepository.getDownloadingApps();
        if (downloadingList.size() > 0) {
            for (AppEntity appEntity : downloadingList) {
                startDownload(appEntity);
            }
        }

        List<AppEntity> queueingApps = mAppRepository.getInQueueDownloadApps();
        if (queueingApps.size() > 0) {
            for (AppEntity appEntity : queueingApps) {
                startDownload(appEntity);
            }
        }

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand");
        if (intent == null) {
            return super.onStartCommand(null, flags, startId);
        }
        AppEntity appEntity = intent.getParcelableExtra("bean");
        if (appEntity != null) {
            boolean paused = intent.getBooleanExtra("paused", false);
            if (paused) {
                manualPauseDownload(appEntity);
            } else {
                startDownload(appEntity);
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }

    public void startDownload(AppEntity appEntity) {
        appEntity.setQueueTimeInMill(System.currentTimeMillis());

        if (mMaps.keySet().size() >= 1) {
            appEntity.setIsWorking(AppEntity.TYPE_IN_QUEUE);
            mAppRepository.update(appEntity);
            return;
        }
        appEntity.setIsWorking(AppEntity.TYPE_WORKING);
        mAppRepository.update(appEntity);
        int taskId = startDownloadImpl(appEntity.getDownloadUrl(), appEntity.getDownPath());
        mMaps.put(appEntity.getDownloadUrl(), new TempBean(taskId, appEntity.getDownloadUrl(), appEntity.getDownPath()));
        NetUtil.NET_TYPE netType = NetUtil.getNetType(getApplicationContext());
        switch (netType) {
            case TYPE_NONE: {
                FileDownloader.getImpl().pause(taskId);
                mAppRepository.update(appEntity);
                break;
            }
            case TYPE_WIFI:
            case TYPE_4G:
            case TYPE_ETHERNET: {
                //ignore.
                break;
            }
//            case TYPE_4G: {
//                boolean allow4G = ((QiYouApp) getApplication()).mAllow4G;
//                if (!allow4G) {
//                    FileDownloader.getImpl().pause(taskId);
//                    mAppRepository.update(appEntity);
//                }
//                break;
//            }
        }
    }

    public int startDownloadImpl(String downloadUrl, String downloadPath) {

        BaseDownloadTask singleTask = FileDownloader.getImpl().create(downloadUrl)
                .setPath(downloadPath, false)
                .setMinIntervalUpdateSpeed(400)
                .setForceReDownload(true)
                .setListener(new FileDownloadSampleListenerImpl());
        int taskId = singleTask.start();
        return taskId;
    }

    class FileDownloadSampleListenerImpl extends FileDownloadSampleListener {
        @Override
        protected void pending(BaseDownloadTask task, int soFarBytes, int totalBytes) {
//            Log.d("feifei", "pending taskId:" + task.getId() + ",soFarBytes:" + soFarBytes + ",totalBytes:" + totalBytes + ",percent:" + soFarBytes * 1.0 / totalBytes);

        }

        @Override
        protected void progress(BaseDownloadTask task, int soFarBytes, int totalBytes) {
//            Log.d("feifei", "progress taskId:" + task.getId() + "," +
//                    "soFarBytes:" + soFarBytes + ",totalBytes:" + totalBytes +
//                    ",percent:" + soFarBytes * 1.0 / totalBytes +
//                    ",speed:" + task.getSpeed());
            int currentSpeed = task.getSpeed() << 10;
            int p = (int) (soFarBytes * 100.0 / totalBytes);
            Log.d("feifei", "" + soFarBytes * 1.0 / totalBytes);
            Log.d("feifei", "" + p);
            final AppEntity appEntity = mAppRepository.getAppByDownloadUrl(task.getUrl());
            if (appEntity != null) {
                appEntity.setDownloadProgress(p);
                appEntity.setDownSpeed(currentSpeed);
                mAppRepository.update(appEntity);
            }
        }

        @Override
        protected void blockComplete(BaseDownloadTask task) {
            Log.d("feifei", "blockComlpete taskId:" + task.getId() + ",filePath:" + task.getPath() + ",fileName:" + task.getFilename() + ",speed:" + task.getSpeed() + ",isReuse:" + task.reuse());

            if (mMaps.get(task.getUrl()) == null) {
                return;
            }
            mMaps.remove(task.getUrl());
            List<AppEntity> appEntities = mAppRepository.getInQueueDownloadApps();
            if (appEntities.size() > 0) {
                startDownload(appEntities.get(0));
            }
            final AppEntity appEntity = mAppRepository.getAppByDownloadUrl(task.getUrl());
            appEntity.setQueueTimeInMill(0);
            appEntity.setDownloadProgress(100);
            mAppRepository.update(appEntity);
            if (task.getUrl().endsWith(".zip")) {
                Intent intent = new Intent(DownloadService.this, UnzipService.class);
                intent.putExtra("bean", appEntity);
                startService(intent);
                return;
            }
            SimpleRealApp appInfo = AppUtil.apkInfo(appEntity.getDownPath(), getApplicationContext());
            if (null == appInfo) {
                File downloadFile = new File(appEntity.getDownPath());
                if (downloadFile.exists()) {
                    downloadFile.delete();
                }
                appEntity.clear();
                mAppRepository.update(appEntity);
                return;
            }
            Log.e(TAG, "blockComlpete: " + appInfo.getPackageName());
            appEntity.setRealVersion(appInfo.getVersionName());
            appEntity.setRealPackage(appInfo.getPackageName());
            boolean hasInstalled = AppUtil.install(getApplicationContext(), appEntity);
            if (hasInstalled) {
                appEntity.setIsInstalled(AppEntity.TYPE_INSTALLED);
            }
            mAppRepository.update(appEntity);
        }

        @Override
        protected void completed(BaseDownloadTask task) {
//            Log.d("feifei", "completed taskId:" + task.getId() + ",isReuse:" + task.reuse());
        }

        @Override
        protected void paused(BaseDownloadTask task, int soFarBytes, int totalBytes) {
//            Log.d("feifei", "paused taskId:" + task.getId() + ",soFarBytes:" + soFarBytes + ",totalBytes:" + totalBytes + ",percent:" + soFarBytes * 1.0 / totalBytes);
//            ToastUtil.show("paused");
        }

        @Override
        protected void error(BaseDownloadTask task, Throwable e) {
//            Log.d("feifei", "error taskId:" + task.getId() + ",e:" + e.getLocalizedMessage());
//            ToastUtil.show("error");
            TempBean tempBean = mMaps.get(task.getUrl());
            startDownloadImpl(tempBean.downloadUrl, tempBean.downloadPath);

        }

        @Override
        protected void warn(BaseDownloadTask task) {
//            Log.d("feifei", "warn taskId:" + task.getId());
//            ToastUtil.show("warn");
        }
    }

//
//    @Subscribe(threadMode = ThreadMode.MAIN)
//    public void handleSetNet(SetNetEvent setNetEvent) {
//        NetUtil.NET_TYPE netType = NetUtil.getNetType(getApplicationContext());
//        if (setNetEvent.allow4G) {
//            if (netType.ordinal() == NetUtil.NET_TYPE.TYPE_4G.ordinal()) {
//                Iterator<TempBean> iterator = mMaps.values().iterator();
//                while (iterator.hasNext()) {
//                    TempBean tempBean = iterator.next();
//                    startDownloadImpl(tempBean.downloadUrl, tempBean.downloadPath);
//                }
//            }
//            return;
//        }
//        if (netType.ordinal() == NetUtil.NET_TYPE.TYPE_4G.ordinal()) {
//            Iterator<TempBean> iterator = mMaps.values().iterator();
//            while (iterator.hasNext()) {
//                TempBean tempBean = iterator.next();
//                FileDownloader.getImpl().pause(tempBean.taskId);
//                AppEntity appEntity = mAppRepository.getAppByDownloadUrl(tempBean.downloadUrl);
//                mAppRepository.update(appEntity);
//            }
//        }
//    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void handleNetChange(CurrentNetEvent currentNetEvent) {
        if (currentNetEvent.netType == CurrentNetEvent.TYPE_NONE) {
            Iterator<TempBean> iterator = mMaps.values().iterator();
            while (iterator.hasNext()) {
                TempBean tempBean = iterator.next();
                AppEntity appEntity = mAppRepository.getAppByDownloadUrl(tempBean.downloadUrl);
                mAppRepository.update(appEntity);
            }
        } else if (currentNetEvent.netType == CurrentNetEvent.TYPE_WIFI ||
                currentNetEvent.netType == CurrentNetEvent.TYPE_ETHERNET || currentNetEvent.netType == CurrentNetEvent.TYPE_4G
        ) {
            Iterator<TempBean> iterator = mMaps.values().iterator();
            while (iterator.hasNext()) {
                TempBean tempBean = iterator.next();
                startDownloadImpl(tempBean.downloadUrl, tempBean.downloadPath);
            }
//        } else if (currentNetEvent.netType == CurrentNetEvent.TYPE_4G) {
//            boolean allow4G = ((QiYouApp) getApplication()).mAllow4G;
//            if (!allow4G) {
//                Iterator<TempBean> iterator = mMaps.values().iterator();
//                while (iterator.hasNext()) {
//                    TempBean tempBean = iterator.next();
//                    FileDownloader.getImpl().pause(tempBean.taskId);
//                    AppEntity appEntity = mAppRepository.getAppByDownloadUrl(tempBean.downloadUrl);
//                    mAppRepository.update(appEntity);
//                }
//            } else {
//                Iterator<TempBean> iterator = mMaps.values().iterator();
//                while (iterator.hasNext()) {
//                    TempBean tempBean = iterator.next();
//                    startDownloadImpl(tempBean.downloadUrl, tempBean.downloadPath);
//
//                }
//            }
        }

    }

    public void manualPauseDownload(AppEntity appEntity) {
        if (null == mMaps.get(appEntity.getDownloadUrl())) {
            return;
        }
        appEntity.setQueueTimeInMill(0);
        appEntity.setIsManualPaused(AppEntity.TYPE_MANUAL_PAUSED);
        mAppRepository.update(appEntity);
        TempBean tempBean = mMaps.get(appEntity.getDownloadUrl());
        mMaps.remove(appEntity.getDownloadUrl());
        FileDownloader.getImpl().pause(tempBean.taskId);
        List<AppEntity> appEntities = mAppRepository.getInQueueDownloadApps();
        for (AppEntity appEntity1 : appEntities) {
            if (appEntity1 == appEntity) {
                continue;
            }
            startDownload(appEntity1);
            return;
        }
    }

    public void cancelDownload(AppEntity appEntity) {
        TempBean tempBean = mMaps.get(appEntity.getDownloadUrl());
        mAppRepository.delete(appEntity);
        mMaps.remove(appEntity.getDownloadUrl());
        deleteTask(tempBean);
        List<AppEntity> appEntities = mAppRepository.getInQueueDownloadApps();
        if (appEntities.size() > 0) {
            startDownload(appEntities.get(0));
        }
    }

    private void deleteTask(TempBean tempBean) {
        File dstFile = new File(tempBean.downloadPath);
        boolean deleteData = FileDownloader.getImpl().clear(tempBean.taskId, dstFile.getParent());
        File targetFile = new File(tempBean.downloadPath);
        boolean delate = false;
        if (targetFile.exists()) {
            delate = targetFile.delete();
        }
        new File(FileDownloadUtils.getTempPath(tempBean.downloadPath)).delete();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");
        mAppRepository = new AppRepository(getApplication());
        EventBus.getDefault().register(this);
        appStart();
    }

    @Override
    public void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();

    }

}
