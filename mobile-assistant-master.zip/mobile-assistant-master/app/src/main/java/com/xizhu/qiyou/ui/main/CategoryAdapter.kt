package com.xizhu.qiyou.ui.main

import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.Cate
import com.xizhu.qiyou.util.ImgLoadUtil

class CategoryAdapter : BaseQuickAdapter<Cate, BaseViewHolder>(R.layout.item_recy_game_category) {
    override fun convert(holder: BaseViewHolder, item: Cate) {
        holder.setText(R.id.tv_name, item.name)
        ImgLoadUtil.load(holder.getView(R.id.iv_head), item.logo)
    }
}