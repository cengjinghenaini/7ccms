package com.xizhu.qiyou.entity;

public class DownApp {
    private String app_id;
    private String icon;
    private String name;

    public DownApp(String app_id, String icon, String name) {
        this.app_id = app_id;
        this.icon = icon;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}
