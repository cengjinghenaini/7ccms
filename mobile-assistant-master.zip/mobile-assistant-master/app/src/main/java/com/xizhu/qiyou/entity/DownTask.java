package com.xizhu.qiyou.entity;

public class DownTask {

    /**
     * id : 1
     * app_id :
     * integral :
     * createtime :
     */

    private String id;
    private String app_id;
    private String integral;
    private String createtime;
    private BaseApp app;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public BaseApp getApp() {
        return app;
    }

    public void setApp(BaseApp app) {
        this.app = app;
    }
}
