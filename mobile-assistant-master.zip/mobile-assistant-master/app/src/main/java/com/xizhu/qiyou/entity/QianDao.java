package com.xizhu.qiyou.entity;

public class QianDao {

    /**
     * integral : 0
     * exp : 0
     * contribution : 0
     */

    private Integer integral;
    private Integer exp;
    private Integer contribution;

    public Integer getIntegral() {
        return integral;
    }

    public void setIntegral(Integer integral) {
        this.integral = integral;
    }

    public Integer getExp() {
        return exp;
    }

    public void setExp(Integer exp) {
        this.exp = exp;
    }

    public Integer getContribution() {
        return contribution;
    }

    public void setContribution(Integer contribution) {
        this.contribution = contribution;
    }
}
