package com.xizhu.qiyou.wxapi;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.google.gson.Gson;
import com.tencent.mm.opensdk.constants.ConstantsAPI;
import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;
import com.xizhu.qiyou.config.Constant;
import com.xizhu.qiyou.config.WXQQConfig;
import com.xizhu.qiyou.entity.Events.Finish;
import com.xizhu.qiyou.entity.Events.WXBind;
import com.xizhu.qiyou.entity.NULL;
import com.xizhu.qiyou.entity.User;
import com.xizhu.qiyou.entity.WXToken;
import com.xizhu.qiyou.entity.WXUser;
import com.xizhu.qiyou.http.HttpUtil;
import com.xizhu.qiyou.http.result.ResultCallback;
import com.xizhu.qiyou.http.result.ResultEntity;
import com.xizhu.qiyou.ui.account.LoginActivity;
import com.xizhu.qiyou.util.LogUtil;
import com.xizhu.qiyou.util.PhoneUtil;
import com.xizhu.qiyou.util.UserMgr;
import com.xizhu.qiyou.util.WXQQ;
import com.xizhu.qiyou.util.dialog.ToastUtil;
import com.xizhu.qiyou.widget.LoadingDialog;

import org.greenrobot.eventbus.EventBus;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class WXEntryActivity extends Activity implements IWXAPIEventHandler {


    private static final String TAG = "WXEntryActivity";
    private LoadingDialog loadingDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WXQQ.getWXAPI().handleIntent(getIntent(), this);
    }

    //微信请求相应
    @Override
    public void onReq(BaseReq baseReq) {

    }

    //发送到微信请求的响应结果
    @Override
    public void onResp(BaseResp resp) {
        LogUtil.e("sssssssssssssonResp: " + resp.errCode);
        int type = resp.getType();
        if (type == ConstantsAPI.COMMAND_SENDMESSAGE_TO_WX) {
            switch (resp.errCode) {
                case BaseResp.ErrCode.ERR_OK:
                    ToastUtil.show("分享成功");
                    break;
                case BaseResp.ErrCode.ERR_USER_CANCEL:
                    ToastUtil.show("取消分享");
                    break;
                case BaseResp.ErrCode.ERR_SENT_FAILED:
                    ToastUtil.show("分享失败");
                    break;
                default:
                    ToastUtil.show("未知原因");
                    break;
            }
        } else if (type == ConstantsAPI.COMMAND_PAY_BY_WX) {
            switch (resp.errCode) {
                case BaseResp.ErrCode.ERR_OK:
                    ToastUtil.show("支付完成");
                    break;
                case BaseResp.ErrCode.ERR_USER_CANCEL:
                    ToastUtil.show("取消支付");
                    break;
                case BaseResp.ErrCode.ERR_SENT_FAILED:
                    ToastUtil.show("支付失败");
                    break;
                default:
                    ToastUtil.show("未知原因");
                    break;
            }
        } else if (type == ConstantsAPI.COMMAND_SENDAUTH) {
            switch (resp.errCode) {
                case BaseResp.ErrCode.ERR_OK:
                    SendAuth.Resp newResp = (SendAuth.Resp) resp;
                    //获取微信传回的code
                    String code = newResp.code;
                    LogUtil.e("onResp code = " + code);
                    //获取token
//                        loadingDialog = new LoadingDialog(this, R.style.DialogRing);
//                        loadingDialog.show();
                    getToken(code);
                    break;
                case BaseResp.ErrCode.ERR_USER_CANCEL:
                    Log.i("WXTest", "onResp ERR_USER_CANCEL ");
                    //发送取消
                    break;
                case BaseResp.ErrCode.ERR_AUTH_DENIED:
                    Log.i("WXTest", "onResp ERR_AUTH_DENIED");
                    //发送被拒绝
                    break;
                default:
                    Log.i("WXTest", "onResp default errCode " + resp.errCode);
                    //发送返回
                    break;
            }
        }
        finish();
    }

    private void getToken(String code) {
        FormBody.Builder builder = new FormBody.Builder();
        builder.add("appid", WXQQConfig.APP_ID);
        builder.add("secret", WXQQConfig.AppSecret);
        builder.add("code", code);
        builder.add("grant_type", "authorization_code");
        Request r = new Request.Builder()
                .post(builder.build())
                .url(WXQQConfig.GetToken)
                .build();

        OkHttpClient client = new OkHttpClient.Builder()
                .build();
        Call call = client.newCall(r);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                LogUtil.e("onFailure: " + e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String body = response.body().string();
                LogUtil.e("onResponse: " + body);
                WXToken wxToken = new Gson().fromJson(body, WXToken.class);
                if (wxToken.getOpenid() != null) {
                    getUserInfo(wxToken);
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ToastUtil.show("invalid appsecret 40125");
                        }
                    });
                }
            }
        });
    }

    private void getUserInfo(WXToken wxToken) {
        FormBody.Builder builder = new FormBody.Builder();
        builder.add("access_token", wxToken.getAccess_token());
        builder.add("openid", wxToken.getOpenid());
        Request r = new Request.Builder()
                .post(builder.build())
                .url(WXQQConfig.GetUserInfo)
                .build();
        OkHttpClient client = new OkHttpClient.Builder()
                .build();
        Call call = client.newCall(r);
        LogUtil.e("getUserInfo: ");
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                LogUtil.e("onFailure: " + e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String body = response.body().string();
                WXUser wxUser = new Gson().fromJson(body, WXUser.class);
                if (Constant.WX_IS_BIND) {
                    bindWX(wxUser);
                } else {
                    otherLoginCheck(wxUser);
                }
            }
        });
    }

    private void bindWX(WXUser wxUser) {
        HttpUtil.getInstance().bindWxQq(UserMgr.getUid(), "0", wxUser.getOpenid(), new ResultCallback<NULL>() {
            @Override
            public void onSuccess(ResultEntity<NULL> s) {
                EventBus.getDefault().post(new WXBind(true));
                if (loadingDialog != null && loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }
            }
        });

    }

    private void otherLoginCheck(WXUser wxUser) {
        HttpUtil.getInstance().otherLoginCheck(Constant.LOGIN_BY_WX, wxUser.getOpenid(), null, null, new ResultCallback<User>() {
            @Override
            public void onSuccess(ResultEntity<User> s) {
                User data = s.getData();
                int isRegister = data.getIsRegister();
                if (0 != isRegister) {
                    EventBus.getDefault().post(new Finish(LoginActivity.class));
                    UserMgr.setUid(s.getData().getUid());
                    PhoneUtil.putSpUid(WXEntryActivity.this, s.getData().getUid());
                    EventBus.getDefault().post(s.getData());
                }
                if (loadingDialog != null && loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }
            }
        });
    }
}