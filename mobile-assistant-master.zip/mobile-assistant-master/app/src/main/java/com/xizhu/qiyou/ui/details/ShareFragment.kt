package com.xizhu.qiyou.ui.details

import android.os.Bundle
import com.tencent.connect.share.QQShare
import com.tencent.tauth.IUiListener
import com.tencent.tauth.UiError
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseBottomDialogFragment
import com.xizhu.qiyou.config.API
import com.xizhu.qiyou.entity.DetailGame
import com.xizhu.qiyou.util.PhoneUtil
import com.xizhu.qiyou.util.WXQQ
import com.xizhu.qiyou.util.dialog.ToastUtil
import kotlinx.android.synthetic.main.fragment_share.*

class ShareFragment : BaseBottomDialogFragment() {
    private var data: DetailGame? = null
    private var block: (() -> Unit)? = null

    companion object {
        fun instance(data: DetailGame?, block: () -> Unit): ShareFragment {
            val fragment = ShareFragment()
            fragment.data = data
            fragment.block = block
            return fragment
        }
    }

    override fun getLayoutId(): Int {
        return R.layout.fragment_share
    }

    override fun initView() {
        iv_close.setOnClickListener {
            dismissAllowingStateLoss()
        }
        tv_qq.setOnClickListener {
            if (!PhoneUtil.hasQQ(activity)) {
                ToastUtil.show("未安装QQ")
                return@setOnClickListener
            }
            dismissAllowingStateLoss()
            val params = Bundle()
            params.putInt(QQShare.SHARE_TO_QQ_KEY_TYPE, QQShare.SHARE_TO_QQ_TYPE_DEFAULT) //分享的类型
            params.putString(QQShare.SHARE_TO_QQ_TITLE, data?.name) //分享标题
            params.putString(QQShare.SHARE_TO_QQ_SUMMARY, data?.introduction) //要分享的内容摘要
            params.putString(QQShare.SHARE_TO_QQ_TARGET_URL, API.MASTER) //内容地址
            params.putString(QQShare.SHARE_TO_QQ_IMAGE_URL, data?.icon) //分享的图片URL
            params.putString(
                QQShare.SHARE_TO_QQ_APP_NAME, getString(R.string.app_name)
            ) //应用名称
            block?.invoke()
            WXQQ.getQQ().shareToQQ(activity, params, object : IUiListener {
                override fun onComplete(o: Any) {

                }

                override fun onError(uiError: UiError) {}
                override fun onCancel() {}
                override fun onWarning(i: Int) {}
            })
        }
    }

    override fun initData() {

    }
}