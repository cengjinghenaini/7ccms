package com.xizhu.qiyou.ui.main

import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.Shaky
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.UnitUtil

class MessageAdapter : BaseQuickAdapter<Shaky, BaseViewHolder>(R.layout.item_recy_message) {
    override fun convert(holder: BaseViewHolder, item: Shaky) {
        holder.setText(R.id.tv_content, item.name)
        holder.setText(R.id.tv_date, UnitUtil.time(item.createtime))
        ImgLoadUtil.load(holder.getView(R.id.iv_content), item.pic)
    }
}