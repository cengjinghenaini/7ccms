package com.xizhu.qiyou.room.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.xizhu.qiyou.room.entity.Replace;

import java.util.List;

@Dao
public interface ReplaceDao {
    @Insert
    void insert(Replace replace);

    @Query("select * from replaces order by id desc")
    List<Replace> queryAll();

    @Query("select * from replaces where target=(:raw)")
    Replace findByRaw(String raw);

    @Query("delete from replaces")
    void delAll();

    @Query("delete from replaces where target=(:raw)")
    void delByRaw(String raw);

    @Update
    void update(Replace replace);
}
