package com.xizhu.qiyou.util

import android.content.Context
import com.qmuiteam.qmui.skin.QMUISkinManager
import com.qmuiteam.qmui.widget.dialog.QMUIDialog.MessageDialogBuilder
import com.qmuiteam.qmui.widget.dialog.QMUIDialogAction
import com.xizhu.qiyou.R

object DialogUtils {
    fun showTipsDialog(
        context: Context,
        title: String = "提示",
        message: CharSequence,
        cancelText: String = "知道了",
        cancelable: Boolean = true,
        onclickListener: () -> Unit = {}
    ) {
        MessageDialogBuilder(context)
            .setTitle(title)
            .setSkinManager(QMUISkinManager.defaultInstance(context))
            .setMessage(message)
            .addAction(0, cancelText, QMUIDialogAction.ACTION_PROP_NEGATIVE) { dialog, _ ->
                dialog.dismiss()
                onclickListener.invoke()
            }.setCancelable(cancelable)
            .create(R.style.DialogTheme2).show()
    }
}