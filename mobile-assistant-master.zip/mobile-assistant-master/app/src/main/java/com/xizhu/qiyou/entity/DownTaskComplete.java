package com.xizhu.qiyou.entity;

public class DownTaskComplete {

    /**
     * id : 1
     * type :
     * task_count :
     * integral :
     * contribution :
     * is_complete :
     * complete_count :
     */

    private String id;
    private String type;
    private String task_count;
    private String integral;
    private String contribution;
    private String is_complete;
    private String complete_count;
    private String name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTask_count() {
        return task_count;
    }

    public void setTask_count(String task_count) {
        this.task_count = task_count;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getContribution() {
        return contribution;
    }

    public void setContribution(String contribution) {
        this.contribution = contribution;
    }

    public String getIs_complete() {
        return is_complete;
    }

    public void setIs_complete(String is_complete) {
        this.is_complete = is_complete;
    }

    public String getComplete_count() {
        return complete_count;
    }

    public void setComplete_count(String complete_count) {
        this.complete_count = complete_count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
