package com.xizhu.qiyou.entity;

public class Forum {

    private String id;
    private String icon;
    private String name;
    private String gambit_count;
    private int is_attention;
    private String hot_count;
    private int is_signin;
    private String grade_id;
    private String grade_name;
    private String posts_count;

    private int res;

    public int getIs_signin() {
        return is_signin;
    }

    public void setIs_signin(int is_signin) {
        this.is_signin = is_signin;
    }


    public void setHot_count(String hot_count) {
        this.hot_count = hot_count;
    }

    public void setGambit_count(String gambit_count) {
        this.gambit_count = gambit_count;
    }

    public void setIs_attention(int is_attention) {
        this.is_attention = is_attention;
    }


    public String getHot_count() {
        return hot_count;
    }

    public String getGambit_count() {
        return gambit_count;
    }

    public int getIs_attention() {
        return is_attention;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRes() {
        return res;
    }

    public void setRes(int res) {
        this.res = res;
    }

    public String getGrade_id() {
        return grade_id;
    }

    public void setGrade_id(String grade_id) {
        this.grade_id = grade_id;
    }

    public String getGrade_name() {
        return grade_name;
    }

    public void setGrade_name(String grade_name) {
        this.grade_name = grade_name;
    }

    public String getPosts_count() {
        return posts_count;
    }

    public void setPosts_count(String posts_count) {
        this.posts_count = posts_count;
    }
}
