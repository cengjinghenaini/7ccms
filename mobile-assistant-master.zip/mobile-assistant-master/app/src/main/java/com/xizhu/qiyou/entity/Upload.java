package com.xizhu.qiyou.entity;

public class Upload {


    /**
     * key : file
     * originUrl : /Uploads/Picture/20201105/9fa749de16bb4016.png
     * smallUrl : /Uploads/Picture/20201105/s_9fa749de16bb4016.png
     * id : 0f39f81ded6265b3dab2c4ad49213c82
     * size : 3495
     * show_url : http://www.7you.cn/Uploads/Picture/20201105/s_9fa749de16bb4016.png
     */

    private String key;
    private String originUrl;
    private String smallUrl;
    private String id;
    private int size;
    private String show_url;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getOriginUrl() {
        return originUrl;
    }

    public void setOriginUrl(String originUrl) {
        this.originUrl = originUrl;
    }

    public String getSmallUrl() {
        return smallUrl;
    }

    public void setSmallUrl(String smallUrl) {
        this.smallUrl = smallUrl;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getShow_url() {
        return show_url;
    }

    public void setShow_url(String show_url) {
        this.show_url = show_url;
    }

    @Override
    public String toString() {
        return "Upload{" +
                "key='" + key + '\'' +
                ", originUrl='" + originUrl + '\'' +
                ", smallUrl='" + smallUrl + '\'' +
                ", id='" + id + '\'' +
                ", size=" + size +
                ", show_url='" + show_url + '\'' +
                '}';
    }
}
