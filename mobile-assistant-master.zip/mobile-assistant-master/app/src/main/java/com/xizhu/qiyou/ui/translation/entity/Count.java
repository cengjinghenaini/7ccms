package com.xizhu.qiyou.ui.translation.entity;

public class Count {
    int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Count(int count) {

        this.count = count;
    }
}
