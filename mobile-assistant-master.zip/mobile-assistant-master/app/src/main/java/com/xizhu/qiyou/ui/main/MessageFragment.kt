package com.xizhu.qiyou.ui.main

import android.content.Intent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.scwang.smart.refresh.layout.api.RefreshLayout
import com.scwang.smart.refresh.layout.listener.OnRefreshLoadMoreListener
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.Events.UnreadEvent
import com.xizhu.qiyou.entity.Shaky
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.ui.details.MessageDetailsActivity
import com.xizhu.qiyou.ui.search.NewSearchActivity
import com.xizhu.qiyou.util.UnitUtil
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.widget.EmptyView
import kotlinx.android.synthetic.main.fragment_game.statusBar
import kotlinx.android.synthetic.main.fragment_message.*
import org.greenrobot.eventbus.EventBus

class MessageFragment : BaseFragment() {
    private var adapter: MessageAdapter? = null
    private var pageNum = 1

    override fun getRes(): Int {
        return R.layout.fragment_message
    }

    override fun initView() {
        super.initView()
        refresh_layout?.setOnRefreshLoadMoreListener(object : OnRefreshLoadMoreListener {
            override fun onRefresh(refreshLayout: RefreshLayout) {
                pageNum = 1
                getActiveList()
            }

            override fun onLoadMore(refreshLayout: RefreshLayout) {
                pageNum++
                getActiveList()
            }
        })
        empty_view?.setLoadListener {
            pageNum = 1
            getActiveList()
        }
        statusBar?.layoutParams?.height = UnitUtil.getStatusBarHeight(activity)
        tv_search_box?.setOnClickListener {
            startActivity(Intent(activity, NewSearchActivity::class.java))
        }
        my_game?.setOnClickListener {
            JumpUtils.jumpToDownloadManagerPage(context)
        }
        recycler.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        adapter = MessageAdapter().apply {
            setEmptyView(EmptyView(requireActivity()).setNoData())
        }
        adapter?.setOnItemClickListener { _, _, position ->
            val item = adapter!!.getItem(position)
            MessageDetailsActivity.start(activity, item)
        }
        recycler.adapter = adapter
    }

    override fun initData() {
        super.initData()
        getActiveList()
    }

    private fun refreshUnreadCount() {
        if (adapter != null && adapter!!.data.isNotEmpty() && UserMgr.isLogin()) {
            val data = adapter!!.data
            val size = data.size
            var unreadCount = 0
            for (i in 0 until size) {
                if (data.size > i) {
                    val shaky = data[i]
                    if (shaky.is_read == 0) {
                        unreadCount += 1
                    }
                }
            }
            EventBus.getDefault().post(UnreadEvent(unreadCount))
        } else {
            EventBus.getDefault().post(UnreadEvent(0))
        }
    }

    override fun onResume() {
        super.onResume()
        getActiveList()
    }


    private fun getActiveList() {
        val params = hashMapOf<String, String>()
        params["uid"] = UserMgr.getUid()
        params["page"] = pageNum.toString()
        params["pageSize"] = Constant.PAGE_SIZE
        getApiService()
            .getActiveList(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<MutableList<Shaky>>() {
                override fun success(t: MutableList<Shaky>) {
                    if (pageNum == 1) {
                        adapter?.setNewInstance(t)
                    } else {
                        adapter?.addData(t)
                    }
                    refreshUnreadCount()
                    if (t.size >= Constant.PAGE_SIZE.toInt()) {
                        refresh_layout?.setEnableLoadMore(true)
                    } else {
                        refresh_layout?.setEnableLoadMore(false)
                    }
                    refresh_layout?.finishRefresh()
                    refresh_layout?.finishLoadMore()
                    empty_view?.visibility = View.GONE
                }

                override fun error(msg: String?, code: Int) {
                    if (empty_view?.visibility == View.VISIBLE) {
                        empty_view?.setLoadFail()
                    }
                    refresh_layout?.setEnableLoadMore(false)
                    refresh_layout?.finishRefresh(false)
                    refresh_layout?.finishLoadMore(false)
                    if (pageNum > 1) {
                        pageNum--
                    }
                }
            })
    }


}