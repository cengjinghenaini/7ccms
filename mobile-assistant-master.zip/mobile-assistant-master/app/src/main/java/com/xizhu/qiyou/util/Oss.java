package com.xizhu.qiyou.util;

import android.content.Context;

import com.alibaba.sdk.android.oss.ClientException;
import com.alibaba.sdk.android.oss.OSS;
import com.alibaba.sdk.android.oss.OSSClient;
import com.alibaba.sdk.android.oss.ServiceException;
import com.alibaba.sdk.android.oss.callback.OSSCompletedCallback;
import com.alibaba.sdk.android.oss.callback.OSSProgressCallback;
import com.alibaba.sdk.android.oss.common.auth.OSSFederationCredentialProvider;
import com.alibaba.sdk.android.oss.common.auth.OSSFederationToken;
import com.alibaba.sdk.android.oss.model.GetObjectRequest;
import com.alibaba.sdk.android.oss.model.GetObjectResult;
import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.alibaba.sdk.android.oss.model.PutObjectResult;
import com.google.gson.Gson;
import com.xizhu.qiyou.config.OSSConfig;
import com.xizhu.qiyou.entity.OssToken;
import com.xizhu.qiyou.inter.OssGetProgress;
import com.xizhu.qiyou.inter.OssGetResult;
import com.xizhu.qiyou.inter.OssPutProgress;
import com.xizhu.qiyou.inter.OssPutResult;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Oss {
    private static Oss INSTANCE;
    private OSS oss;

    public static Oss getInstance() {
        return INSTANCE;
    }

    public static void init(Context context) {
        INSTANCE = new Oss(context);
    }

    private Oss(Context context) {
        initClient(context);
    }

    private void initClient(Context context) {
        OSSFederationCredentialProvider ossFederationCredentialProvider = new OSSFederationCredentialProvider() {
            @Override
            public OSSFederationToken getFederationToken() throws ClientException {
                OkHttpClient client = new OkHttpClient.Builder()
                        .build();
                Request request = new Request.Builder()
                        .get()
                        .url(OSSConfig.STS_SERVER_URL)
                        .build();
                Call call = client.newCall(request);
                try {
                    Response response = call.execute();
                    String body = response.body().string();
                    LogUtil.e( "getFederationToken: " + body);
                    OssToken ossToken = new Gson().fromJson(body, OssToken.class);
                    return new OSSFederationToken(ossToken.getAccessKeyId(),
                            ossToken.getAccessKeySecret(),
                            ossToken.getSecurityToken(),
                            ossToken.getExpiration());

                } catch (IOException e) {
                    LogUtil.e("getFederationToken: ");
                    e.printStackTrace();
                    return null;
                }
            }
        };

        oss = new OSSClient(context.getApplicationContext(), OSSConfig.OSS_ENDPOINT, ossFederationCredentialProvider);
    }


    public String presignPublicObjectURL(String objectKey) {
        return oss.presignPublicObjectURL(OSSConfig.BUCKET_NAME, objectKey);
    }

    public void putObj(String objKey, String filePath, OssPutProgress ossPutProgress, OssPutResult ossPutResult) {
        // 构造上传请求。
        PutObjectRequest put = new PutObjectRequest(OSSConfig.BUCKET_NAME, objKey, filePath);
        // 异步上传时可以设置进度回调。
        put.setProgressCallback(new OSSProgressCallback<PutObjectRequest>() {
            @Override
            public void onProgress(PutObjectRequest request, long currentSize, long totalSize) {
                if (ossPutProgress != null) {
                    ossPutProgress.onProgress(request, currentSize, totalSize);
                }
            }
        });
        oss.asyncPutObject(put, new OSSCompletedCallback<PutObjectRequest, PutObjectResult>() {
            @Override
            public void onSuccess(PutObjectRequest request, PutObjectResult result) {
                if (ossPutResult != null) {
                    ossPutResult.onSuccess(request, result);
                }
            }

            @Override
            public void onFailure(PutObjectRequest request, ClientException clientExcepion, ServiceException serviceException) {
                // 请求异常。
                if (clientExcepion != null) {
                    // 本地异常，如网络异常等。
                    LogUtil.e(serviceException.getHostId());
                    LogUtil.e(clientExcepion.getMessage());
                    clientExcepion.printStackTrace();
                }
                if (serviceException != null) {
                    // 服务异常。
                    LogUtil.e( serviceException.getErrorCode());
                    LogUtil.e(serviceException.getRequestId());
                    LogUtil.e(serviceException.getHostId());
                    LogUtil.e(serviceException.getRawMessage());
                }
            }
        });
    }

    public void getObj(String objKey, OssGetProgress getProgress, OssGetResult getResult) {
        GetObjectRequest get = new GetObjectRequest(OSSConfig.BUCKET_NAME, objKey);
        get.setProgressListener(new OSSProgressCallback<GetObjectRequest>() {
            @Override
            public void onProgress(GetObjectRequest request, long currentSize, long totalSize) {
                if (getProgress != null) {
                    getProgress.onProgress(request, currentSize, totalSize);
                }
            }
        });

        oss.asyncGetObject(get, new OSSCompletedCallback<GetObjectRequest, GetObjectResult>() {
            @Override
            public void onSuccess(GetObjectRequest request, GetObjectResult result) {
                if (getResult != null) {
                    getResult.onSuccess(request, result);

                }
            }

            @Override
            public void onFailure(GetObjectRequest request, ClientException clientException, ServiceException serviceException) {
                // 请求异常
                if (clientException != null) {
                    // 本地异常如网络异常等
                    clientException.printStackTrace();
                }
                if (serviceException != null) {
                    // 服务异常
                    LogUtil.e( serviceException.getErrorCode());
                    LogUtil.e(serviceException.getRequestId());
                    LogUtil.e( serviceException.getHostId());
                    LogUtil.e( serviceException.getRawMessage());
                }
            }
        });
    }

}
