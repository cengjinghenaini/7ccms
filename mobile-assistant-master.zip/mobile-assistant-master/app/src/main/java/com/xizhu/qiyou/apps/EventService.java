package com.xizhu.qiyou.apps;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.xizhu.qiyou.entity.AppInfo;
import com.xizhu.qiyou.room.entity.AppEntity;
import com.xizhu.qiyou.util.PhoneUtil;

import java.util.ArrayList;
import java.util.List;


/**
 * @ClassName EventService
 * @Description 监听app安装、卸载和app新打开的时候，纠正db中相关数据的状态
 * @Author guchu
 * @Date 2021/3/7 13:47
 * @Version 1.0
 */
public class EventService extends Service {
    public static final String TAG = EventService.class.getSimpleName();
    private AppListener mAppListener;
    private static AppRepository mAppRepository;

    @Override
    public void onCreate() {
        super.onCreate();
        mAppRepository = new AppRepository(getApplication());
        mAppListener = new AppListener(this);
        mAppListener.begin(new IAppListener());
        correctInit();
        Log.d(TAG, "onCreate");
    }

    //startService 反复调用
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (null != mAppListener) {
            mAppListener.unregisterListener();
        }
        super.onDestroy();
    }

    static class IAppListener implements AppListener.AppStateListener {

        @Override
        public void onAppInstall(String packageName) {
            mAppRepository.finishInstall(packageName);
        }

        @Override
        public void onAppUninstall(String packageName) {
            mAppRepository.deleteByPackage(packageName);
        }
    }

    //
    // 更新用户已经安装的app.
    private void correctInit() {
        //删除用户已经卸载的app，
        List<AppInfo> installedApps = PhoneUtil.getUserApps(getApplicationContext());
        List<String> installedPackages = new ArrayList<>();
        for (AppInfo appInfo : installedApps) {
            installedPackages.add(appInfo.getPackageName());
        }
        List<AppEntity> dbInstalledApps = mAppRepository.getAppsFinished();
        for (AppEntity appEntity : dbInstalledApps) {
            int appIndex = installedPackages.indexOf(appEntity.getRealPackage());
            if (appIndex < 0) {
                mAppRepository.deleteByPackage(appEntity.getRealPackage());
            }
        }
        //更新用户已经安装的app(这里面要进行版本检查，版本不同，也不进行更新).
        List<AppEntity> db4InstallApp = mAppRepository.getApps4Install();
        for (AppEntity appEntity : db4InstallApp) {
            int appIndex = installedPackages.indexOf(appEntity.getRealPackage());
            if (appIndex >= 0) {
                String dbVersionName = appEntity.getRealVersion();
                String installedVersionName = installedPackages.get(appIndex);
                if (dbVersionName.equals(installedVersionName)) {
                    mAppRepository.finishInstall(appEntity.getRealPackage());
                }
            }
        }
    }
}
