package com.xizhu.qiyou.base;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.xizhu.qiyou.R;
import com.xizhu.qiyou.util.PhoneUtil;
import com.xizhu.qiyou.util.StatusX;
import com.xizhu.qiyou.widget.LoadingDialog;

import org.greenrobot.eventbus.EventBus;
import org.jetbrains.annotations.NotNull;

import java.util.List;

import butterknife.ButterKnife;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

public abstract class BaseCompatActivity extends AppCompatActivity {
    public String TAG = this.getClass().getSimpleName();
    public FragmentManager fragmentManager;
    protected String[] titles;
    private Activity activity;
    protected LoadingDialog loadingDialog;
    private CompositeDisposable mCompositeDisposable;

    public Context getActivity() {
        return activity;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(TAG, "onCreate: " + getTaskId());

        saved(savedInstanceState);
        setContentView(getRes());


        if (isSetUltimateBar()) {
            setStatusBar();
        }


        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        activity = this;
        if (isBindButterKnife()) {
            ButterKnife.bind(this);
        }
        loadingDialog = new LoadingDialog(this, R.style.DialogRing);
        loadingDialog.setTitle(setLoadingString());
//        loadingDialog.setCancelable(false);

        fragmentManager = getSupportFragmentManager();
        if (isRegisterEventBus()) {
            EventBus.getDefault().register(this);
        }

        // 如果页面有标题栏的返回键
        View back = findViewById(R.id.back);
        if (back != null) {
            back.setOnClickListener(v -> finish());
        }


        // 如果页面有tab +viewpager，初始化
        titles = hasTitles();

        isPORTRAIT();

        initView();
        initData();
        initEvent();
    }


    protected String setLoadingString() {
        return "正在加载中...";
    }

    protected void saved(Bundle savedInstanceState) {
    }


    // 是否使用UltimateBar
    protected boolean isSetUltimateBar() {
        return true;
    }

    //设置沉浸式状态栏
    private void setStatusBar() {
        if (!PhoneUtil.getSpMode(this)) {
            StatusX.initStatusBar(this, isLight(), !fitWindow(), getResources().getColor(getStatusColorRes()));
        } else {
            StatusX.initStatusBar(this, !isLight(), !fitWindow(), getResources().getColor(getStatusColorRes()));
        }
    }

    //是否阻止入侵
    protected boolean fitWindow() {
        return true;
    }

    //状态栏是否高亮
    protected boolean isLight() {
        return true;
    }

    //返回状态栏颜色，可复写, 默认返回白色
    protected int getStatusColorRes() {
        return R.color.windowBackground;
    }


    protected void showProgress() {
        if (!isDestroyed() && !loadingDialog.isShowing()) {
            loadingDialog.show();
        }
    }

    protected void dismissProgress() {
        if (!isDestroyed() && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }
    }


    protected boolean isRegisterEventBus() {
        return false;
    }

    protected boolean isBindButterKnife() {
        return true;
    }


    // 返回
    protected List<Fragment> hasFragments() {
        return null;
    }

    // 返回tabItem资源
    protected Integer hasTabAndPager() {
        return null;
    }

    // 返回标题集
    protected String[] hasTitles() {
        return null;
    }


    protected abstract int getRes();

    protected abstract void initView();

    protected void initData() {
    }

    protected void initEvent() {
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isRegisterEventBus()) {
            dismissProgress();
            EventBus.getDefault().unregister(this);
        }
        unDisposable();
    }

    // 键盘遮挡问题
    protected void addLayoutListener(final View main, final View scroll) {
        main.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Rect rect = new Rect();
                main.getWindowVisibleDisplayFrame(rect);
                int mainInvisibleHeight = main.getRootView().getHeight() - rect.bottom;
                if (mainInvisibleHeight > 150) {
                    int[] location = new int[2];
                    scroll.getLocationInWindow(location);
                    int srollHeight = (location[1] + scroll.getHeight()) - rect.bottom;
                    main.scrollTo(0, srollHeight + 15);
                } else {
                    main.scrollTo(0, 0);
                }
            }
        });
    }


    @Override
    public void setRequestedOrientation(int requestedOrientation) {
        if (isPORTRAIT()) {
            super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else {
            super.setRequestedOrientation(requestedOrientation);
        }
    }

    protected boolean isPORTRAIT() {
        return true;
    }

    public boolean addObserver(@NotNull Disposable disposable) {
        if (mCompositeDisposable == null) {
            mCompositeDisposable = new CompositeDisposable();
        }
        return mCompositeDisposable.add(disposable);
    }


    public void unDisposable() {
        if (mCompositeDisposable != null) {
            mCompositeDisposable.clear();
        }
    }
}
