package com.xizhu.qiyou.http.request;

import com.xizhu.qiyou.http.HttpClient;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Callback;
import okhttp3.Request;
import okhttp3.Response;

public abstract class ReqHelper {
    private String url;
    private final Map<String, String> params = new HashMap<>();
    private final List<File> files = new ArrayList<>();

    public ReqHelper url(String url) {
        this.url = url;
        return this;
    }

    public ReqHelper addParams(String key, String value) {
        params.put(key, value);
        return this;
    }

    public ReqHelper addParams(Map<String, String> map) {
        for (String key : map.keySet()) {
            params.put(key, map.get(key));
        }
        return this;
    }

    public ReqHelper addFile(File file) {
        files.add(file);
        return this;
    }

    public abstract Request createReq();


    public void enqueue(Callback callback) {
        Request request = createReq();
        HttpClient.getInstance().enqueue(request, callback);
    }

    public Response execute() throws IOException {
        Request request = createReq();
        return HttpClient.getInstance().execute(request);
    }

    public String getUrl() {
        return url;
    }

    public Map<String, String> getParams() {
        return params;
    }

    public List<File> getFiles() {
        return files;
    }
}
