package com.xizhu.qiyou.ui.main

import android.content.Intent
import android.view.View
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.pass.util.DisplayUtil
import com.qmuiteam.qmui.widget.textview.QMUISpanTouchFixTextView
import com.scwang.smart.refresh.layout.api.RefreshLayout
import com.scwang.smart.refresh.layout.listener.OnRefreshLoadMoreListener
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.BaseApp
import com.xizhu.qiyou.entity.Label
import com.xizhu.qiyou.entity.Special
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.ui.details.TopicDetailsActivity
import io.reactivex.Observable
import kotlinx.android.synthetic.main.fragment_last.*
import kotlinx.android.synthetic.main.header_fragment_last.view.*
import java.util.*

class LastFragment : BaseFragment() {
    private var adapter: LastAdapter? = null
    private var lastAdapter: HomeLikeAdapter? = null
    private var headerView: View? = null
    private var textColor: Int = 0
    private var tagBgColor: Int = 0
    private var dp4: Int = 0
    private var dp12: Int = 0
    private var dp20: Int = 0
    private var pageNum = 1

    override fun getRes(): Int {
        return R.layout.fragment_last
    }

    override fun initView() {
        super.initView()
        refresh_layout?.setOnRefreshLoadMoreListener(object : OnRefreshLoadMoreListener {
            override fun onRefresh(refreshLayout: RefreshLayout) {
                pageNum = 1
                refresh()
            }

            override fun onLoadMore(refreshLayout: RefreshLayout) {
                pageNum++
                getTopicList()
            }
        })
        empty_view?.setLoadListener {
            refresh()
        }
        refresh_layout.setEnableRefresh(true)
        refresh_layout.setEnableLoadMore(false)
        recycler.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        adapter = LastAdapter().apply {
            addChildClickViewIds(R.id.tv_more)
            setOnItemChildClickListener { _, view, position ->
                val item = getItem(position)
                TopicDetailsActivity.start(context, item)
            }
        }
        headerView = View.inflate(context, R.layout.header_fragment_last, null)
        headerView!!.recycler_last.layoutManager =
            GridLayoutManager(context, 4, GridLayoutManager.VERTICAL, false)
        lastAdapter = HomeLikeAdapter().apply {
            setOnItemClickListener { _, _, position ->
                val childItem = getItem(position)
                JumpUtils.jumpToGameDetailsPage(context, childItem?.id)
            }
        }
        headerView!!.recycler_last.adapter = lastAdapter
        headerView!!.tv_more.setOnClickListener {
            startActivity(Intent(context, LabelListActivity::class.java))
        }
        headerView!!.tv_more1.setOnClickListener {
            LastGameActivity.start(context)
        }
        adapter?.addHeaderView(headerView!!)
        recycler.adapter = adapter

        textColor = ContextCompat.getColor(mContext, R.color.color_66)
        tagBgColor = ContextCompat.getColor(mContext, R.color.color_ee)
        dp4 = DisplayUtil.dip2px(mContext, 4f)
        dp12 = DisplayUtil.dip2px(mContext, 12f)
        dp20 = DisplayUtil.dip2px(mContext, 20f)
    }


    private fun updateTagView(cateList: List<Label>?) {
        headerView?.fl_tag?.removeAllViews()
        cateList?.forEach {
            val textView = QMUISpanTouchFixTextView(context)
            textView.textSize = 15f
            textView.setTextColor(textColor)
            textView.setBackgroundColor(tagBgColor)
            textView.radius = dp20
            textView.setPadding(dp12, dp4, dp12, dp4)
            textView.text = it.name
            textView.setOnClickListener { _ ->
                GameListActivity.start(context, "", it.id, it.name)
            }
            headerView?.fl_tag?.addView(textView)
        }
    }

    override fun initData() {
        super.initData()
        refresh()
    }

    private fun showTopicList(topicList: MutableList<Special>?) {
        topicList?.let {
            if (pageNum == 1) {
                adapter?.setNewInstance(it)
            } else {
                adapter?.addData(it)
            }
            if (it.size >= Constant.PAGE_SIZE.toInt()) {
                refresh_layout?.setEnableLoadMore(true)
            } else {
                refresh_layout?.setEnableLoadMore(false)
            }
            refresh_layout?.finishRefresh()
            refresh_layout?.finishLoadMore()
            empty_view?.visibility = View.GONE
        } ?: run {
            if (empty_view?.visibility == View.VISIBLE) {
                empty_view?.setLoadFail()
            }
            refresh_layout?.setEnableLoadMore(false)
            refresh_layout?.finishRefresh(false)
            refresh_layout?.finishLoadMore(false)
            if (pageNum > 1) {
                pageNum--
            }
        }
    }


    private fun refresh() {
        val map = HashMap<String, String>()
        map["type"] = "0"
        map["page"] = "1"
        val observable1 = getApiService().getAppLabel(map)
        val observable2 = getApiService().getNewApp(map)
        val observable3 = getApiService().getTopic(
            hashMapOf(
                Pair("page", "1"),
                Pair("pageSize", Constant.PAGE_SIZE)
            )
        )
        val disposable = Observable.zip(observable1, observable2, observable3, { t1, t2, t3 ->
            val array = arrayOfNulls<Any>(3)
            array[0] = t1.data
            array[1] = t2.data
            array[2] = t3.data
            return@zip array
        }).compose(IoMainScheduler())
            .subscribe({ resultList: Array<Any?> ->
                val labelList = resultList[0] as? MutableList<Label>
                val lastAppList = resultList[1] as? MutableList<BaseApp?>
                val topicList = resultList[2] as? MutableList<Special>
                updateTagView(labelList)
                lastAppList?.let {
                    val newList = if (it.size > 8) it.subList(0, 8) else it
                    lastAdapter?.setNewInstance(newList)
                }
                showTopicList(topicList)
            })
            {
                showTopicList(null)
            }
        addObserver(disposable)
    }


    private fun getTopicList() {
        val ids = StringBuffer()
        if (adapter?.data?.isNotEmpty() == true) {
            adapter?.data?.forEachIndexed { index, topicInfo ->
                if (index != 0) {
                    ids.append(",")
                }
                ids.append(topicInfo.id)
            }
        }
        val params = hashMapOf(
            Pair("ids", ids.toString()),
            Pair("pageSize", Constant.PAGE_SIZE)
        )
        getApiService()
            .getTopic(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<MutableList<Special>>() {
                override fun success(t: MutableList<Special>) {
                    showTopicList(t)
                }

                override fun error(msg: String?, code: Int) {
                    showTopicList(null)
                }
            })
    }
}