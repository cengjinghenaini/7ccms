package com.xizhu.qiyou.entity;

import java.io.Serializable;
import java.util.List;

public class BaseComment implements Serializable {


    /**
     * id : value
     * sheet_id : value
     * uid : value
     * zan_count : value
     * reply_count : value
     * phone_type : value
     * content : value
     * reply_id : value
     * createtime : value
     * reply_uid : value
     * score : value
     * user : {"uid":"value","phone":"value","email":"value","name":"value","wx_name":"value","qq":"value","head":"value","touxian_id":"value","touxian":"value","sex":"value","is_member":"value","age":"value","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":""}
     */
    protected String is_zan;
    protected String id;
    protected String sheet_id;
    protected String uid;
    protected String zan_count;
    protected String reply_count;
    protected String phone_type;
    protected String content;
    protected String reply_id;
    protected String createtime;
    protected String reply_uid;
    protected double score;
    protected User user;
    protected String createtime_f;
    protected String app_id;
    protected String is_me;
    protected String posts_id;
    protected String topic_id;
    protected String rec_id;
    protected String tail_id;
    protected Tail tail;
    protected List<String> pics;


    public List<String> getPics() {
        return pics;
    }

    private String atuids;

    public String getAtuids() {
        return atuids;
    }

    public void setAtuids(String atuids) {
        this.atuids = atuids;
    }

    public void setPics(List<String> pics) {
        this.pics = pics;
    }
    public Tail getTail() {
        return tail;
    }
    public void setTail(Tail tail) {
        this.tail = tail;
    }
    public String getTail_id() {
        return tail_id;
    }

    public void setTail_id(String tail_id) {
        this.tail_id = tail_id;
    }
    public String getRec_id() {
        return rec_id;
    }

    public void setRec_id(String rec_id) {
        this.rec_id = rec_id;
    }
    public String getPosts_id() {
        return posts_id;
    }

    public void setPosts_id(String posts_id) {
        this.posts_id = posts_id;
    }

    public String getTopic_id() {
        return topic_id;
    }

    public void setTopic_id(String topic_id) {
        this.topic_id = topic_id;
    }


    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public void setIs_zan(String is_zan) {
        this.is_zan = is_zan;
    }

    public String getIs_zan() {
        return is_zan;
    }

    public void setCreatetime_f(String createtime_f) {
        this.createtime_f = createtime_f;
    }

    public String getCreatetime_f() {
        return createtime_f;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSheet_id() {
        return sheet_id;
    }

    public void setSheet_id(String sheet_id) {
        this.sheet_id = sheet_id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getZan_count() {
        return zan_count;
    }

    public void setZan_count(String zan_count) {
        this.zan_count = zan_count;
    }

    public String getReply_count() {
        return reply_count;
    }

    public void setReply_count(String reply_count) {
        this.reply_count = reply_count;
    }

    public String getPhone_type() {
        return phone_type;
    }

    public void setPhone_type(String phone_type) {
        this.phone_type = phone_type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getReply_id() {
        return reply_id;
    }

    public void setReply_id(String reply_id) {
        this.reply_id = reply_id;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getReply_uid() {
        return reply_uid;
    }

    public void setReply_uid(String reply_uid) {
        this.reply_uid = reply_uid;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getIs_me() {
        return is_me;
    }

    public void setIs_me(String is_me) {
        this.is_me = is_me;
    }
}
