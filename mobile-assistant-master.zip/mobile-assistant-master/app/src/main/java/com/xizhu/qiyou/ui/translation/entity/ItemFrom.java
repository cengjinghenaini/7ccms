package com.xizhu.qiyou.ui.translation.entity;

public class ItemFrom {
    private String name;
    private String en;
    private boolean isFrom;

    public String getEn() {
        return en;
    }

    public void setEn(String en) {
        this.en = en;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isFrom() {
        return isFrom;
    }

    public void setFrom(boolean from) {
        isFrom = from;
    }
}
