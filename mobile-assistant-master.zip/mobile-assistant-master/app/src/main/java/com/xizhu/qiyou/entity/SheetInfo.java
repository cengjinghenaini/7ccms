package com.xizhu.qiyou.entity;

import java.io.Serializable;
import java.util.List;

public class SheetInfo extends BaseSheet  implements Serializable {

    /**
     * id : value
     * pic : value
     * uid : value
     * title : value
     * zan_count : value
     * collect_count : value
     * comment_count : value
     * name : value
     * head : value
     * is_attention : value
     * user : {"head":"value","name":"value"}
     * is_collect : value
     * is_zan : value
     * apps : [{"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value","is_reserve":"value","yiyuyue":"value"}]
     */


    private int is_attention;
    private User user;
    private int is_collect;
    private int is_zan;
    private List<BaseApp> apps;


    public int getIs_attention() {
        return is_attention;
    }

    public void setIs_attention(int is_attention) {
        this.is_attention = is_attention;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getIs_collect() {
        return is_collect;
    }

    public void setIs_collect(int is_collect) {
        this.is_collect = is_collect;
    }

    public int getIs_zan() {
        return is_zan;
    }

    public void setIs_zan(int is_zan) {
        this.is_zan = is_zan;
    }

    public List<BaseApp> getApps() {
        return apps;
    }

    public void setApps(List<BaseApp> apps) {
        this.apps = apps;
    }

    @Override
    public String toString() {
        return "SheetInfo{" +
                "is_attention='" + is_attention + '\'' +
                ", user=" + user +
                ", is_collect='" + is_collect + '\'' +
                ", is_zan='" + is_zan + '\'' +
                ", apps=" + apps +
                '}';
    }

}
