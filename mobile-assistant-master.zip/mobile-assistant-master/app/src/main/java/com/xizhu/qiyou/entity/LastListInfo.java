package com.xizhu.qiyou.entity;

import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.util.List;

public class LastListInfo implements MultiItemEntity {
    public static final int TYPE_TAG = 1;
    public static final int TYPE_TOPIC = 2;
    private int type;
    public String title = "";
    public String moreText = "";
    public List<Cate> cateList = null;
    public List<BaseGame> gameList = null;

    public LastListInfo(int type) {
        this.type = type;
    }

    @Override
    public int getItemType() {
        return type;
    }
}
