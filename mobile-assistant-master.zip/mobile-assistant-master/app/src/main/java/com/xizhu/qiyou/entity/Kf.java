package com.xizhu.qiyou.entity;

public class Kf {

    /**
     * kf_phone : 0329-1212121
     * kf_qq : 123456789
     */

    private String kf_phone;
    private String kf_qq;

    public String getKf_phone() {
        return kf_phone;
    }

    public void setKf_phone(String kf_phone) {
        this.kf_phone = kf_phone;
    }

    public String getKf_qq() {
        return kf_qq;
    }

    public void setKf_qq(String kf_qq) {
        this.kf_qq = kf_qq;
    }
}
