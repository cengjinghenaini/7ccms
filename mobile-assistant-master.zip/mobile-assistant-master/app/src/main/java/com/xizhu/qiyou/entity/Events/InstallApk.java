package com.xizhu.qiyou.entity.Events;

public class InstallApk {
    private final String apkPath;

    public InstallApk(String apkPath) {
        this.apkPath = apkPath;
    }


    public String getApkPath() {
        return apkPath;
    }
}
