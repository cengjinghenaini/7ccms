package com.xizhu.qiyou.entity;

import java.util.List;

public class GoodsDetail extends Goods{

    /**
     * id : 1
     * pic :
     * title :
     * integral :
     * desc :
     * gallery : ["","",""]
     * createtime :
     * user : {"contribution":"","integral":""}
     */

    private String desc;
    private String createtime;
    private User user;
    private List<String> gallery;

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<String> getGallery() {
        return gallery;
    }

    public void setGallery(List<String> gallery) {
        this.gallery = gallery;
    }

}
