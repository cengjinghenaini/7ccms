package com.xizhu.qiyou.entity.Events;

import java.io.File;

public class UpdateApp {

    private String size;
    private String name;
    private String id;
    private String head;
    private String uid;
    private String gameDesc;
    private File bitmap;

    public UpdateApp(String size, String name, String id, String head, String uid, String gameDesc, File bitmap) {
        this.size = size;
        this.name = name;
        this.id = id;
        this.head = head;
        this.uid =uid;
        this.gameDesc = gameDesc;
        this.bitmap = bitmap;
    }

    public File getBitmap() {
        return bitmap;
    }

    public void setBitmap(File bitmap) {
        this.bitmap = bitmap;
    }

    public String getGameDesc() {
        return gameDesc;
    }

    public void setGameDesc(String gameDesc) {
        this.gameDesc = gameDesc;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }
}
