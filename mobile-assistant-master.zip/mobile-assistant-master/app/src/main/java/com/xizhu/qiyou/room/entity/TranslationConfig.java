package com.xizhu.qiyou.room.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "translationConfig")
public class TranslationConfig {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;
    @ColumnInfo
    private String baidu_key;
    @ColumnInfo
    private String baidu_secretKey;
    @ColumnInfo
    private String baidu_image_key;
    @ColumnInfo
    private String baidu_image_secretKey;
    @ColumnInfo
    private String tencent_key;
    @ColumnInfo
    private String tencent_secretKey;
    @ColumnInfo
    private int font_size;
    @ColumnInfo
    private int font_color_translate;
    @ColumnInfo
    private int font_color_discern;
    @ColumnInfo
    private int font_color_bg;
    @ColumnInfo
    private float wind_aph;
    @ColumnInfo
    private float button_aph;
    @ColumnInfo
    private int wind_time;
    @ColumnInfo
    private int wind_width;
    @ColumnInfo
    private int wind_height;
    @ColumnInfo
    private int line_height;
    @ColumnInfo
    private int line_width;
    @ColumnInfo
    private boolean isTrim;
    @ColumnInfo
    private boolean scree_err;
    @ColumnInfo
    private boolean only_result;
    @ColumnInfo
    private boolean isReplace;
    @ColumnInfo
    private boolean isFilter;
    @ColumnInfo
    private boolean isSaveRecord;
    @ColumnInfo
    private int quickly_time;
    @ColumnInfo
    private int mode;
    @ColumnInfo
    private boolean isVertical;
    @ColumnInfo
    private boolean isTouchChoice;
    @ColumnInfo
    private boolean isQuicklyTrans;


    @ColumnInfo
    private int windowNum;
    @ColumnInfo
    private boolean isAssist;
    @ColumnInfo
    private boolean isWindowTrans;
    @ColumnInfo
    private boolean isTextTrans;

    @ColumnInfo
    private String from;
    @ColumnInfo
    private String to;

    @ColumnInfo
    private boolean isTencentSdk;

    public boolean isTencentSdk() {
        return isTencentSdk;
    }

    public void setTencentSdk(boolean tencentSdk) {
        isTencentSdk = tencentSdk;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public boolean isAssist() {
        return isAssist;
    }

    public void setAssist(boolean assist) {
        isAssist = assist;
    }

    public boolean isWindowTrans() {
        return isWindowTrans;
    }

    public void setWindowTrans(boolean windowTrans) {
        isWindowTrans = windowTrans;
    }

    public boolean isTextTrans() {
        return isTextTrans;
    }

    public void setTextTrans(boolean textTrans) {
        isTextTrans = textTrans;
    }

    public int getWindowNum() {
        return windowNum;
    }

    public void setWindowNum(int windowNum) {
        this.windowNum = windowNum;
    }


    public boolean isQuicklyTrans() {
        return isQuicklyTrans;
    }

    public void setQuicklyTrans(boolean quicklyTrans) {
        isQuicklyTrans = quicklyTrans;
    }

    public boolean isTouchChoice() {
        return isTouchChoice;
    }

    public void setTouchChoice(boolean touchChoice) {
        isTouchChoice = touchChoice;
    }

    public boolean isVertical() {
        return isVertical;
    }

    public void setVertical(boolean vertical) {
        isVertical = vertical;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBaidu_key() {
        return baidu_key;
    }

    public void setBaidu_key(String baidu_key) {
        this.baidu_key = baidu_key;
    }

    public String getBaidu_secretKey() {
        return baidu_secretKey;
    }

    public void setBaidu_secretKey(String baidu_secretKey) {
        this.baidu_secretKey = baidu_secretKey;
    }

    public String getBaidu_image_key() {
        return baidu_image_key;
    }

    public void setBaidu_image_key(String baidu_image_key) {
        this.baidu_image_key = baidu_image_key;
    }

    public String getBaidu_image_secretKey() {
        return baidu_image_secretKey;
    }

    public void setBaidu_image_secretKey(String baidu_image_secretKey) {
        this.baidu_image_secretKey = baidu_image_secretKey;
    }

    public String getTencent_key() {
        return tencent_key;
    }

    public void setTencent_key(String tencent_key) {
        this.tencent_key = tencent_key;
    }

    public String getTencent_secretKey() {
        return tencent_secretKey;
    }

    public void setTencent_secretKey(String tencent_secretKey) {
        this.tencent_secretKey = tencent_secretKey;
    }

    public int getFont_size() {
        return font_size;
    }

    public void setFont_size(int font_size) {
        this.font_size = font_size;
    }

    public int getFont_color_translate() {
        return font_color_translate;
    }

    public void setFont_color_translate(int font_color_translate) {
        this.font_color_translate = font_color_translate;
    }

    public int getFont_color_discern() {
        return font_color_discern;
    }

    public void setFont_color_discern(int font_color_discern) {
        this.font_color_discern = font_color_discern;
    }

    public int getFont_color_bg() {
        return font_color_bg;
    }

    public void setFont_color_bg(int font_color_bg) {
        this.font_color_bg = font_color_bg;
    }

    public float getWind_aph() {
        return wind_aph;
    }

    public void setWind_aph(float wind_aph) {
        this.wind_aph = wind_aph;
    }

    public float getButton_aph() {
        return button_aph;
    }

    public void setButton_aph(float button_aph) {
        this.button_aph = button_aph;
    }

    public int getWind_time() {
        return wind_time;
    }

    public void setWind_time(int wind_time) {
        this.wind_time = wind_time;
    }

    public int getWind_width() {
        return wind_width;
    }

    public void setWind_width(int wind_width) {
        this.wind_width = wind_width;
    }

    public int getWind_height() {
        return wind_height;
    }

    public void setWind_height(int wind_height) {
        this.wind_height = wind_height;
    }

    public int getLine_height() {
        return line_height;
    }

    public void setLine_height(int line_height) {
        this.line_height = line_height;
    }

    public int getLine_width() {
        return line_width;
    }

    public void setLine_width(int line_width) {
        this.line_width = line_width;
    }

    public boolean isTrim() {
        return isTrim;
    }

    public void setTrim(boolean trim) {
        isTrim = trim;
    }

    public boolean isScree_err() {
        return scree_err;
    }

    public void setScree_err(boolean scree_err) {
        this.scree_err = scree_err;
    }

    public boolean isOnly_result() {
        return only_result;
    }

    public void setOnly_result(boolean only_result) {
        this.only_result = only_result;
    }

    public boolean isReplace() {
        return isReplace;
    }

    public void setReplace(boolean replace) {
        isReplace = replace;
    }

    public boolean isFilter() {
        return isFilter;
    }

    public void setFilter(boolean filter) {
        isFilter = filter;
    }

    public boolean isSaveRecord() {
        return isSaveRecord;
    }

    public void setSaveRecord(boolean saveRecord) {
        isSaveRecord = saveRecord;
    }

    public int getQuickly_time() {
        return quickly_time;
    }

    public void setQuickly_time(int quickly_time) {
        this.quickly_time = quickly_time;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }
}
