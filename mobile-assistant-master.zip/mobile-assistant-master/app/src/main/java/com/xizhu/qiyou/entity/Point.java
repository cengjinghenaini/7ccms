package com.xizhu.qiyou.entity;

import java.io.Serializable;
import java.util.List;

public class Point implements Serializable {

    /**
     * id : 1
     * uid : 1
     * forum_id :
     * title :
     * content :
     * pics : ["",""]
     * video :
     * zan_count :
     * comment_count :
     * phone_type :
     * is_top :
     * is_gonggao :
     * is_reward :
     * reward_integral :
     * cate_id :
     * createtime :
     * createtime_f :
     * user : {"uid":"1","phone":"18254127300","email":"123@12.com","name":"","wx_name":"","qq":"","head":"","touxian_id":"","touxian":"","sex":"1","is_member":"","age":"","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":""}
     */

    private String id;
    private String uid;
    private String forum_id;
    private String title;
    private String content;
    private String video;
    private String zan_count;
    private String comment_count;
    private String phone_type;
    private String is_top;

    public String getHome_top() {
        return home_top;
    }

    public void setHome_top(String home_top) {
        this.home_top = home_top;
    }

    private String home_top;
    private String is_gonggao;
    private String is_reward;
    private String reward_integral;
    private String cate_id;
    private String createtime;
    private String createtime_f;
    private User user;
    private List<String> pics;
    private String is_zan;
    private int is_forum_host;
    private String show_type;
    private String look_id;

    public String getLook_id() {
        return look_id;
    }

    public void setLook_id(String look_id) {
        this.look_id = look_id;
    }


    public String getIs_zan() {
        return is_zan;
    }

    public void setIs_zan(String is_zan) {
        this.is_zan = is_zan;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getForum_id() {
        return forum_id;
    }

    public void setForum_id(String forum_id) {
        this.forum_id = forum_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public String getZan_count() {
        return zan_count;
    }

    public void setZan_count(String zan_count) {
        this.zan_count = zan_count;
    }

    public String getComment_count() {
        return comment_count;
    }

    public void setComment_count(String comment_count) {
        this.comment_count = comment_count;
    }

    public String getPhone_type() {
        return phone_type;
    }

    public void setPhone_type(String phone_type) {
        this.phone_type = phone_type;
    }

    public String getIs_top() {
        return is_top;
    }

    public void setIs_top(String is_top) {
        this.is_top = is_top;
    }

    public String getIs_gonggao() {
        return is_gonggao;
    }

    public void setIs_gonggao(String is_gonggao) {
        this.is_gonggao = is_gonggao;
    }

    public String getIs_reward() {
        return is_reward;
    }

    public void setIs_reward(String is_reward) {
        this.is_reward = is_reward;
    }

    public String getReward_integral() {
        return reward_integral;
    }

    public void setReward_integral(String reward_integral) {
        this.reward_integral = reward_integral;
    }

    public String getCate_id() {
        return cate_id;
    }

    public void setCate_id(String cate_id) {
        this.cate_id = cate_id;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getCreatetime_f() {
        return createtime_f;
    }

    public void setCreatetime_f(String createtime_f) {
        this.createtime_f = createtime_f;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<String> getPics() {
        return pics;
    }

    public void setPics(List<String> pics) {
        this.pics = pics;
    }

    public int getIs_forum_host() {
        return is_forum_host;
    }

    public void setIs_forum_host(int is_forum_host) {
        this.is_forum_host = is_forum_host;
    }

    public String getShow_type() {
        return show_type;
    }

    public void setShow_type(String show_type) {
        this.show_type = show_type;
    }
}
