package com.xizhu.qiyou.widget

import android.content.Context
import android.graphics.Color
import android.text.TextUtils
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import com.pass.util.DisplayUtil
import com.xizhu.qiyou.R
import kotlinx.android.synthetic.main.view_empty.view.*

class EmptyView : FrameLayout, View.OnClickListener {
    private var status = 0//0 无数据 1 加载中 2加载失败
    private var isDialogStyle = false
    private var loadLister: (() -> Unit)? = null

    constructor(context: Context) : this(context, null)

    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        initView(context)
    }

    private fun initView(context: Context) {
        LayoutInflater.from(context).inflate(R.layout.view_empty, this)
        setEnableDialogStyle(isDialogStyle)
        tvLoadingTips?.text = "正在加载"
        contentWrap?.visibility = View.VISIBLE
//        ivNoData?.visibility = View.GONE
        tvNoData?.visibility = View.GONE
        rootEmptyLayout?.setOnClickListener(this)
    }

    fun setLoading(): EmptyView {
        return setLoading("")
    }

    fun setEnableDialogStyle(dialogStyle: Boolean): EmptyView {
        isDialogStyle = dialogStyle
        if (isDialogStyle) {
            rootEmptyLayout?.setBackgroundColor(Color.TRANSPARENT)
            contentWrap?.setBackgroundResource(R.drawable.qmui_loading_dialog_bg)
            tvLoadingTips?.visibility = View.VISIBLE
            loadingView?.setSize(DisplayUtil.dip2px(context, 28f))
            loadingView?.setColor(ContextCompat.getColor(context, R.color.white))
            tvLoadingTips?.setTextColor(ContextCompat.getColor(context, R.color.white))
        } else {
            rootEmptyLayout?.setBackgroundResource(R.color.white)
            contentWrap?.setBackgroundColor(Color.TRANSPARENT)
            tvLoadingTips?.visibility = View.GONE
            contentWrap?.visibility = View.GONE
            loadingView?.setSize(DisplayUtil.dip2px(context, 28f))
            loadingView?.setColor(ContextCompat.getColor(context, R.color.text_color1))
            tvLoadingTips?.setTextColor(ContextCompat.getColor(context, R.color.text_color1))
        }
        return this
    }

    fun setTransparentBackground(): EmptyView {
        rootEmptyLayout?.setBackgroundColor(Color.TRANSPARENT)
        return this
    }

    fun setLoadListener(listener: () -> Unit) {
        this.loadLister = listener
    }

    fun setLoading(text: String): EmptyView {
        status = 1
        if (isDialogStyle) {
            if (!TextUtils.isEmpty(text)) {
                tvLoadingTips?.text = text
            } else {
                tvLoadingTips?.text = "正在加载"
            }
        }
        contentWrap?.visibility = View.VISIBLE
        loadingView?.visibility = View.VISIBLE
//        ivNoData?.visibility = View.GONE
        tvNoData?.visibility = View.GONE
        if (visibility != View.VISIBLE) {
            visibility = View.VISIBLE
        }
        return this
    }

    fun setLoadFail(): EmptyView {
        status = 2
        contentWrap?.visibility = View.GONE
//        ivNoData?.visibility = View.VISIBLE
//        ivNoData?.setImageResource(R.mipmap.icon_empty_load_fail)
        tvNoData?.visibility = View.VISIBLE
        tvNoData?.text = "加载失败，点击重试"
        if (visibility != View.VISIBLE) {
            visibility = View.VISIBLE
        }
        return this
    }

    fun setNoData(): EmptyView {
        return setNoData(0, "")
    }

    fun setNoData(resImageId: Int, text: String): EmptyView {
        status = 0
        contentWrap?.visibility = View.GONE
//        ivNoData?.visibility = View.VISIBLE
//        if (resImageId > 0) {
//            ivNoData?.setImageResource(resImageId)
//        }
        tvNoData?.visibility = View.VISIBLE
        if (!TextUtils.isEmpty(text)) {
            tvNoData?.text = text
        }
        if (visibility != View.VISIBLE) {
            visibility = View.VISIBLE
        }
        return this
    }


    fun setNoData(text: String): EmptyView {
        status = 0
        contentWrap?.visibility = View.GONE
//        ivNoData?.visibility = View.VISIBLE
        tvNoData?.visibility = View.VISIBLE
        if (!TextUtils.isEmpty(text)) {
            tvNoData?.text = text
        }
        if (visibility != View.VISIBLE) {
            visibility = View.VISIBLE
        }
        return this
    }

    override fun onClick(v: View?) {
        if (status == 2) {
            setLoading()
            loadLister?.invoke()
        }
    }

    fun getStatus(): Int {
        return status
    }

}