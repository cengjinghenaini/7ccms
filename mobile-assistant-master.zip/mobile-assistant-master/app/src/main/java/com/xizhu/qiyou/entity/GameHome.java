package com.xizhu.qiyou.entity;

public class GameHome extends BaseGame {

    /**
     * id : value
     * app_id : value
     * pic : value
     * sort : value
     * createtime : value
     * app : {"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value"}
     */

    private String id;
    private String pic;



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }



}
