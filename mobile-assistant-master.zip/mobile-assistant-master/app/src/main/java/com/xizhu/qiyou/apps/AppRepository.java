package com.xizhu.qiyou.apps;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.xizhu.qiyou.room.AppDataBase;
import com.xizhu.qiyou.room.dao.AppDao;
import com.xizhu.qiyou.room.entity.AppEntity;

import java.util.List;

/**
 * @ClassName AppRepository
 * @Description 数据库操作封装(查询操作可以在UI线程 ， 更新操作都在工作线程)
 * @Author guchu
 * @Date 2021/8/12 22:30
 * @Version 1.0
 */
public class AppRepository {
    private AppDao mAppDao;
    private LiveData<List<AppEntity>> mAllApps;

    public AppRepository(Application application) {
        mAppDao = AppDataBase.getInstance(application).getAppDao();
        mAllApps = mAppDao.getAllApps();
    }

    public void insert(AppEntity appEntity) {
        AppDataBase.databaseWriteExecutor.execute(() -> mAppDao.insert(appEntity));
    }

    public LiveData<List<AppEntity>> getAllApps() {
        return mAllApps;
    }

    public AppEntity getAppByDownloadUrl(String downloadUrl) {
        return mAppDao.getAppByDownloadUrl(downloadUrl);
    }


    public AppEntity getAppByWebPackage(String webPackage) {
        return mAppDao.getAppByWebPackage(webPackage);
    }
    public AppEntity getAppByRealPackage(String realPackage) {
        return mAppDao.getAppByRealPackage(realPackage);
    }

    public AppEntity getAppByDstPath(String unzipPath) {
        return mAppDao.getAppByDstPath(unzipPath);
    }

    public List<AppEntity> getAppsNoFinished() {
        return mAppDao.getAppsNoFinished();
    }

    public List<AppEntity> getApps4Install() {
        return mAppDao.getApps4Install();
    }


    public List<AppEntity> getAppsFinished() {
        return mAppDao.getAppsFinished();
    }

    public List<AppEntity> getDownloadingApps() {
        return mAppDao.getDownloadingApps();
    }

    public List<AppEntity> getInQueueDownloadApps() {
        return mAppDao.getInQueueDownloadApps();
    }

    public List<AppEntity> getUnzippingApps() {
        return mAppDao.getUnzippingApps();
    }

    public List<AppEntity> getInQueueUnzipApps() {
        return mAppDao.getInQueueUnzipApps();
    }

    public List<AppEntity> getPausedApps() {
        return mAppDao.getPausedApps();
    }

    public void update(AppEntity appEntity) {
        AppDataBase.databaseWriteExecutor.execute(() -> mAppDao.update(appEntity));
    }

    public void delete(AppEntity appEntity) {
        AppDataBase.databaseWriteExecutor.execute(() -> mAppDao.deleteApp(appEntity));
    }

    public void deleteByPackage(String packageStr) {
        AppEntity appEntity = mAppDao.getAppByRealPackage(packageStr);
        if (null != appEntity) {
            AppDataBase.databaseWriteExecutor.execute(() -> mAppDao.deleteApp(appEntity));
        }
    }

    public void finishInstall(String packageStr) {
        final AppEntity appEntity = mAppDao.getAppByRealPackage(packageStr);
        if (null != appEntity) {
            appEntity.setIsInstalled(AppEntity.TYPE_INSTALLED);
            AppDataBase.databaseWriteExecutor.execute(() -> mAppDao.update(appEntity));
        }
    }


}
