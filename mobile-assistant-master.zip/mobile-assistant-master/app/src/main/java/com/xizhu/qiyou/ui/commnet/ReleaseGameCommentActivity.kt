package com.xizhu.qiyou.ui.commnet

import android.app.Activity
import android.content.Intent
import android.text.TextUtils
import android.view.View
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.Comment
import com.xizhu.qiyou.entity.NULL
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.util.*
import com.xizhu.qiyou.util.dialog.ToastUtil
import kotlinx.android.synthetic.main.activity_release_game_comment.*
import kotlinx.android.synthetic.main.title_layout.*

class ReleaseGameCommentActivity : BaseCompatActivity() {
    private var appId: String? = null
    private var comment: Comment? = null

    companion object {
        fun start(
            context: Activity,
            appId: String?,
            comment: Comment? = null,
        ) {
            val intent = Intent(context, ReleaseGameCommentActivity::class.java)
            intent.putExtra("app_id", appId)
            intent.putExtra("comment", comment)
            context.startActivityForResult(intent, 6001)
        }
    }

    override fun getRes(): Int {
        return R.layout.activity_release_game_comment
    }

    override fun initView() {
        iv_back?.setOnClickListener {
            finish()
        }
        tv_page_title?.text = "发布评论"
        tv_right?.text = "发布"
        tv_right?.setOnClickListener {
            addComment()
        }
        iv_head.setOnClickListener {
            PopupUtils.showUserInfo(comment?.user, it)
        }
    }

    override fun initData() {
        super.initData()
        appId = intent.getStringExtra("app_id")
        comment = intent.getSerializableExtra("comment") as? Comment

        if (comment != null) {
            layout_comment?.visibility = View.VISIBLE
            tv_rating?.visibility = View.GONE
            rating_bar?.visibility = View.GONE

            ImgLoadUtil.loadHead(iv_head, comment?.user?.head)
            tv_name.text = comment?.user?.name
            tv_date.text = UnitUtil.time(comment?.createtime)
            tv_content.text = comment?.content
            val score = (comment?.score ?: 0).toFloat()
            rating_bar1.rating = score
        }
    }


    private fun addComment() {
        val content = et_content?.text.toString().trim()
        if (TextUtils.isEmpty(content)) {
            ToastUtil.show("还没输入内容呢")
            return
        }
        if (rating_bar.rating == 0f && comment == null) {
            ToastUtil.show("还没评分呢")
            return
        }
        val rating = rating_bar.rating.toInt()
        showProgress()
        val params = hashMapOf<String, Any?>()
        params["uid"] = UserMgr.getUid()
        params["app_id"] = appId
        if (comment != null) {
            params["reply_id"] = comment?.id
            params["reply_uid"] = comment?.user?.uid
            params["score"] = comment?.score
        } else {
            params["score"] = rating
        }
        params["phone_type"] = PhoneUtil.phone_type
        params["content"] = content

        getApiService()
            .commentApp(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<NULL>() {
                override fun success(t: NULL) {
                    ToastUtil.show("发布成功")
                    dismissProgress()
                    setResult(RESULT_OK)
                    finish()
                }

                override fun error(msg: String?, code: Int) {
                    super.error(msg, code)
                    dismissProgress()
                }
            })
    }

}