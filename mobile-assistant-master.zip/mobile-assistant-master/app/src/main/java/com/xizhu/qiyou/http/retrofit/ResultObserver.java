package com.xizhu.qiyou.http.retrofit;

import androidx.annotation.NonNull;

import com.xizhu.qiyou.http.result.ResultEntity;
import com.xizhu.qiyou.util.dialog.ToastUtil;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public abstract class ResultObserver<T> implements Observer<ResultEntity<T>> {
    @Override
    public void onSubscribe(@NonNull Disposable d) {

    }

    @Override
    public void onNext(@NonNull ResultEntity<T> resultEntity) {
        if (resultEntity.getCode() == 0 && resultEntity.getData() != null)
            success(resultEntity.getData());
        else error(resultEntity.getMsg(), resultEntity.getCode());
    }

    protected abstract void success(@NonNull T t);

    protected void error(String msg, int code) {
        ToastUtil.show(msg);
    }

    @Override
    public void onError(@NonNull Throwable e) {
        error(e.getMessage(), 1000);
    }

    @Override
    public void onComplete() {

    }
}
