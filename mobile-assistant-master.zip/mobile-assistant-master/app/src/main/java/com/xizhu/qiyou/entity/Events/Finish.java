package com.xizhu.qiyou.entity.Events;

public class Finish {

    private final Class<?> clazz;

    public Finish(Class<?> clazz){
        this.clazz = clazz;
    }

    public Class<?> getClazz() {
        return clazz;
    }
}
