package com.xizhu.qiyou.inter;

public interface CosPutProgress {
    void onProgress(long complete, long target);
}