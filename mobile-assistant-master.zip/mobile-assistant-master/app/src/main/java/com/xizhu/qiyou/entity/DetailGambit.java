package com.xizhu.qiyou.entity;

import java.util.List;

public class DetailGambit {


    /**
     * gambit : {"id":"2","pic":"","name":"应用123","posts_count":"0","look_count":"0","createtime":"1607433436"}
     * postslist : [{"id":"1","uid":"7","forum_id":"1","title":"帖子1","content":"<p>奥术大师大所多撒多<\/p><p>aww<\/p>","pics":["http://www.7you.cn/Uploads/Picture/20201204/0ae1d67d67b2d6f6.jpg","http://www.7you.cn/Uploads/Picture/20201204/0ae1d67d67b2d6f6.jpg"],"video":"","zan_count":"3","comment_count":"20","collect_count":"2","look_count":"5","phone_type":"","is_top":"0","is_gonggao":"0","is_reward":"0","reward_integral":"0","cate_id":"1","reply_time":"1607240340","createtime":"0","app_id":"0","tail_id":"0","is_active":"0","status":"1","check_reason":"l","user":{"uid":"7","phone":"12345678910","email":"","name":"123****8910","wx_name":"","qq":"","head":"http://7ceshi.oss-cn-chengdu.aliyuncs.com/1607511729951Image%20%285%29.jpg","touxian_id":"","touxian":"","sex":"1","is_member":"","age":20,"sign":"距办公家具估计会v干活","integral":"1423","exp":"","contribution":"","grade_id":"","grade_name":"","is_pwd":0,"is_bind_wx":0,"is_bind_qq":0},"is_zan":0,"createtime_f":"1970-01-01 08:00:00"}]
     */

    private Gambit gambit;
    private List<Point> postslist;

    public Gambit getGambit() {
        return gambit;
    }

    public void setGambit(Gambit gambit) {
        this.gambit = gambit;
    }

    public List<Point> getPostslist() {
        return postslist;
    }

    public void setPostslist(List<Point> postslist) {
        this.postslist = postslist;
    }


}
