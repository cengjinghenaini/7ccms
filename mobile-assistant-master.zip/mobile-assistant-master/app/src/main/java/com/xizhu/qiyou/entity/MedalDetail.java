package com.xizhu.qiyou.entity;

public class MedalDetail extends Medal{

    /**
     * id : 1
     * pic :
     * name :
     * is_convert :
     * contribution :
     * desc :
     * createtime :
     * user : {"integral":"1","contribution":""}
     * is_get :
     */

    private User user;
    private String is_get;


    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getIs_get() {
        return is_get;
    }

    public void setIs_get(String is_get) {
        this.is_get = is_get;
    }

}
