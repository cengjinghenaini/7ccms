package com.xizhu.qiyou.config;

public class WXQQConfig {
    public static final String GetToken = "https://api.weixin.qq.com/sns/oauth2/access_token";
    public static final String GetUserInfo = "https://api.weixin.qq.com/sns/userinfo";
    public static final String APP_ID = "wxc5c2487a83de57bb";
//    public static final String AppSecret = "812934fe46a675f1343c83a68776ea7b";
    public static final String AppSecret = "850f2205f4e33c6082dd15ba3f3b854c";
    public static final String QQ_APP_ID = "101914777";
}
