package com.xizhu.qiyou.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

public class ScrollViewPager extends ViewPager {
    private boolean scrollAble = true;

    public boolean isScrollAble() {
        return scrollAble;
    }

    public void setScrollable(boolean scrollAble) {
        this.scrollAble = scrollAble;
    }

    public ScrollViewPager(@NonNull Context context) {
        super(context);
    }

    public ScrollViewPager(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }


    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (scrollAble) {
            //允许滑动则应该调用父类的方法
            return super.onTouchEvent(ev);
        } else {
            //禁止滑动则不做任何操作，直接返回true即可
            return true;
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent arg0) {
        if (scrollAble)
            return super.onInterceptTouchEvent(arg0);
        else
            return false;
    }


}
