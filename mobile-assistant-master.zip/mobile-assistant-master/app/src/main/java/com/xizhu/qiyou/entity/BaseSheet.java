package com.xizhu.qiyou.entity;


import java.io.Serializable;
public class BaseSheet implements Serializable {
    /**
     * id : value
     * pic : value
     * uid : value
     * title : value
     * zan_count : value
     * collect_count : value
     * comment_count : value
     * name : value
     * head : value
     */

    protected String id;
    protected String pic;
    protected String uid;
    protected String title;
    protected String zan_count;
    protected String collect_count;
    protected String comment_count;
    protected String name;
    protected String head;
    protected String desc;
    protected String app_ids;
    protected String app_count;



    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setApp_ids(String app_ids) {
        this.app_ids = app_ids;
    }

    public void setApp_count(String app_count) {
        this.app_count = app_count;
    }

    public String getDesc() {
        return desc;
    }

    public String getApp_ids() {
        return app_ids;
    }

    public String getApp_count() {
        return app_count;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getZan_count() {
        return zan_count;
    }

    public void setZan_count(String zan_count) {
        this.zan_count = zan_count;
    }

    public String getCollect_count() {
        return collect_count;
    }

    public void setCollect_count(String collect_count) {
        this.collect_count = collect_count;
    }

    public String getComment_count() {
        return comment_count;
    }

    public void setComment_count(String comment_count) {
        this.comment_count = comment_count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    @Override
    public String toString() {
        return "BaseSheet{" +
                "id='" + id + '\'' +
                ", pic='" + pic + '\'' +
                ", uid='" + uid + '\'' +
                ", title='" + title + '\'' +
                ", zan_count='" + zan_count + '\'' +
                ", collect_count='" + collect_count + '\'' +
                ", comment_count='" + comment_count + '\'' +
                ", name='" + name + '\'' +
                ", head='" + head + '\'' +
                ", desc='" + desc + '\'' +
                ", app_ids='" + app_ids + '\'' +
                ", app_count='" + app_count + '\'' +
                '}';
    }


}