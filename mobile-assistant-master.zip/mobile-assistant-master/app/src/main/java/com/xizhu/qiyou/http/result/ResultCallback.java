package com.xizhu.qiyou.http.result;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.Gson;
import com.xizhu.qiyou.util.LogUtil;
import com.xizhu.qiyou.util.dialog.ToastUtil;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public abstract class ResultCallback<B> implements Callback {
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void onFailure(@NotNull Call call, @NotNull IOException e) {
        handler.post(() -> onFailure(e.getMessage(), -1024));
    }

    @Override
    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        int code = response.code();
        String body = response.body().string();
        if (code == 200) {
            ResultEntity<?> resultEntity = new Gson().fromJson(body, ResultEntity.class);

            if (resultEntity==null)return;

            if (resultEntity.getState() == null) {
                handler.post(() -> onRawResponse(body, code));
                return;
            }

            int resultCode = resultEntity.getCode();

            if (resultCode == 0) {
                ParameterizedType newType = createNewType(ResultEntity.class, getActualTypeArguments(this));
                handler.post(() -> onSuccess(new Gson().fromJson(body, newType)));
            } else {
                handler.post(() -> onFailure(resultEntity.getMsg(), resultCode));
            }

        } else {
            handler.post(() -> onFailure(body, code));
        }
    }

    private Type[] getActualTypeArguments(Object o){
        ParameterizedType genericSuperclass = (ParameterizedType) o.getClass().getGenericSuperclass();
        assert genericSuperclass != null;
        return genericSuperclass.getActualTypeArguments();
    }



    private ParameterizedType createNewType(Class<?> rawClazz, Type[] actualTypeArguments) {
        return new ParameterizedType() {
            @NonNull
            @Override
            public Type[] getActualTypeArguments() {
                return actualTypeArguments;
            }
            @NonNull
            @Override
            public Type getRawType() {
                return rawClazz;
            }

            @Nullable
            @Override
            public Type getOwnerType() {
                return null;
            }
        };
    }


    protected void onFailure(String err, int code) {
        LogUtil.e(err);
        if (err.length() > 50) {
            err = err.substring(0, 50);
        }
        ToastUtil.show(err);
    }

    //原始内容
    public void onRawResponse(String body, int code) {
    }

    protected abstract void onSuccess(ResultEntity<B> result);
}
