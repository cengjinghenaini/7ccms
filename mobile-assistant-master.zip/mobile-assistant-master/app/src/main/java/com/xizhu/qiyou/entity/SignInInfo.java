package com.xizhu.qiyou.entity;

public class SignInInfo {
    public String integral;
    public String exp;
}
