package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class Decorate implements Serializable {

    /**
     * id : 1
     * name :
     * pic :
     * integral :
     * cate_id :
     * type :
     * createtime :
     */

    private String id;
    private String name;
    private String pic;
    private String integral;
    private String cate_id;
    private String type;
    private String createtime;



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getCate_id() {
        return cate_id;
    }

    public void setCate_id(String cate_id) {
        this.cate_id = cate_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }
}
