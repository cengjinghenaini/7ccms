package com.xizhu.qiyou.entity.Events;

public class Reward {
    public Reward(int reward_count) {
        this.reward_count = reward_count;
    }

    public int getReward_count() {
        return reward_count;
    }

    int reward_count;
}
