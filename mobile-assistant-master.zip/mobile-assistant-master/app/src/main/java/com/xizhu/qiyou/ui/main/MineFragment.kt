package com.xizhu.qiyou.ui.main

import android.content.Intent
import android.text.TextUtils
import android.view.View
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.entity.Events.Exit
import com.xizhu.qiyou.entity.User
import com.xizhu.qiyou.entity.UserHome
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.ui.collect.CollectListActivity
import com.xizhu.qiyou.ui.account.LoginActivity
import com.xizhu.qiyou.ui.account.UserInfoActivity
import com.xizhu.qiyou.ui.history.BrowserHistoryActivity
import com.xizhu.qiyou.ui.integral.ClockInActivity
import com.xizhu.qiyou.ui.integral.IntegralListActivity
import com.xizhu.qiyou.util.*
import kotlinx.android.synthetic.main.fragment_mine.*
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class MineFragment : BaseFragment(), View.OnClickListener {

    override fun isRegister(): Boolean {
        return true
    }

    override fun getRes(): Int {
        return R.layout.fragment_mine
    }

    override fun initView() {
        super.initView()
        statusBar?.layoutParams?.height = UnitUtil.getStatusBarHeight(activity)
        iv_head?.setOnClickListener(this)
        tv_name?.setOnClickListener(this)
        tv_integral_value?.setOnClickListener(this)
        layout_integral_num?.setOnClickListener(this)
        tv_clock_in?.setOnClickListener(this)
        layout_history?.setOnClickListener(this)
        tv_download?.setOnClickListener(this)
        tv_integral?.setOnClickListener(this)
        tv_collect?.setOnClickListener(this)
        iv_setting?.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.iv_head, R.id.tv_name, R.id.iv_setting -> {
                if (toLogin()) {
                    return
                }
                startActivity(Intent(context, UserInfoActivity::class.java))
            }
            R.id.tv_integral_value, R.id.tv_integral, R.id.layout_integral_num -> {
                if (toLogin()) {
                    return
                }
                startActivity(Intent(context, IntegralListActivity::class.java))
            }
            R.id.tv_clock_in -> {
                if (toLogin()) {
                    return
                }
                startActivity(Intent(context, ClockInActivity::class.java))
            }
            R.id.layout_history -> {
                if (toLogin()) {
                    return
                }
                startActivity(Intent(context, BrowserHistoryActivity::class.java))
            }
            R.id.tv_download -> {
                JumpUtils.jumpToDownloadManagerPage(context)
            }
            R.id.tv_collect -> {
                if (toLogin()) {
                    return
                }
                startActivity(Intent(context, CollectListActivity::class.java))
            }
            else -> {
            }
        }
    }

    private fun toLogin(): Boolean {
        if (!UserMgr.isLogin()) {
            startActivity(Intent(context, LoginActivity::class.java))
            return true
        }
        return false
    }

    override fun initData() {
        super.initData()
        updateLoginView()
        getUserHome()
    }

    override fun onResume() {
        super.onResume()
        getUserHome()
    }

    private fun getUserHome() {
        if (UserMgr.isLogin()) {
            val uid = UserMgr.getUid()
            HttpUtil.getInstance().getUserHome(uid, uid, object : ResultCallback<UserHome>() {
                override fun onSuccess(s: ResultEntity<UserHome>) {
                    val user = s.data.user
                    UserMgr.setUser(user)
                    updateLoginView()
                }
            })
        }
    }

    private fun updateLoginView() {
        if (!UserMgr.isLogin()) {
            iv_head?.setImageResource(R.mipmap.icon_mine_header)
            tv_name?.text = "未登录"
            tv_login_tips?.visibility = View.VISIBLE
            iv_level?.visibility = View.GONE
            tv_clock_in?.text = "去登录"
            layout_download_num?.visibility = View.GONE
            layout_integral_num?.visibility = View.GONE
            tv_history?.text = null
        } else {
            val user = UserMgr.getUser()
            ImgLoadUtil.loadHead(iv_head, user?.head)
            tv_name?.text = user?.name
            layout_download_num?.visibility = View.VISIBLE
            layout_integral_num?.visibility = View.VISIBLE
            tv_login_tips?.visibility = View.GONE
            iv_level?.visibility = View.VISIBLE
            val sumCount = user.day_appdown?.sum_count ?: 0
            val unUseCount = try {
                sumCount - (user.day_appdown?.usecount ?: "0").toInt()
            } catch (e: Exception) {
                0
            }
            val downloadNum = "${unUseCount}/${sumCount}"
            tv_download_num?.text = downloadNum
            when (if (TextUtils.isEmpty(user?.grade_id)) " 1" else user?.grade_id) {
                "1" -> {
                    iv_level.setImageResource(R.mipmap.icon_mine_level1)
                }
                "2" -> {
                    iv_level.setImageResource(R.mipmap.icon_mine_level2)
                }
                "3" -> {
                    iv_level.setImageResource(R.mipmap.icon_mine_level3)
                }
                "4" -> {
                    iv_level.setImageResource(R.mipmap.icon_mine_level4)
                }
                "5" -> {
                    iv_level.setImageResource(R.mipmap.icon_mine_level5)
                }
                "6" -> {
                    iv_level.setImageResource(R.mipmap.icon_mine_level6)
                }
                "7" -> {
                    iv_level.setImageResource(R.mipmap.icon_mine_level7)
                }
                "8" -> {
                    iv_level.setImageResource(R.mipmap.icon_mine_level8)
                }
                "9" -> {
                    iv_level.setImageResource(R.mipmap.icon_mine_level9)
                }
                else -> {
                    iv_level.setImageResource(R.mipmap.icon_mine_level10)
                }
            }
            tv_integral_value?.text =
                if (TextUtils.isEmpty(user?.integral)) "0" else user?.integral.toString()
            tv_clock_in?.text = if (user.is_sign == 1) "已打卡" else "打卡"
            tv_history?.text = null
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun loginSuccessful(user: User) {
        val activity = activity
        if (activity != null) {
            PhoneUtil.putSpUid(activity, user.uid)
        }
        LogUtil.e("LoginSuccessful: " + user.is_member)
        updateLoginView()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun exitLogin(exit: Exit?) {
        UserMgr.setUser(null)
        updateLoginView()
    }

}