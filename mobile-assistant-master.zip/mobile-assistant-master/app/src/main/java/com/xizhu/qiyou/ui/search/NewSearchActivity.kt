package com.xizhu.qiyou.ui.search

import android.text.TextUtils
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.pass.util.DisplayUtil
import com.qmuiteam.qmui.widget.QMUIFloatLayout
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.BaseApp
import com.xizhu.qiyou.entity.SearchKeyWord
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.room.AppDataBase
import com.xizhu.qiyou.room.entity.SearchRecord
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.util.SysUtil
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.util.dialog.ToastUtil
import com.xizhu.qiyou.widget.EmptyView
import kotlinx.android.synthetic.main.activity_new_search.*

class NewSearchActivity : BaseCompatActivity() {
    private var adapter: SearchAdapter? = null
    private var keyword: String? = null

    override fun getRes(): Int {
        return R.layout.activity_new_search
    }

    override fun initView() {
        recycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        adapter = SearchAdapter().apply {
            setEmptyView(EmptyView(this@NewSearchActivity).setNoData())
            setOnItemClickListener { _, _, position ->
                val item = getItem(position)
                JumpUtils.jumpToGameDetailsPage(this@NewSearchActivity,item.id)
            }
        }
        recycler.adapter = adapter
        et_search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                keyword = et_search.text.toString().trim()
                toSearch()
                return@setOnEditorActionListener true
            }
            return@setOnEditorActionListener false
        }
        iv_refresh.setOnClickListener {
            getSearchKeyword()
        }
        iv_delete.setOnClickListener {
            val recordDao = AppDataBase.getInstance(this).recordDao
            recordDao.deleteAll()
            fl_history.removeAllViews()
            layout_history_title.visibility = View.GONE
            fl_history.visibility = View.GONE
        }
        iv_refresh_search.setOnClickListener {
            if (empty_view.getStatus() != 1 || empty_view.visibility != View.VISIBLE) {
                empty_view.setLoading()
                toSearch()
            }
        }
        empty_view.setLoadListener {
            empty_view.setLoading()
            toSearch()
        }
        my_game.setOnClickListener {
            JumpUtils.jumpToDownloadManagerPage(this)
        }
    }

    override fun initData() {
        super.initData()
        getSearchKeyword()
        getHistory()
    }

    private fun getSearchKeyword() {
        HttpUtil.getInstance()
            .getSearchKeyword(object : ResultCallback<MutableList<SearchKeyWord>>() {
                override fun onSuccess(s: ResultEntity<MutableList<SearchKeyWord>>) {
                    val searchKeyWordList = s.data
                    updateKeyword(fl_hot, searchKeyWordList)
                }
            })
    }


    private fun getHistory() {
        val recordDao = AppDataBase.getInstance(this).recordDao
        val all = recordDao.loadAll()
        val searchKeyWords = mutableListOf<SearchKeyWord>()

        for (searchRecord in all) {
            val searchKeyWord = SearchKeyWord()
            searchKeyWord.id = searchRecord.id.toString()
            searchKeyWord.keyword = searchRecord.keyWord
            searchKeyWords.add(0, searchKeyWord)
        }
        if (searchKeyWords.size == 0) {
            layout_history_title.visibility = View.GONE
            fl_history.visibility = View.GONE
        } else {
            layout_history_title.visibility = View.VISIBLE
            fl_history.visibility = View.VISIBLE
        }
        updateKeyword(fl_history, searchKeyWords)
    }

    private fun updateKeyword(
        tagLayout: QMUIFloatLayout,
        searchKeyWords: MutableList<SearchKeyWord>
    ) {
        tagLayout.removeAllViews()
        val textColor = ContextCompat.getColor(this, R.color.color_66)
        val dp5 = DisplayUtil.dip2px(this, 5f)
        val dp12 = DisplayUtil.dip2px(this, 12f)
        searchKeyWords.forEach {
            val textView = TextView(this)
            textView.textSize = 15f
            textView.setTextColor(textColor)
            textView.setBackgroundResource(R.drawable.shape_round_bg_ee_radius_30)
            textView.includeFontPadding = false
            textView.setPadding(dp12, dp5, dp12, dp5)
            textView.text = it.keyword
            textView.setOnClickListener { _ ->
                keyword = it.keyword
                et_search.setText(keyword)
                toSearch()
            }
            tagLayout.addView(textView)
        }
    }


    private fun toSearch() {
        SysUtil.hide(activity, et_search)
        if (TextUtils.isEmpty(keyword)) {
            ToastUtil.show("没有输入任何内容")
            return
        }
        //入库
        val recordDao = AppDataBase.getInstance(this).recordDao
        val byKeyWord = recordDao.findByKeyWord(keyword)
        if (byKeyWord == null) {
            val searchRecord = SearchRecord()
            searchRecord.keyWord = keyword
            recordDao.insertUser(searchRecord)
            getHistory()
        }
        scroll_view_history.visibility = View.GONE
        empty_view.setLoading()

        val uid = UserMgr.getUid()
        HttpUtil.getInstance().getSearchResult(
            "0",
            uid,
            keyword,
            "1",
            "100",
            object : ResultCallback<MutableList<BaseApp>>() {
                override fun onSuccess(s: ResultEntity<MutableList<BaseApp>>) {
                    val apps = s.data
                    adapter?.setNewInstance(apps)
                    tv_search_result.text = "搜索到${apps.size}个结果"
                    empty_view.visibility = View.GONE
                }

                override fun onFailure(err: String?, code: Int) {
                    super.onFailure(err, code)
                    empty_view.setLoadFail()
                }
            })
    }

    override fun onBackPressed() {
        if (scroll_view_history.visibility != View.VISIBLE) {
            scroll_view_history.visibility = View.VISIBLE
        } else {
            super.onBackPressed()
        }
    }
}