package com.xizhu.qiyou.ui.integral

import android.content.Intent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.scwang.smart.refresh.layout.api.RefreshLayout
import com.scwang.smart.refresh.layout.listener.OnRefreshLoadMoreListener
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.GradeBean
import com.xizhu.qiyou.entity.UserIntegral
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.UserMgr
import kotlinx.android.synthetic.main.fragment_message.*
import kotlinx.android.synthetic.main.header_integral_list.view.*
import kotlinx.android.synthetic.main.title_layout.*

class IntegralListActivity : BaseCompatActivity() {
    private var headerView: View? = null
    private var adapter: IntegralListAdapter? = null
    private var pageNum = 1

    override fun getRes(): Int {
        return R.layout.activity_integral_list
    }

    override fun initView() {
        iv_back.setOnClickListener {
            finish()
        }
        tv_page_title.text = "积分"
        refresh_layout?.setOnRefreshLoadMoreListener(object : OnRefreshLoadMoreListener {
            override fun onRefresh(refreshLayout: RefreshLayout) {
                pageNum = 1
                getIntegralList()
            }

            override fun onLoadMore(refreshLayout: RefreshLayout) {
                pageNum++
                getIntegralList()
            }
        })
        empty_view?.setLoadListener {
            pageNum = 1
            getIntegralList()
        }
        recycler.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        adapter = IntegralListAdapter()
        recycler.adapter = adapter
        initHeader()
    }

    private fun initHeader() {
        headerView = View.inflate(this, R.layout.header_integral_list, null)
        headerView!!.tv_recharge.setOnClickListener {
            startActivity(Intent(this, RechargeIntegralActivity::class.java))
        }
        adapter?.addHeaderView(headerView!!)
    }

    override fun initData() {
        super.initData()
        getIntegralList()
    }

    override fun onResume() {
        super.onResume()
        getUserIntegral()
    }

    private fun getUserIntegral() {
        if (UserMgr.isLogin()) {
            val uid = UserMgr.getUid()
            HttpUtil.getInstance().getUserIntegral(uid, object : ResultCallback<UserIntegral>() {
                override fun onSuccess(s: ResultEntity<UserIntegral>) {
                    headerView?.tv_integral_value?.text = s.data.integral
                }
            })
        }
    }

    private fun getIntegralList() {
        val uid = UserMgr.getUid()
        HttpUtil.getInstance().getGrades(
            uid,
            -1,
            pageNum,
            Constant.PAGE_SIZE.toInt(),
            object : ResultCallback<MutableList<GradeBean>>() {
                override fun onSuccess(s: ResultEntity<MutableList<GradeBean>>) {
                    val data = s.data
                    val newData = mutableListOf<Any>()
                    newData.addAll(data)
                    if (pageNum == 1) {
                        if (newData.isEmpty()) {
                            newData.add("空状态")
                        }
                        adapter?.setNewInstance(newData)
                    } else {
                        adapter?.addData(data)
                    }
                    if (data.size >= Constant.PAGE_SIZE.toInt()) {
                        refresh_layout?.setEnableLoadMore(true)
                    } else {
                        refresh_layout?.setEnableLoadMore(false)
                    }
                    refresh_layout?.finishRefresh()
                    refresh_layout?.finishLoadMore()
                    empty_view?.visibility = View.GONE
                }

                override fun onFailure(err: String?, code: Int) {
                    super.onFailure(err, code)
                    if (empty_view?.visibility == View.VISIBLE) {
                        empty_view?.setLoadFail()
                    }
                    refresh_layout?.setEnableLoadMore(false)
                    refresh_layout?.finishRefresh(false)
                    refresh_layout?.finishLoadMore(false)
                    if (pageNum > 1) {
                        pageNum--
                    }
                }
            })
    }
}