package com.xizhu.qiyou.ui.main

import android.content.Context
import android.content.Intent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.scwang.smart.refresh.layout.api.RefreshLayout
import com.scwang.smart.refresh.layout.listener.OnRefreshLoadMoreListener
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.BaseApp
import com.xizhu.qiyou.ext.getApiService
import com.xizhu.qiyou.http.retrofit.ResultObserver
import com.xizhu.qiyou.http.retrofit.scheduler.IoMainScheduler
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.ui.search.SearchAdapter
import com.xizhu.qiyou.widget.EmptyView
import kotlinx.android.synthetic.main.activity_game_list.*
import kotlinx.android.synthetic.main.title_layout.*
import java.util.*

class LastGameActivity : BaseCompatActivity() {
    private var adapter: SearchAdapter? = null
    private var pageNum = 1

    companion object {
        fun start(context: Context?) {
            val intent = Intent(context, LastGameActivity::class.java)
            context?.startActivity(intent)
        }
    }


    override fun getRes(): Int {
        return R.layout.activity_game_list
    }

    override fun initView() {
        iv_back.setOnClickListener {
            finish()
        }
        tv_page_title.text = "每日新发现"
        refresh_layout?.setOnRefreshLoadMoreListener(object : OnRefreshLoadMoreListener {
            override fun onRefresh(refreshLayout: RefreshLayout) {
                pageNum = 1
                getGameList()
            }

            override fun onLoadMore(refreshLayout: RefreshLayout) {
                pageNum++
                getGameList()
            }
        })
        empty_view?.setLoadListener {
            pageNum = 1
            getGameList()
        }
        recycler.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        adapter = SearchAdapter().apply {
            setEmptyView(EmptyView(this@LastGameActivity).setNoData())
            setOnItemClickListener { _, _, position ->
                val item = getItem(position)
                JumpUtils.jumpToGameDetailsPage(this@LastGameActivity, item.id)
            }
        }
        recycler.adapter = adapter
    }

    override fun initData() {
        super.initData()
        getGameList()
    }

    private fun getGameList() {
        val params = HashMap<String, String>()
        params["type"] = "0"
        params["page"] = pageNum.toString()
        params["pageSize"] = Constant.PAGE_SIZE
        getApiService()
            .getNewApp(params)
            .compose(IoMainScheduler())
            .subscribe(object : ResultObserver<MutableList<BaseApp>>() {
                override fun success(t: MutableList<BaseApp>) {
                    if (pageNum == 1) {
                        adapter?.setNewInstance(t)
                    } else {
                        adapter?.addData(t)
                    }
                    if (t.size >= Constant.PAGE_SIZE.toInt()) {
                        refresh_layout?.setEnableLoadMore(true)
                    } else {
                        refresh_layout?.setEnableLoadMore(false)
                    }
                    refresh_layout?.finishRefresh()
                    refresh_layout?.finishLoadMore()
                    empty_view?.visibility = View.GONE
                }

                override fun error(msg: String?, code: Int) {
                    if (empty_view?.visibility == View.VISIBLE) {
                        empty_view?.setLoadFail()
                    }
                    refresh_layout?.setEnableLoadMore(false)
                    refresh_layout?.finishRefresh(false)
                    refresh_layout?.finishLoadMore(false)
                    if (pageNum > 1) {
                        pageNum--
                    }
                }

            })
    }
}