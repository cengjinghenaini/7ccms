package com.xizhu.qiyou.inter;
import com.alibaba.sdk.android.oss.model.GetObjectRequest;

public interface OssGetProgress {
    void onProgress(GetObjectRequest request, long currentSize, long totalSize);
}
