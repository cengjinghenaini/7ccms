package com.xizhu.qiyou.ui.main

import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.BaseApp
import com.xizhu.qiyou.util.ImgLoadUtil

class HomeLikeAdapter :
    BaseQuickAdapter<BaseApp?, BaseViewHolder>(R.layout.item_recy_home_like) {

    override fun convert(holder: BaseViewHolder, item: BaseApp?) {
        ImgLoadUtil.load(holder.getView(R.id.iv_game_logo), item?.icon)
        holder.setText(R.id.tv_game_name, item?.name)
    }
}