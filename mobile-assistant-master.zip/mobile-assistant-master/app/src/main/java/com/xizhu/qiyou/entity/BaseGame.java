package com.xizhu.qiyou.entity;

public class BaseGame {


    /**
     * app_id : value
     * sort : value
     * createtime : value
     * app : {"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value","is_reserve":"value","yiyuyue":"value"}
     * createtime_f : value
     */

    protected String app_id;
    protected String sort;
    protected String createtime;
    protected BaseApp app;
    protected String createtime_f;



    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public BaseApp getApp() {
        return app;
    }

    public void setApp(BaseApp app) {
        this.app = app;
    }

    public String getCreatetime_f() {
        return createtime_f;
    }

    public void setCreatetime_f(String createtime_f) {
        this.createtime_f = createtime_f;
    }


}

