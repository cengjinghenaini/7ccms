package com.xizhu.qiyou.entity;

import android.os.Parcel;

import java.util.List;

public class DetailGame extends BaseApp {

    /**
     * id : value
     * pic : value
     * title : value
     * name : value
     * icon : value
     * introduction : value
     * score : value
     * comment_count : value
     * version : value
     * size : value
     * down_time : value
     * rec_reason : value
     * labels : [{"id":"value","name":"value"}]
     * user : {"uid":"value","name":"value","head":"value","touxian":"value"}
     * isAttention : value
     * rewards : [{"uid":"","head":"","name":"","integral":"","createtime":"","createtime_f":""}]
     * rec_apps : [{"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value"}]
     * pics : ["",""]
     * tip :
     * update_tip :
     * desc :
     * reward_count :
     */


    private User user;
    private String isAttention;
    private String tip;
    private List<String> update_tip;

    private String reward_count;
    private List<RewardUser> rewards;
    private List<RecApp> rec_apps;
    private List<String> pics;
    private int is_collect;
    private String fee_status;//0.免费，1.付费
    private String is_gratis_down;//是否显示普通下载按钮
    private String is_speed_down;//是否显示极速下载按钮
    private String down_integral;//下载需要的积分
    private String createtime;
    private String download_url;//

    public DetailGame() {

    }

    protected DetailGame(Parcel in) {
        super(in);
    }

    public User getUser() {
        return user;
    }

    public String getIsAttention() {
        return isAttention;
    }

    public String getTip() {
        return tip;
    }

    public List<String> getUpdate_tip() {
        return update_tip;
    }


    public String getReward_count() {
        return reward_count;
    }

    public List<RewardUser> getRewards() {
        return rewards;
    }

    public List<RecApp> getRec_apps() {
        return rec_apps;
    }

    public List<String> getPics() {
        return pics;
    }

    public int getIs_collect() {
        return is_collect;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setIsAttention(String isAttention) {
        this.isAttention = isAttention;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public void setUpdate_tip(List<String> update_tip) {
        this.update_tip = update_tip;
    }


    public void setReward_count(String reward_count) {
        this.reward_count = reward_count;
    }

    public void setRewards(List<RewardUser> rewards) {
        this.rewards = rewards;
    }

    public void setRec_apps(List<RecApp> rec_apps) {
        this.rec_apps = rec_apps;
    }

    public void setPics(List<String> pics) {
        this.pics = pics;
    }

    public void setIs_collect(int is_collect) {
        this.is_collect = is_collect;
    }

    public String getFee_status() {
        return fee_status;
    }

    public void setFee_status(String fee_status) {
        this.fee_status = fee_status;
    }

    public String getDown_integral() {
        return down_integral;
    }

    public void setDown_integral(String down_integral) {
        this.down_integral = down_integral;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getDownload_url() {
        return download_url;
    }

    public void setDownload_url(String download_url) {
        this.download_url = download_url;
    }

    public String getIs_gratis_down() {
        return is_gratis_down;
    }

    public void setIs_gratis_down(String is_gratis_down) {
        this.is_gratis_down = is_gratis_down;
    }

    public String getIs_speed_down() {
        return is_speed_down;
    }

    public void setIs_speed_down(String is_speed_down) {
        this.is_speed_down = is_speed_down;
    }

    @Override
    public String toString() {
        return "DetailGame{" +
                "user=" + user +
                ", isAttention='" + isAttention + '\'' +
                ", tip='" + tip + '\'' +
                ", update_tip='" + update_tip + '\'' +
                ", reward_count='" + reward_count + '\'' +
                ", rewards=" + rewards +
                ", rec_apps=" + rec_apps +
                ", pics=" + pics +
                ", is_collect=" + is_collect +
                '}';
    }
}
