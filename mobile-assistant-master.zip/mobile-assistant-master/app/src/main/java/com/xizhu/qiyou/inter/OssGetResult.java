package com.xizhu.qiyou.inter;


import com.alibaba.sdk.android.oss.model.GetObjectRequest;
import com.alibaba.sdk.android.oss.model.GetObjectResult;

public interface OssGetResult {
    void onSuccess(GetObjectRequest request, GetObjectResult result);
}
