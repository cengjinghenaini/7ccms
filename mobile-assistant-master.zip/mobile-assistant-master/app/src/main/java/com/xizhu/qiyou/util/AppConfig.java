package com.xizhu.qiyou.util;

import android.app.Application;
import android.graphics.Color;
import android.os.Environment;

import com.xizhu.qiyou.room.AppDataBase;
import com.xizhu.qiyou.room.entity.TranslationConfig;

public class AppConfig {


    public static boolean interceptor = false;
    private static final String TAG = "AppConfig";
    private static Application application;
    public static final String ZIP_IN_PATH = Environment.getExternalStorageDirectory() + "/Android/obb";

    public static void init(Application application) {
        AppConfig.application = application;

        //阿里云oss
        Oss.init(application);
        //腾讯oss
        Cos.init(application);
        //微信开放
        WXQQ.init(application);
        //网络状态监听
        NetUtil.init(application);

    }

    public static Application getApplication() {
        return application;
    }

    public static TranslationConfig getTranslationConfig() {
        TranslationConfig translationConfig = AppDataBase.getInstance(application).getConfigDao().queryById(1);
        if (translationConfig == null) {
            translationConfig = new TranslationConfig();
            translationConfig.setId(1);
            translationConfig.setFont_size(14);
            translationConfig.setFont_color_discern(Color.WHITE);
            translationConfig.setFont_color_translate(Color.WHITE);
            translationConfig.setFont_color_bg(0x00000000);

            translationConfig.setWind_aph(255);
            translationConfig.setButton_aph(255);
            translationConfig.setWind_time(0);

            translationConfig.setVertical(false);
            translationConfig.setWind_width(100);
            translationConfig.setWind_height(15);

            translationConfig.setLine_height(40);
            translationConfig.setLine_width(0);

            translationConfig.setTouchChoice(true);
            translationConfig.setFilter(false);
            translationConfig.setScree_err(false);
            translationConfig.setOnly_result(false);

            translationConfig.setQuicklyTrans(false);
            translationConfig.setWindowNum(1);
            translationConfig.setQuickly_time(2);
            translationConfig.setAssist(false);
            translationConfig.setWindowTrans(true);
            translationConfig.setTextTrans(false);


            translationConfig.setFrom("en");
            translationConfig.setTo("zh");

            translationConfig.setTencentSdk(false);

            AppDataBase.getInstance(application).getConfigDao().insert(translationConfig);
        }
        return translationConfig;
    }

    public static void setTranslationConfig(TranslationConfig translationConfig) {
        AppDataBase.getInstance(application).getConfigDao().update(translationConfig);
    }
}
