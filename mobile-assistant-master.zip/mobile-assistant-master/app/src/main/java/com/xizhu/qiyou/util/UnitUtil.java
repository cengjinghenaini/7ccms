package com.xizhu.qiyou.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.xizhu.qiyou.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UnitUtil {

    public static int dip2px(Context context, float dpValue) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    public static int px2dip(Context context, float pxValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }


    public static String wan(String count) {
        int i = Integer.parseInt(count);
        if (i > 10000) {
            return i / 10000 + "万";
        } else {
            return count;
        }
    }

    public static String zan(String count) {
        if (TextUtils.isEmpty(count)) {
            return "0";
        }
        return count;
    }

    public static String fen(String score) {
        return score + "分";
    }

    public static String v(String v) {
        return "版本：" + v;
    }

    public static String sv(String s, String v) {
        return UnitUtil.zao(s) + " / " + "v" + v;
    }

    @SuppressLint("DefaultLocale")
    public static String zao(String count) {
        if (TextUtils.isEmpty(count)) {
            return "0";
        }
        double b = Double.parseDouble(count);
        if (b > 1024 * 1024 * 1024) {
            double g = b / 1024 / 1024 / 1024;
            return String.format("%.2f", g) + "G";
        } else if (b > 1024 * 1024) {
            double g = b / 1024 / 1024;
            return String.format("%.2f", g) + "M";
        } else if (b > 1024) {
            double g = b / 1024;
            return String.format("%.2f", g) + "K";
        } else {
            return String.format("%.2f", b) + "B";
        }


//        if (b > 1024) {
//            double k = b / 1024;
//            if (k > 1024) {
//                double m = b / 1024 / 1024;
//                if (m > 1024) {
//                    double g = b / 1024 / 2014 / 1024;
//                    return String.format("%.2f", g) + "G";
//                } else {
//                    return String.format("%.2f", m) + "M";
//                }
//            } else {
//                return String.format("%.2f", k) + "K";
//            }
//        } else {
//            return String.format("%.2f", b) + "B";
//        }
    }

    public static String dzao(String curr, String fileSize) {
        String currZao = UnitUtil.zao(curr);
        String fileZao = UnitUtil.zao(fileSize);
        return currZao + "/" + fileZao;
    }

    public static String pin(String count) {
        if (TextUtils.isEmpty(count)) {
            count = "0";
        }
        return count + "条评论";
    }


    public static void setTouxian(TextView touxain, TextView touxain2, String tou, String tou2) {

        if (TextUtils.isEmpty(tou)) {
            touxain.setVisibility(View.GONE);
        } else {
            touxain.setText(tou);
        }


        if (TextUtils.isEmpty(tou2)) {
            touxain2.setVisibility(View.GONE);
        } else {
            touxain2.setText(tou2);
        }
    }

    public static String pinp(String count) {
        if (TextUtils.isEmpty(count)) {
            count = "0";
        }
        return "(" + count + ")";
    }


    public static String timeM(String formatTime) {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date parse = sdf.parse(formatTime);

            DateFormat df1 = DateFormat.getDateInstance();
            if (parse == null) {
                return "";
            }
            return df1.format(parse);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }


    public static String time(String seconds) {
        if (seconds == null) {
            return null;
        }
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm");
        Calendar calendar = new GregorianCalendar();

        calendar.setTime(new Date());
        calendar.add(Calendar.DATE, -1);
        String yesterday = sdf.format(calendar.getTime());

        calendar.clear();
        calendar.setTime(new Date());
        calendar.add(Calendar.DATE, -2);
        String bYesterday = sdf.format(calendar.getTime());

        String today = sdf.format(new Date());


        Date date = new Date(Long.parseLong(seconds + "000"));
        String target = sdf.format(date);
        String time = sdf1.format(date);

        if (TextUtils.equals(target, today)) {
            return "今天 " + time;
        } else if (TextUtils.equals(target, yesterday)) {
            return "昨天 " + time;
        } else if (TextUtils.equals(target, bYesterday)) {
            return "前天 " + time;
        } else {
            return target;
        }
    }


    public static String timeStamp2Date(String seconds) {
        if (TextUtils.isEmpty(seconds)) {
            return "";
        }
        String format = "yyyy-MM-dd";
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(new Date(Long.parseLong(seconds + "000")));
    }


    public static int getStatusBarHeight(Context context) {
        Resources resources = context.getResources();
        int resourceId = resources.getIdentifier("status_bar_height", "dimen", "android");
        return resources.getDimensionPixelSize(resourceId);
    }

    public static String level(String v) {
        return "v" + v;
    }

    public static String reward(String integral) {
        return " + " + integral + "积分";
    }

    public static String bill(int position) {
        return "楼层" + (position + 1);
    }

    public static String touxian(String touxian) {
        if (TextUtils.isEmpty(touxian)) {
            return "暂无";
        }
        return touxian;
    }

    public static String touxian2(String touxian) {
        if (TextUtils.isEmpty(touxian)) {
            return "暂无";
        }
        return touxian;
    }

    public static void zanSub(TextView zan_count) {
        zan_count.setSelected(false);
        zan_count.setText(String.valueOf(Integer.parseInt((String) zan_count.getText()) - 1));
    }

    public static void zanAdd(TextView zan_count) {
        zan_count.setSelected(true);
        zan_count.setText(String.valueOf(Integer.parseInt((String) zan_count.getText()) + 1));
    }

    public static String msg(String type, String content) {
        //0.评论回复，1.帖子点赞，2.帖子评论，3.帖子中被@
        content = (TextUtils.isEmpty(content) ? "" : content);
        switch (type) {
            case "0":
                return "回复了你：" + content;
            case "1":
                return "赞了你" + content;
            case "2":
                return "评论了你的帖子: " + content;
            case "3":
            case "4":
                return "@了你：" + content;
            default:
                return "";

        }
    }

    public static String[] month(String month) {
        if (TextUtils.isEmpty(month)) {
            return new String[]{"推荐", "推荐"};
        }

        String curr = month + "月推荐";
        int i = Integer.parseInt(month) - 1;
        if (i == 0) {
            i = 12;
        }
        String prev = i + "月推荐";

        return new String[]{curr, prev};

    }

    public static int pattern(String text, String compile) {
        if (text == null) {
            return 0;
        }
        // 根据指定的字符构建正则
        Pattern pattern = Pattern.compile(compile);
        // 构建字符串和正则的匹配
        Matcher matcher = pattern.matcher(text);
        int count = 0;
        // 循环依次往下匹配
        while (matcher.find()) { // 如果匹配,则数量+1
            count++;
        }
        return count;
    }
}
