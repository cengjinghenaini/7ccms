package com.xizhu.qiyou.entity;

import android.os.Parcel;

public class GameGame extends BaseApp{
    protected GameGame(Parcel in) {
        super(in);
    }

    /**
     * id : value
     * pic : value
     * title : value
     * name : value
     * icon : value
     * introduction : value
     * score : value
     * comment_count : value
     * version : value
     * size : value
     * down_time : value
     * rec_reason : value
     * is_reserve : value
     * yiyuyue : value
     */


}
