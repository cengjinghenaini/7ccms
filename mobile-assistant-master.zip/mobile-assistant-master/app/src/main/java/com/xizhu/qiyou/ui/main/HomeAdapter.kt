package com.xizhu.qiyou.ui.main

import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import androidx.core.content.ContextCompat
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R
import com.xizhu.qiyou.entity.HomeGame
import com.xizhu.qiyou.util.ImgLoadUtil
import com.xizhu.qiyou.util.UnitUtil

class HomeAdapter : BaseQuickAdapter<HomeGame, BaseViewHolder>(R.layout.item_recy_home_normal) {

    override fun convert(holder: BaseViewHolder, item: HomeGame) {
        ImgLoadUtil.load(holder.getView(R.id.iv_game_logo), item.icon)
        holder.setText(R.id.tv_game_name, item.name)
        val spannable = SpannableString("描述：${item.introduction}")
        val pinkColor =
            ContextCompat.getColor(context, R.color.color_main_pink)
        spannable.setSpan(
            ForegroundColorSpan(pinkColor),
            0, 3,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        holder.setText(R.id.tv_game_des, spannable)
        holder.setText(R.id.tv_game_size, UnitUtil.zao(item.size))

        ImgLoadUtil.load(holder.getView(R.id.iv_game_cover), item.pic)
    }
}