package com.xizhu.qiyou.entity.Events;

public class ReviewGrade {
    private String integral;

    public ReviewGrade(String integral) {
        this.integral = integral;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }
}
