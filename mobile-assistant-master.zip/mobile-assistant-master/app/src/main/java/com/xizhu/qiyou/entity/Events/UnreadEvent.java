package com.xizhu.qiyou.entity.Events;

public class UnreadEvent {
    private final int count;

    public UnreadEvent(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }
}
