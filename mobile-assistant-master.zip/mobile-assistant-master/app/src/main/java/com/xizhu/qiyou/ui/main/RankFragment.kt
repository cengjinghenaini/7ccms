package com.xizhu.qiyou.ui.main

import android.content.Context
import android.graphics.Color
import androidx.core.content.ContextCompat
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.widget.IndicatorFragment
import com.xizhu.qiyou.widget.IndicatorViewPagerAdapter
import kotlinx.android.synthetic.main.fragment_rank.*
import net.lucode.hackware.magicindicator.ViewPagerHelper
import net.lucode.hackware.magicindicator.buildins.UIUtil
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView
import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.ClipPagerTitleView

class RankFragment : BaseFragment() {
    private var commonNavigator: CommonNavigator? = null
    private val indicatorFragmentList = mutableListOf<IndicatorFragment>()


    override fun getRes(): Int {
        return R.layout.fragment_rank
    }

    override fun initView() {
        super.initView()
        initMagicIndicator()
        createFragment()
    }


    private fun initMagicIndicator() {
        commonNavigator = CommonNavigator(context)
        commonNavigator?.isSkimOver = true
        commonNavigator?.adapter = object : CommonNavigatorAdapter() {

            override fun getCount(): Int {
                return indicatorFragmentList.size
            }

            override fun getTitleView(context: Context?, index: Int): IPagerTitleView? {
                val clipPagerTitleView = ClipPagerTitleView(context)
                clipPagerTitleView.text = indicatorFragmentList[index].title
                clipPagerTitleView.textSize = UIUtil.dip2px(context, 14.0).toFloat()
                val dp17 = UIUtil.dip2px(context, 17.0)
                clipPagerTitleView.setPadding(dp17, 0, dp17, 0)
                clipPagerTitleView.textColor =
                    ContextCompat.getColor(context!!, R.color.color_main_pink)
                clipPagerTitleView.clipColor = Color.WHITE
                clipPagerTitleView.setOnClickListener { view_pager?.currentItem = index }
                return clipPagerTitleView
            }

            override fun getIndicator(context: Context?): IPagerIndicator {
                val indicator = LinePagerIndicator(context)
                indicator.lineHeight = UIUtil.dip2px(context, 28.0).toFloat()
                indicator.setColors(ContextCompat.getColor(context!!, R.color.color_main_pink))
                return indicator
            }
        }
        magic_indicator?.navigator = commonNavigator
        if (magic_indicator != null && view_pager != null) {
            ViewPagerHelper.bind(magic_indicator, view_pager)
        }
    }


    private fun createFragment() {
        view_pager?.removeAllViewsInLayout()
        indicatorFragmentList.clear()
        indicatorFragmentList.add(
            IndicatorFragment(
                "评分",
                RankPageFragment.instance(2)
            )
        )
        indicatorFragmentList.add(
            IndicatorFragment(
                "下载",
                RankPageFragment.instance(1)
            )
        )

        val indicatorViewPagerAdapter =
            IndicatorViewPagerAdapter(childFragmentManager, commonNavigator) { _, _ -> }
        indicatorViewPagerAdapter.setData(indicatorFragmentList)
        view_pager?.adapter = indicatorViewPagerAdapter
        view_pager?.currentItem = 0
        magic_indicator?.onPageSelected(0)
    }
}