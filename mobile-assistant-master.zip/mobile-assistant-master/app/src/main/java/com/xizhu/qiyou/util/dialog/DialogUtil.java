package com.xizhu.qiyou.util.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.viewpager.widget.ViewPager;

import com.arialyy.aria.core.Aria;
import com.tencent.connect.share.QQShare;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXMusicObject;
import com.tencent.mm.opensdk.modelmsg.WXTextObject;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.UiError;
import com.xizhu.qiyou.R;
import com.xizhu.qiyou.config.API;
import com.xizhu.qiyou.config.Constant;
import com.xizhu.qiyou.entity.BaseApp;
import com.xizhu.qiyou.entity.Comment;
import com.xizhu.qiyou.entity.DetailGame;
import com.xizhu.qiyou.entity.Events.Gambit;
import com.xizhu.qiyou.entity.Events.MenuLink;
import com.xizhu.qiyou.entity.Events.PayGrade;
import com.xizhu.qiyou.entity.Events.PointXuanShang;
import com.xizhu.qiyou.entity.Events.ReviewGrade;
import com.xizhu.qiyou.entity.Events.Reward;
import com.xizhu.qiyou.entity.Events.UpdateComment;
import com.xizhu.qiyou.entity.Events.UpdatePoint;
import com.xizhu.qiyou.entity.Events.UpdatePointList;
import com.xizhu.qiyou.entity.Events.UpdateSheetSet;
import com.xizhu.qiyou.entity.Events.UpdateTail;
import com.xizhu.qiyou.entity.Events.XuanShang;
import com.xizhu.qiyou.entity.NULL;
import com.xizhu.qiyou.entity.Point;
import com.xizhu.qiyou.entity.QianDao;
import com.xizhu.qiyou.entity.RecGame;
import com.xizhu.qiyou.entity.Ring;
import com.xizhu.qiyou.entity.SheetInfo;
import com.xizhu.qiyou.entity.XieYi;
import com.xizhu.qiyou.http.HttpUtil;
import com.xizhu.qiyou.http.result.ResultCallback;
import com.xizhu.qiyou.http.result.ResultEntity;
import com.xizhu.qiyou.room.AppDataBase;
import com.xizhu.qiyou.room.entity.Filter;
import com.xizhu.qiyou.room.entity.Replace;
import com.xizhu.qiyou.room.entity.TranslationConfig;
import com.xizhu.qiyou.util.AppConfig;
import com.xizhu.qiyou.util.LoginUtil;
import com.xizhu.qiyou.util.PhoneUtil;
import com.xizhu.qiyou.util.UnitUtil;
import com.xizhu.qiyou.util.UserMgr;
import com.xizhu.qiyou.util.WXQQ;
import com.xizhu.qiyou.widget.SwitchButton;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.util.List;

public class DialogUtil {
    public static void showGotoLoginActivity(Context context) {
        LoginUtil.getInstance((Activity) context).toLogin(null);
    }

    public static void showGotoLoginActivity(Context context, LoginUtil.ILoginSuccess iLoginSuccess) {
        LoginUtil.getInstance((Activity) context).toLogin(iLoginSuccess);
    }

    public static void simpleInfoDialog(Context context, String infoMsg, DialogUtil.CallBack<String> callBack) {
        Dialog dialog = new Dialog(context);
        View root = LayoutInflater.from(context).inflate(R.layout.dialog_simple_info, null);
        root.findViewById(R.id.btn_cancel).setOnClickListener(v -> dialog.dismiss());

        TextView tv_tishi = root.findViewById(R.id.tv_tishi);
        tv_tishi.setText(infoMsg);

        root.findViewById(R.id.btn_commit).setOnClickListener(v -> {
            dialog.dismiss();
            callBack.success("");
        });
        root.findViewById(R.id.btn_cancel).setOnClickListener(v -> {
            dialog.dismiss();
            callBack.failure("");
        });
        dialog.setContentView(root);
        dialog.show();

        Window window = dialog.getWindow();
        window.setBackgroundDrawableResource(R.drawable.shape_20_ffffffff);
        WindowManager.LayoutParams attributes = window.getAttributes();
//        attributes.flags =
        attributes.height = WindowManager.LayoutParams.WRAP_CONTENT;
        attributes.width = UnitUtil.dip2px(context, 300);
        attributes.gravity = Gravity.CENTER;
        window.setAttributes(attributes);
    }

    public interface CallBack<T> {
        void success(T t);

        void failure(String err);
    }
}
