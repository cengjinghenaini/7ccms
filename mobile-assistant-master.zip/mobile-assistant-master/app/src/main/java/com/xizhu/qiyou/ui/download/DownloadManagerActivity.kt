package com.xizhu.qiyou.ui.download

import android.content.Context
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat
import com.pass.util.DisplayUtil
import com.xizhu.qiyou.R
import com.xizhu.qiyou.apps.AppUtil
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.widget.IndicatorFragment
import com.xizhu.qiyou.widget.IndicatorViewPagerAdapter
import kotlinx.android.synthetic.main.fragment_game.*
import kotlinx.android.synthetic.main.title_layout.*
import net.lucode.hackware.magicindicator.ViewPagerHelper
import net.lucode.hackware.magicindicator.buildins.UIUtil
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView
import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.ColorTransitionPagerTitleView

/**
 * 下载管理
 */
class DownloadManagerActivity : BaseCompatActivity() {
    private var commonNavigator: CommonNavigator? = null
    private val indicatorFragmentList = mutableListOf<IndicatorFragment>()


    override fun getRes(): Int {
        return R.layout.activity_download_manager
    }

    override fun initView() {
        iv_back?.setOnClickListener { finish() }
        tv_page_title?.text = "下载管理"

        initMagicIndicator()
        createFragment()
    }


    private fun initMagicIndicator() {
        commonNavigator = CommonNavigator(this)
        commonNavigator?.isSkimOver = true
        commonNavigator?.adapter = object : CommonNavigatorAdapter() {

            override fun getCount(): Int {
                return indicatorFragmentList.size
            }

            override fun getTitleView(context: Context?, index: Int): IPagerTitleView? {
                val simplePagerTitleView = ColorTransitionPagerTitleView(context)
                simplePagerTitleView.text = indicatorFragmentList[index].title
                simplePagerTitleView.setPadding(
                    DisplayUtil.dip2px(context, 12f),
                    0,
                    DisplayUtil.dip2px(context, 12f),
                    0
                )
                simplePagerTitleView.normalColor =
                    ContextCompat.getColor(context!!, R.color.color_7c7c7c)
                simplePagerTitleView.selectedColor =
                    ContextCompat.getColor(context, R.color.color_main_pink)
                simplePagerTitleView.textSize = 18F
                simplePagerTitleView.setOnClickListener { view_pager?.currentItem = index }
                return simplePagerTitleView
            }

            override fun getIndicator(context: Context?): IPagerIndicator {
                val indicator = LinePagerIndicator(context)
                indicator.mode = LinePagerIndicator.MODE_EXACTLY
                indicator.lineHeight = UIUtil.dip2px(context, 4.0).toFloat()
                indicator.lineWidth = UIUtil.dip2px(context, 22.0).toFloat()
                indicator.roundRadius = UIUtil.dip2px(context, 2.0).toFloat()
                indicator.startInterpolator = AccelerateInterpolator()
                indicator.endInterpolator = DecelerateInterpolator(2.0f)
                indicator.setColors(ContextCompat.getColor(context!!, R.color.color_main_pink))
                return indicator
            }
        }
        magic_indicator?.navigator = commonNavigator
        if (magic_indicator != null && view_pager != null) {
            ViewPagerHelper.bind(magic_indicator, view_pager)
        }
    }


    private fun createFragment() {
        view_pager?.removeAllViewsInLayout()
        indicatorFragmentList.clear()
        indicatorFragmentList.add(
            IndicatorFragment(
                "正在下载",
                DownloadFragment.instance(0)
            )
        )
        indicatorFragmentList.add(
            IndicatorFragment(
                "等待安装",
                DownloadFragment.instance(1)
            )
        )

        val indicatorViewPagerAdapter =
            IndicatorViewPagerAdapter(supportFragmentManager, commonNavigator) { _, _ -> }
        indicatorViewPagerAdapter.setData(indicatorFragmentList)
        view_pager?.adapter = indicatorViewPagerAdapter
        view_pager?.currentItem = 0
        magic_indicator?.onPageSelected(0)
    }

    override fun onResume() {
        super.onResume()
        AppUtil.saveGameId(this, "all")
    }
}