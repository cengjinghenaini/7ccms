package com.xizhu.qiyou.http;

import androidx.annotation.NonNull;

import com.xizhu.qiyou.BuildConfig;
import com.xizhu.qiyou.util.LogUtil;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;

public class HttpClient {
    private static HttpClient INSTANCE;
    private final OkHttpClient client;

    private HttpClient() {
        client = build();
    }

    public static OkHttpClient build() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor logInterceptor = new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
                @Override
                public void log(@NonNull String message) {
                    try {
                        LogUtil.d(LogUtil.unicodeToUtf8(message));
                    } catch (Exception e) {
                        LogUtil.d(message);
                        e.printStackTrace();
                    }
                }
            });

            logInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            builder.addInterceptor(logInterceptor);
        }
        return builder
                .callTimeout(30, TimeUnit.SECONDS)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    public static HttpClient getInstance() {
        if (INSTANCE == null) {
            synchronized (HttpClient.class) {
                if (INSTANCE == null) {
                    INSTANCE = new HttpClient();
                }
            }
        }
        return INSTANCE;
    }

    public void enqueue(Request request, Callback callback) {
        client.newCall(request).enqueue(callback);
    }

    public Response execute(Request request) throws IOException {
        return client.newCall(request).execute();
    }
}
