package com.xizhu.qiyou.http.retrofit;

import com.xizhu.qiyou.config.API;
import com.xizhu.qiyou.entity.BaseApp;
import com.xizhu.qiyou.entity.BaseGame;
import com.xizhu.qiyou.entity.Comment;
import com.xizhu.qiyou.entity.DownloadInfo;
import com.xizhu.qiyou.entity.GameBigPicture;
import com.xizhu.qiyou.entity.HomeGame;
import com.xizhu.qiyou.entity.Kf;
import com.xizhu.qiyou.entity.Label;
import com.xizhu.qiyou.entity.NULL;
import com.xizhu.qiyou.entity.Shaky;
import com.xizhu.qiyou.entity.SignInInfo;
import com.xizhu.qiyou.entity.Special;
import com.xizhu.qiyou.http.result.ResultEntity;

import java.util.List;
import java.util.Map;

import io.reactivex.Observable;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiServer {

    @FormUrlEncoded
    @POST(API.kf)
    Observable<ResultEntity<Kf>> kf(@FieldMap Map<String, String> map);

    @FormUrlEncoded
    @POST(API.addUserSheetApp)
    Observable<ResultEntity<NULL>> addUserSheetApp(@FieldMap Map<String, String> map);

    @FormUrlEncoded
    @POST(API.getAppLabel)
    Observable<ResultEntity<List<Label>>> getAppLabel(@FieldMap Map<String, String> map);

    @FormUrlEncoded
    @POST(API.getTopic)
    Observable<ResultEntity<List<Special>>> getTopic(@FieldMap Map<String, String> map);

    @FormUrlEncoded
    @POST(API.getNewApp)
    Observable<ResultEntity<List<BaseApp>>> getNewApp(@FieldMap Map<String, String> map);

    /**
     * 获取活动列表
     */
    @FormUrlEncoded
    @POST(API.getActiveList)
    Observable<ResultEntity<List<Shaky>>> getActiveList(@FieldMap Map<String, String> map);

    /**
     * 获取活动详情
     */
    @FormUrlEncoded
    @POST(API.getActiveDetails)
    Observable<ResultEntity<Shaky>> getActiveDetails(@FieldMap Map<String, String> map);

    /**
     * 首页大图推荐
     */
    @FormUrlEncoded
    @POST(API.getBigPicture)
    Observable<ResultEntity<List<GameBigPicture>>> getBigPicture(@FieldMap Map<String, String> map);

    /**
     * 热门游戏
     */
    @FormUrlEncoded
    @POST(API.getHotGame)
    Observable<ResultEntity<List<BaseGame>>> getHotGame(@FieldMap Map<String, String> map);

    /**
     * 首页游戏
     */
    @FormUrlEncoded
    @POST("Api/Home/getBigPicApp")
    Observable<ResultEntity<List<HomeGame>>> getHomeGame(@FieldMap Map<String, String> map);

    /**
     * 获取应用评论
     */
    @FormUrlEncoded
    @POST(API.getAppComment)
    Observable<ResultEntity<List<Comment>>> getAppComment(@FieldMap Map<String, String> map);

    /**
     * 评论应用或者回复应用
     */
    @FormUrlEncoded
    @POST(API.commentApp)
    Observable<ResultEntity<NULL>> commentApp(@FieldMap Map<String, Object> map);

    /**
     * 签到
     */
    @FormUrlEncoded
    @POST("Api/Home/signIn")
    Observable<ResultEntity<SignInInfo>> signIn(@FieldMap Map<String, Object> map);

    /**
     * 签到
     */
    @FormUrlEncoded
    @POST("Api/Home/getSignInDate")
    Observable<ResultEntity<List<String>>> getSignInDate(@FieldMap Map<String, Object> map);

    /**
     * 下载APP
     */
    @FormUrlEncoded
    @POST("Api/Home/downloadApp")
    Observable<ResultEntity<DownloadInfo>> downloadApp(@FieldMap Map<String, Object> map);

    /**
     * 分享增加下载次数
     */
    @FormUrlEncoded
    @POST("Api/Home/shareAddDownCount")
    Observable<ResultEntity<Object>> shareAddDownCount(@FieldMap Map<String, Object> map);

    /**
     * 增加下载数量
     */
    @FormUrlEncoded
    @POST("Api/Home/addAppDownCount")
    Observable<ResultEntity<Object>> addAppDownCount(@FieldMap Map<String, Object> map);

    /**
     * 找回密码
     */
    @FormUrlEncoded
    @POST("Api/User/secretPassword")
    Observable<ResultEntity<NULL>> retrievePassword(@FieldMap Map<String, Object> map);

    /**
     * 获取h5地址
     */
    @FormUrlEncoded
    @POST("Api/Public/getSetting")
    Observable<ResultEntity<Map<String, String>>> getH5Url(@FieldMap Map<String, Object> map);

    /**
     * 获取
     */
    @FormUrlEncoded
    @POST("Api/Public/pageContent")
    Observable<ResultEntity<Map<String, String>>> getPageContent(@FieldMap Map<String, Object> map);

}
