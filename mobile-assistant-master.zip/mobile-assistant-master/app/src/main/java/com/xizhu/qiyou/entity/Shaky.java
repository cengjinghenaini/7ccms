package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class Shaky implements Serializable {

    /**
     * id : 1
     * name :
     * cate_id :
     * pic :
     * is_shequ :
     * posts_id : 帖子id
     * starttime :
     * endtime :
     * createtime :
     * status : 0.未开始，1.进行中，2.已结束
     * createtime_f :
     */

    private String id;
    private String name;
    private String cate_id;
    private String pic;
    private String is_shequ;
    private String posts_id;
    private String starttime;
    private String endtime;
    private String createtime;
    private String status;
    private String createtime_f;
    private String url;
    private String show_type;
    private String content;
    private int is_read;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCate_id() {
        return cate_id;
    }

    public void setCate_id(String cate_id) {
        this.cate_id = cate_id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getIs_shequ() {
        return is_shequ;
    }

    public void setIs_shequ(String is_shequ) {
        this.is_shequ = is_shequ;
    }

    public String getPosts_id() {
        return posts_id;
    }

    public void setPosts_id(String posts_id) {
        this.posts_id = posts_id;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatetime_f() {
        return createtime_f;
    }

    public void setCreatetime_f(String createtime_f) {
        this.createtime_f = createtime_f;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getShow_type() {
        return show_type;
    }

    public void setShow_type(String show_type) {
        this.show_type = show_type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getIs_read() {
        return is_read;
    }

    public void setIs_read(int is_read) {
        this.is_read = is_read;
    }
}
