package com.xizhu.qiyou.entity;

public class SheetChoice {
    public static final String TYPE_SHEET = "0";
    public static final String TYPE_TOPIC = "1";
    /**
     * id : value
     * sheet_id : value
     * pic : value
     * sort : value
     * createtime : value
     * sheet : {"id":"value","pic":"value","uid":"value","title":"value","zan_count":"value","collect_count":"value","comment_count":"value","name":"value","head":"value"}
     */

    private String id;
    private String sheet_id;
    private String pic;
    private String sort;
    private String createtime;
    private String type;
    private BaseSheet sheet;
    private Special topic;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Special getTopic() {
        return topic;
    }

    public void setTopic(Special topic) {
        this.topic = topic;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSheet_id() {
        return sheet_id;
    }

    public void setSheet_id(String sheet_id) {
        this.sheet_id = sheet_id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public BaseSheet getSheet() {
        return sheet;
    }

    public void setSheet(BaseSheet sheet) {
        this.sheet = sheet;
    }

}
