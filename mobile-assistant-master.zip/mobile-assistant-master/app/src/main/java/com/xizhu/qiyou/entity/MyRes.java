package com.xizhu.qiyou.entity;

public class MyRes {

    /**
     * id :
     * app_id :
     * icon :
     * name :
     * version :
     * size :
     * rec_reason : 推荐理由
     * status : 0.待审核，1.通过，2.拒绝
     * check_reason : 审核理由
     * createtime :
     */

    private String id;
    private String app_id;
    private String icon;
    private String name;
    private String version;
    private String size;
    private String rec_reason;
    private String status;
    private String check_reason;
    private String createtime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getRec_reason() {
        return rec_reason;
    }

    public void setRec_reason(String rec_reason) {
        this.rec_reason = rec_reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCheck_reason() {
        return check_reason;
    }

    public void setCheck_reason(String check_reason) {
        this.check_reason = check_reason;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    @Override
    public String toString() {
        return "MyRes{" +
                "id='" + id + '\'' +
                ", app_id='" + app_id + '\'' +
                ", icon='" + icon + '\'' +
                ", name='" + name + '\'' +
                ", version='" + version + '\'' +
                ", size='" + size + '\'' +
                ", rec_reason='" + rec_reason + '\'' +
                ", status='" + status + '\'' +
                ", check_reason='" + check_reason + '\'' +
                ", createtime='" + createtime + '\'' +
                '}';
    }
}
