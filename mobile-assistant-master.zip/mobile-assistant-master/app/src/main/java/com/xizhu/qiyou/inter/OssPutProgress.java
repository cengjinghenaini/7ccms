package com.xizhu.qiyou.inter;

import com.alibaba.sdk.android.oss.model.PutObjectRequest;

public interface OssPutProgress {
     void onProgress(PutObjectRequest request, long currentSize, long totalSize);
}
