package com.xizhu.qiyou.entity;

import java.io.Serializable;

public class Tail implements Serializable {


    /**
     * uid : 1
     * id : 1
     * content : 123@12.com
     * createtime :
     */

    private String uid;
    private String id;
    private String content;
    private String createtime;

    @Override
    public String toString() {
        return "Tail{" +
                "uid='" + uid + '\'' +
                ", id='" + id + '\'' +
                ", content='" + content + '\'' +
                ", createtime='" + createtime + '\'' +
                '}';
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }
}
