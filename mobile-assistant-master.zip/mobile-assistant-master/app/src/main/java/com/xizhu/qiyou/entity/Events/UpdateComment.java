package com.xizhu.qiyou.entity.Events;

public class UpdateComment {

    public int getType() {
        return type;
    }

    private final int type;

    private boolean isOne;

    public boolean isOne() {
        return isOne;
    }

    public void setOne(boolean one) {
        isOne = one;
    }

    public UpdateComment(int type, boolean isOne) {
        this.isOne = isOne;
        this.type = type;
    }

    public UpdateComment(int type) {
        this.type = type;
    }
}
