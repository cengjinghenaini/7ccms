package com.xizhu.qiyou.entity;

public class OssToken {

    /**
     * StatusCode : 200
     * AccessKeyId : STS.NTDjHoM8xSUkopDM3Z242CNLa
     * AccessKeySecret : HYqUHsjE2TJimB13rvBJZt9uTNze6NKYWVxgXUpEnPYf
     * Expiration : 2020-12-11T09:25:00Z
     * SecurityToken : CAISzwJ1q6Ft5B2yfSjIr5fxIfLboOdZ5JeAbVb1qTMPPrserIvngzz2IHpMenBqBOkXt/Q0m21X7fgalqJ4T55IQ1Dza8J148yXTpNB7syT1fau5Jko1bdecAr6Umweta2/SuH9S8ynQpXJQlvYlyh17KLnfDG5JTKMOoGIjpgVPrZyWRKjPwJbGPBcJAZptK1/MmDKZ9KsKQLSi3DMFygYvRFn20p17r6j59CY9hvGhUfm9/cRoI39WMLGCfNhJ5BiSdy48fVrf67aqk5q5gNN6b19gd46m0vOtcrPBEJKsVfUcbiL+dB0LA4+JIpCQvQd9qWkz6Ii5bKNzNqnmywgZ78FD37tI6m729bBFe+TMdI0SK32IXyl0KrUbMGr6ll5OCNCZFgVJoV6dCdqehUoSyDHLKi840zNYQqlRKWD3bs/zZ1v1VLs8Moqj8w1lwViuxqAAWjQgLi5Qv7NpeRazdD20ww8GXv/QWooyaN4XvWMS+EelYUaDX6vZcJoLuYSLgwHywsCwlFK/4+jMDJt2kUcqxNbPSpfHXojP3BfkbXmoStpwKI1silqCyzFG5sqrw7PnkD/PF+W8u0LSFSFM9SZijDcUU7NoQSjJ7dq4sM1EMBq
     */

    private int StatusCode;
    private String AccessKeyId;
    private String AccessKeySecret;
    private String Expiration;
    private String SecurityToken;

    public int getStatusCode() {
        return StatusCode;
    }

    public void setStatusCode(int StatusCode) {
        this.StatusCode = StatusCode;
    }

    public String getAccessKeyId() {
        return AccessKeyId;
    }

    public void setAccessKeyId(String AccessKeyId) {
        this.AccessKeyId = AccessKeyId;
    }

    public String getAccessKeySecret() {
        return AccessKeySecret;
    }

    public void setAccessKeySecret(String AccessKeySecret) {
        this.AccessKeySecret = AccessKeySecret;
    }

    public String getExpiration() {
        return Expiration;
    }

    public void setExpiration(String Expiration) {
        this.Expiration = Expiration;
    }

    public String getSecurityToken() {
        return SecurityToken;
    }

    public void setSecurityToken(String SecurityToken) {
        this.SecurityToken = SecurityToken;
    }
}
