package com.xizhu.qiyou.apps;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.text.TextUtils;

import androidx.annotation.Nullable;

import com.xizhu.qiyou.room.entity.AppEntity;
import com.xizhu.qiyou.util.FileUtil;
import com.xizhu.qiyou.util.dialog.ToastUtil;
import com.xizhu.qiyou.util.zip.FileUtils;
import com.xizhu.qiyou.util.zip.ZipUtils;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * UnzipService zip安装包的解压缩服务
 */

public class UnzipService extends Service {
    public static final String TAG = UnzipService.class.getSimpleName();
    private MyBinder mBinder = new MyBinder();
    public static final int MAX_THREAD = 4;
    ExecutorService mThreadPool = Executors.newFixedThreadPool(MAX_THREAD);

    private AppRepository mAppRepository;
    private Map<String, Future> mMap = new HashMap<>(MAX_THREAD);
    //记录上一次返回解压缩数据的时间戳,计算解压缩速率用
    private Map<String, Long> mTimeMap = new HashMap<>(MAX_THREAD);

    public class MyBinder extends Binder {

        public UnzipService getService() {
            return UnzipService.this;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return super.onStartCommand(null, flags, startId);
        }
        AppEntity appEntity = intent.getParcelableExtra("bean");
        if (appEntity != null) {
            boolean paused = intent.getBooleanExtra("paused", false);
            if (paused) {
                cancelUnzip(appEntity);
            } else {
                startUnzip(appEntity);
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }

    public void startUnzip(AppEntity appEntity) {
        if (null == appEntity) {
            return;
        }
        if (TextUtils.isEmpty(appEntity.getDownPath())) {
            appEntity.clear();
            mAppRepository.update(appEntity);
            return;
        }
        File dstDir = new File(appEntity.getUnzipPath());
        if (!dstDir.exists()) {
            dstDir.mkdirs();
        } else {
            FileUtils.deleteAllInDir(dstDir);
        }
        File rawFile = new File(appEntity.getDownPath());
        if (!rawFile.exists()) {
            appEntity.setDownloadProgress(0);
            mAppRepository.update(appEntity);
            return;
        }
        appEntity.setQueueTimeInMill(System.currentTimeMillis());
        if (mMap.size() >= MAX_THREAD) {
            appEntity.setIsWorking(AppEntity.TYPE_IN_QUEUE);
            mAppRepository.update(appEntity);
            return;
        }
        appEntity.setIsWorking(AppEntity.TYPE_WORKING);
        appEntity.setUnzipSpeed(0);
        mAppRepository.update(appEntity);
        Future future = mThreadPool.submit(() -> {
            try {
                ZipUtils.unzipFile(appEntity.getDownPath(), appEntity.getUnzipPath());
            } catch (Exception e) {
                e.printStackTrace();
                Thread.currentThread().interrupt();
                EventBus.getDefault().post(new UnzipEvent(appEntity.getUnzipPath(), 0, 0, true));
            }
        });
        mMap.put(appEntity.getUnzipPath(), future);
        mTimeMap.put(appEntity.getUnzipPath(), System.currentTimeMillis());
    }

    public void cancelUnzip(AppEntity appEntity) {
        appEntity.setUnzipProgress(0);
        appEntity.setIsManualPaused(AppEntity.TYPE_MANUAL_PAUSED);
        mAppRepository.update(appEntity);
        Future future = mMap.get(appEntity.getUnzipPath());
        if (future == null) {
            return;
        }
        future.cancel(true);
        mMap.remove(appEntity.getUnzipPath());
        mTimeMap.remove(appEntity.getUnzipPath());
        List<AppEntity> appEntities = mAppRepository.getUnzippingApps();
        if (appEntities.size() > 0) {
            startUnzip(appEntities.get(0));
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void eventHandle(UnzipEvent unzipEvent) {
        AppEntity appEntity = mAppRepository.getAppByDstPath(unzipEvent.dstPath);
        if (unzipEvent.isFail) {
            ToastUtil.show(appEntity.getName() + " 安装包解压缩失败");
            mAppRepository.delete(appEntity);
            mMap.remove(appEntity.getUnzipPath());
            mTimeMap.remove(appEntity.getUnzipPath());
            List<AppEntity> appEntities = mAppRepository.getUnzippingApps();
            if (appEntities.size() > 0) {
                startUnzip(appEntities.get(0));
            }
            return;
        }
        if (mMap.get(appEntity.getUnzipPath()) == null) {
            return;
        }
        long timeCost = System.currentTimeMillis() - mTimeMap.get(appEntity.getUnzipPath());
        long unzippedSize = unzipEvent.getUnzippedSize() - appEntity.getUnzipProgress() * unzipEvent.getTotalSize();
        int unzipSpeed = (int) (unzippedSize * 1000 / timeCost / 8);
        mTimeMap.put(appEntity.getUnzipPath(), System.currentTimeMillis());
        int newProgress = (int) (unzipEvent.getUnzippedSize() * 100 / unzipEvent.getTotalSize());
//        Log.d(TAG, newProgress + "");
        if (unzipSpeed > 0) {
            appEntity.setUnzipSpeed(unzipSpeed);
        }
        appEntity.setUnzipProgress(newProgress);
        mAppRepository.update(appEntity);
        if (newProgress == 100) {
            File unzippedDir = new File(appEntity.getUnzipPath());
            File[] files = unzippedDir.listFiles();
            File resourceDir = null;
            File apkFile = null;
            for (File file : files) {
                if (file.isDirectory()) {
                    resourceDir = file;
                } else {
                    apkFile = file;
                }
            }
            SimpleRealApp appInfo = AppUtil.apkInfo(apkFile.getAbsolutePath(), getApplicationContext());
            if (appInfo != null) {
                appEntity.setRealVersion(appInfo.getVersionName());
                appEntity.setRealPackage(appInfo.getPackageName());
                mAppRepository.update(appEntity);
            } else {
                File downloadFile = new File(appEntity.getDownPath());
                if (downloadFile.exists()) {
                    downloadFile.delete();
                }
                appEntity.clear();
                mAppRepository.update(appEntity);
                mMap.remove(appEntity.getUnzipPath());
                mTimeMap.remove(appEntity.getUnzipPath());
                List<AppEntity> appEntities = mAppRepository.getUnzippingApps();
                if (appEntities.size() > 0) {
                    startUnzip(appEntities.get(0));
                }
                return;
            }
            FileUtil.moveFiles(resourceDir.getPath(), AppModel.OBB_PATH);
            boolean hasInstalled = AppUtil.install(getApplicationContext(), appEntity);
            if (hasInstalled) {
                appEntity.setIsInstalled(AppEntity.TYPE_INSTALLED);
            }
            mAppRepository.update(appEntity);
            mMap.remove(appEntity.getUnzipPath());
            mTimeMap.remove(appEntity.getUnzipPath());
            List<AppEntity> appEntities = mAppRepository.getUnzippingApps();
            if (appEntities.size() > 0) {
                startUnzip(appEntities.get(0));
            }
        }

    }

    @Override
    public void onCreate() {
        super.onCreate();
        mAppRepository = new AppRepository(getApplication());
        EventBus.getDefault().register(this);
        appStart();
    }

    /**
     * App新启动
     */
    private void appStart() {
        //可能会有isWorking的.
        //然后再是inQueue.
        List<AppEntity> unzippingApps = mAppRepository.getUnzippingApps();
        if (unzippingApps.size() > 0) {
            for (AppEntity appEntity : unzippingApps) {
                startUnzip(appEntity);
            }
        }
        List<AppEntity> queueingApps = mAppRepository.getInQueueUnzipApps();
        if (queueingApps.size() > 0) {
            for (AppEntity appEntity : queueingApps) {
                startUnzip(appEntity);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }
}
