package com.xizhu.qiyou.ui.account

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.text.TextUtils
import com.xizhu.qiyou.BuildConfig
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseCompatActivity
import com.xizhu.qiyou.entity.User
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.CharacterUtils
import com.xizhu.qiyou.util.AppUtils
import com.xizhu.qiyou.util.DialogUtils
import com.xizhu.qiyou.util.PhoneUtil
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.util.dialog.ToastUtil
import kotlinx.android.synthetic.main.activity_new_register.*

class RegisterActivity : BaseCompatActivity() {

    override fun fitWindow(): Boolean {
        return false
    }

    override fun isLight(): Boolean {
        return false
    }

    override fun getStatusColorRes(): Int {
        return R.color.C_00000000
    }

    override fun getRes(): Int {
        return R.layout.activity_new_register
    }

    override fun initView() {
        val welcomeText = tv_welcome.text.toString()
        tv_welcome.text = welcomeText.replace("XXX", AppUtils.getAppName(this))
        tv_action_1.setOnClickListener {
            register()
        }
        tv_action_2.setOnClickListener {
            onBackPressed()
        }
        if (!BuildConfig.DEBUG) {
            et_account.text = null
            et_pwd.text = null
            et_pwd1.text = null
            et_secret_security.setText(CharacterUtils.getRandomString(8))
        }
    }


    //检测是否非法输入
    private fun illegal(): Boolean {
        val phone = et_account.text.toString()
        if (phone.length != 11) {
            ToastUtil.show("请输入正确的手机号")
            return true
        }
        val pwd = et_pwd.text.toString()
        if (TextUtils.isEmpty(pwd)) {
            ToastUtil.show(et_pwd.hint.toString())
            return true
        }
        if (pwd.length < 6) {
            ToastUtil.show("密码至少6位")
            return true
        }
        val pwd1 = et_pwd1.text.toString()
        if (TextUtils.isEmpty(pwd1)) {
            ToastUtil.show(et_pwd1.hint.toString())
            return true
        }
        if (!TextUtils.equals(pwd, pwd1)) {
            ToastUtil.show("两次密码输入不一致，请重新输入")
            return true
        }
        val secretSecurity = et_secret_security.text.toString()
        if (secretSecurity.length < 6) {
            ToastUtil.show("密保至少6位")
            return true
        }
        return false
    }


    private fun register() {
        if (illegal()) {
            return
        }
        showProgress()
        val phone = et_account.text.toString()
        val pwd = et_pwd.text.toString()
        val secretSecurity = et_secret_security.text.toString()
        HttpUtil.getInstance()
            .pwdRegister(phone, pwd, secretSecurity, object : ResultCallback<User?>() {
                override fun onSuccess(s: ResultEntity<User?>) {
                    dismissProgress()
                    copy(secretSecurity)
                    DialogUtils.showTipsDialog(
                        this@RegisterActivity,
                        message = "注册成功，已将密保复制到剪贴板请妥善保管您的密保，找回密码的唯一凭证！",
                        cancelable = false,
                        onclickListener = {
                            loginSuccess(s)
                        })
                }

                override fun onFailure(err: String?, code: Int) {
                    super.onFailure(err, code)
                    dismissProgress()
                }
            })
    }

    private fun copy(secretSecurity: String) {
        val clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val mClipData = ClipData.newPlainText("secretSecurity", secretSecurity)
        clipboardManager.primaryClip = mClipData
    }

    private fun loginSuccess(s: ResultEntity<User?>) {
        ToastUtil.show("登录成功")
        UserMgr.setUser(s.data)
        PhoneUtil.putSpUid(activity, s.data?.uid)
        finish()
    }

    override fun onBackPressed() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}