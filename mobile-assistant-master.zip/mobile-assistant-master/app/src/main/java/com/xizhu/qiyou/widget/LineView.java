package com.xizhu.qiyou.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.xizhu.qiyou.R;

public class LineView extends View {

    private Path path;
    private Paint paint;

    public LineView(Context context) {
        super(context);init();
    }

    public LineView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);init();
    }

    public LineView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);init();
    }

    public LineView(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);

        init();
    }

    private void init(){
        paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(getResources().getColor(R.color.status_bar));
        path = new Path();
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.save();
        path.lineTo(getWidth(),0);
        path.lineTo(0, (float) (getHeight()*0.7));
        path.close();

        canvas.drawPath(path,paint);
        canvas.restore();
        super.onDraw(canvas);
    }
}
