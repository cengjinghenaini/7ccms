package com.xizhu.qiyou.ui.main

import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import com.scwang.smart.refresh.layout.api.RefreshLayout
import com.scwang.smart.refresh.layout.listener.OnRefreshLoadMoreListener
import com.xizhu.qiyou.R
import com.xizhu.qiyou.base.BaseFragment
import com.xizhu.qiyou.config.Constant
import com.xizhu.qiyou.entity.BaseApp
import com.xizhu.qiyou.http.HttpUtil
import com.xizhu.qiyou.http.result.ResultCallback
import com.xizhu.qiyou.http.result.ResultEntity
import com.xizhu.qiyou.util.JumpUtils
import com.xizhu.qiyou.util.UserMgr
import com.xizhu.qiyou.widget.EmptyView
import kotlinx.android.synthetic.main.fragment_rank_page.*

class RankPageFragment : BaseFragment() {
    private var type = "1"//1 下载 2评分
    private var pageNum = 1
    private var adapter: RankPageAdapter? = null

    companion object {
        fun instance(type: Int): RankPageFragment {
            val fragment = RankPageFragment()
            fragment.type = type.toString()
            return fragment
        }
    }


    override fun getRes(): Int {
        return R.layout.fragment_rank_page
    }


    override fun initView() {
        super.initView()
        refresh_layout?.setOnRefreshLoadMoreListener(object : OnRefreshLoadMoreListener {
            override fun onRefresh(refreshLayout: RefreshLayout) {
                pageNum = 1
                getRankList()
            }

            override fun onLoadMore(refreshLayout: RefreshLayout) {
                pageNum++
                getRankList()
            }
        })
        empty_view?.setLoadListener {
            pageNum = 1
            getRankList()
        }
        val layoutManager = GridLayoutManager(context, 3, GridLayoutManager.VERTICAL, false)
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                val item = adapter?.getItem(position)
                return when {
                    item is String -> {
                        layoutManager.spanCount / 3
                    }
                    position == 0 -> {
                        layoutManager.spanCount / 3
                    }
                    position == 1 -> {
                        layoutManager.spanCount / 3
                    }
                    position == 2 -> {
                        layoutManager.spanCount / 3
                    }
                    else -> {
                        layoutManager.spanCount
                    }
                }
            }
        }
        recycler.layoutManager = layoutManager
        adapter = activity?.let {
            RankPageAdapter(it).apply {
                setEmptyView(EmptyView(it).setNoData())
                setOnItemClickListener { _, _, position ->
                    val item = getItem(position)
                    if (item is BaseApp) {
                        JumpUtils.jumpToGameDetailsPage(context, item.id)
                    }
                }
            }
        }
        recycler.adapter = adapter
    }

    override fun initData() {
        super.initData()
        getRankList()
    }


    private fun getRankList() {
        val uid = UserMgr.getUid()
        HttpUtil.getInstance()
            .getLeaderboard(uid, type, null, pageNum.toString(), Constant.PAGE_SIZE,
                object : ResultCallback<MutableList<BaseApp>>() {
                    override fun onSuccess(s: ResultEntity<MutableList<BaseApp>>) {
                        val data = s.data
                        val newData = mutableListOf<Any>()
                        if (pageNum == 1) {
                            when {
                                data.size == 1 -> {
                                    newData.add("空")
                                    newData.addAll(data)
                                }
                                data.size >= 2 -> {
                                    val firstData = data[0]
                                    data[0] = data[1]
                                    data[1] = firstData
                                    newData.addAll(data)
                                }
                                else -> {
                                    newData.addAll(data)
                                }
                            }
                            adapter?.setNewInstance(newData)
                        } else {
                            newData.addAll(data)
                            adapter?.addData(newData)
                        }
                        if (data.size >= Constant.PAGE_SIZE.toInt()) {
                            refresh_layout?.setEnableLoadMore(true)
                        } else {
                            refresh_layout?.setEnableLoadMore(false)
                        }
                        refresh_layout?.finishRefresh()
                        refresh_layout?.finishLoadMore()
                        empty_view?.visibility = View.GONE
                    }

                    override fun onFailure(err: String?, code: Int) {
                        refresh_layout?.finishRefresh(false)
                        refresh_layout?.finishLoadMore(false)
                        refresh_layout?.setEnableLoadMore(false)
                        if (pageNum > 1) {
                            pageNum--
                        }
                        if (empty_view?.visibility == View.VISIBLE) {
                            empty_view?.setLoadFail()
                        }
                    }
                })
    }

}