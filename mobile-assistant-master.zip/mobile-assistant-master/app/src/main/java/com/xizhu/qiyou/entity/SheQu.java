package com.xizhu.qiyou.entity;

import java.util.List;

public class SheQu {

    private List<SheQuActive> actives;
    private List<Forum> forums;

    public List<SheQuActive> getActives() {
        return actives;
    }

    public void setActives(List<SheQuActive> actives) {
        this.actives = actives;
    }

    public List<Forum> getForums() {
        return forums;
    }

    public void setForums(List<Forum> forums) {
        this.forums = forums;
    }


}
