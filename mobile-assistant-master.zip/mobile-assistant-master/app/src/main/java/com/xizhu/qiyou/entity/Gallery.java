package com.xizhu.qiyou.entity;

public class Gallery {

    private String id;
    private String uid;
    private String pic;
    private String createtime;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    @Override
    public String toString() {
        return "Gallery{" +
                "id='" + id + '\'' +
                ", uid='" + uid + '\'' +
                ", pic='" + pic + '\'' +
                ", createtime='" + createtime + '\'' +
                '}';
    }
}
