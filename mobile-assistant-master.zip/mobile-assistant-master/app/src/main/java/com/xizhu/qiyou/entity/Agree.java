package com.xizhu.qiyou.entity;

public class Agree {

    /**
     * content : <p>biaotit</p><p>neirong</p>
     */

    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
