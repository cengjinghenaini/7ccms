package com.xizhu.qiyou.entity;


import android.os.Parcel;

public class RecApp extends BaseApp {

    protected RecApp(Parcel in) {
        super(in);
    }
}


