package com.xizhu.qiyou.entity.Events;

public class Exit {
}
