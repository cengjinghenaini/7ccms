package com.xizhu.qiyou.entity;

public class UserRecApp {

    /**
     * id : value
     * app_id : value
     * name : value
     * createtime : value
     * createtime_f : value
     * phone_type : value
     * rec_reason : value
     * is_release : value
     * score : value
     * zan_count : value
     * comment_count : value
     * app : {"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value","is_reserve":"value","yiyuyue":"value"}
     * user : {"uid":"value","phone":"value","email":"value","name":"value","wx_name":"value","qq":"value","head":"value","touxian_id":"value","touxian":"value","sex":"value","is_member":"value","age":"value","sign":"","integral":"","exp":"","contribution":"","grade_id":"","grade_name":"","is_attention":"value"}
     */

    private String id;
    private String app_id;
    private String name;
    private String createtime;
    private String createtime_f;
    private String phone_type;
    private String rec_reason;
    private String is_release;
    private String score;
    private String zan_count;
    private String comment_count;
    private BaseApp app;
    private User user;
    private int is_zan;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getCreatetime_f() {
        return createtime_f;
    }

    public void setCreatetime_f(String createtime_f) {
        this.createtime_f = createtime_f;
    }

    public String getPhone_type() {
        return phone_type;
    }

    public void setPhone_type(String phone_type) {
        this.phone_type = phone_type;
    }

    public String getRec_reason() {
        return rec_reason;
    }

    public void setRec_reason(String rec_reason) {
        this.rec_reason = rec_reason;
    }

    public String getIs_release() {
        return is_release;
    }

    public void setIs_release(String is_release) {
        this.is_release = is_release;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getZan_count() {
        return zan_count;
    }

    public void setZan_count(String zan_count) {
        this.zan_count = zan_count;
    }

    public String getComment_count() {
        return comment_count;
    }

    public void setComment_count(String comment_count) {
        this.comment_count = comment_count;
    }


    public BaseApp getApp() {
        return app;
    }

    public void setApp(BaseApp app) {
        this.app = app;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getIs_zan() {
        return is_zan;
    }

    public void setIs_zan(int is_zan) {
        this.is_zan = is_zan;
    }
}
