package com.xizhu.qiyou.entity;

public class ReserveGame extends BaseGame {

    /**
     * id : value
     * uid : value
     * app_id : value
     * createtime : value
     * app : {"id":"value","pic":"value","title":"value","name":"value","icon":"value","introduction":"value","score":"value","comment_count":"value","version":"value","size":"value","down_time":"value","rec_reason":"value"}
     */

    private String id;
    private String uid;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }


}
