package com.xizhu.qiyou.config;

public class COSConfig {
    public static String secretId = "AKIDl4Xpyr4QxEsvnOd156hEVVEIxPlqBbEd"; //永久密钥 secretId
    public static String secretKey = "IWT9fz2GFzOWNwUGvd8omghRDAqFBzeA"; //永久密钥 secretKey
    public static String region = "ap-nanjing";
    public static String bucket = "7you-1304371138"; // 存储桶，格式：BucketName-APPID
}
