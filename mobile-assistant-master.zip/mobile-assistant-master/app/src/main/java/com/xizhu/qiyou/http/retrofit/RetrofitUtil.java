package com.xizhu.qiyou.http.retrofit;

import com.xizhu.qiyou.config.API;
import com.xizhu.qiyou.http.HttpClient;

import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitUtil {

    private static RetrofitUtil INSTANCE;
    private final ApiServer apiServer;

    public ApiServer server() {
        return apiServer;
    }

    private RetrofitUtil() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(API.DOMAIN)
                .client(HttpClient.build())
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();
        apiServer = retrofit.create(ApiServer.class);
    }


    public static RetrofitUtil instance() {
        if (INSTANCE == null) {
            synchronized (RetrofitUtil.class) {
                if (INSTANCE == null) {
                    INSTANCE = new RetrofitUtil();
                }
            }
        }
        return INSTANCE;
    }
}
