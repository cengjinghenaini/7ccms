package com.xizhu.qiyou.inter;

import com.tencent.cos.xml.exception.CosXmlClientException;
import com.tencent.cos.xml.exception.CosXmlServiceException;
import com.tencent.cos.xml.model.CosXmlRequest;
import com.tencent.cos.xml.model.CosXmlResult;

public interface CosPutResult {
    void onPutSuccess(CosXmlRequest request, CosXmlResult result);
    void onPutFail(CosXmlRequest request, CosXmlClientException exception, CosXmlServiceException serviceException);
}
