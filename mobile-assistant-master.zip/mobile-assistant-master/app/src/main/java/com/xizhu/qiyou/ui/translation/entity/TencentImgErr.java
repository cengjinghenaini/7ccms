package com.xizhu.qiyou.ui.translation.entity;

public class TencentImgErr {

    /**
     * Error : {"Code":"AuthFailure.SecretIdNotFound","Message":"The SecretId is not found, please ensure that your SecretId is correct."}
     * RequestId : 780be7e5-c9de-4815-8020-d6e55bcc15fb
     */

    private Response Response;

    public Response getResponse() {
        return Response;
    }

    public void setResponse(Response Response) {
        this.Response = Response;
    }

    public static class Response {
        /**
         * Code : AuthFailure.SecretIdNotFound
         * Message : The SecretId is not found, please ensure that your SecretId is correct.
         */

        private Error Error;
        private String RequestId;

        public Error getError() {
            return Error;
        }

        public void setError(Error Error) {
            this.Error = Error;
        }

        public String getRequestId() {
            return RequestId;
        }

        public void setRequestId(String RequestId) {
            this.RequestId = RequestId;
        }

        public static class Error {
            private String Code;
            private String Message;

            public String getCode() {
                return Code;
            }

            public void setCode(String Code) {
                this.Code = Code;
            }

            public String getMessage() {
                return Message;
            }

            public void setMessage(String Message) {
                this.Message = Message;
            }
        }
    }
}
