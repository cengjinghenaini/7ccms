package com.xizhu.qiyou.ui.main.provider

import com.chad.library.adapter.base.provider.BaseItemProvider
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.xizhu.qiyou.R
import com.xizhu.qiyou.ui.main.RankPageAdapter

class RankPageEmptyProvider : BaseItemProvider<Any>() {

    override val itemViewType: Int
        get() = RankPageAdapter.TYPE_EMPTY
    override val layoutId: Int
        get() = R.layout.item_recy_game_rank_empty


    override fun convert(helper: BaseViewHolder, item: Any) {

    }

}