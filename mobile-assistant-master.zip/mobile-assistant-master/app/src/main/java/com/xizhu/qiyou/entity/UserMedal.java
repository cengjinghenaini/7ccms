package com.xizhu.qiyou.entity;

public class UserMedal {

    /**
     * id :
     * name :
     * pic :
     * is_show :
     */

    private String id;
    private String name;
    private String pic;
    private String is_show;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getIs_show() {
        return is_show;
    }

    public void setIs_show(String is_show) {
        this.is_show = is_show;
    }

    @Override
    public String toString() {
        return "UserMedal{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", pic='" + pic + '\'' +
                ", is_show='" + is_show + '\'' +
                '}';
    }
}

