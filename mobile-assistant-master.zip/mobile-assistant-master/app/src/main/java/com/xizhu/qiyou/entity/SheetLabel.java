package com.xizhu.qiyou.entity;

import java.util.List;

public class SheetLabel {


    private List<Soft> soft;
    private List<Game> game;

    public List<Soft> getSoft() {
        return soft;
    }

    public void setSoft(List<Soft> soft) {
        this.soft = soft;
    }

    public List<Game> getGame() {
        return game;
    }

    public void setGame(List<Game> game) {
        this.game = game;
    }


}
