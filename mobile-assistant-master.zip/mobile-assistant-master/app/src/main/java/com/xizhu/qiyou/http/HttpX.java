package com.xizhu.qiyou.http;

import com.xizhu.qiyou.http.request.FileHelper;
import com.xizhu.qiyou.http.request.GetHelper;
import com.xizhu.qiyou.http.request.PostHelper;
import com.xizhu.qiyou.http.request.ReqHelper;


public class HttpX {

    public static ReqHelper get(){
        return new GetHelper();
    }

    public static ReqHelper post(){
        return new PostHelper();
    }
    public static ReqHelper file(){
        return new FileHelper();
    }
}
