package com.rex.editor.common;

/**
 * @author Rex on 2019/6/20.
 */
public class CommonJs {

    /**
     * 为全局图片加上点击事件 回调 imageOnclick.openImage imageOnclick.openImage需要客户端对应实现
     * 时机为window.onload
     */
    public final static String IMG_CLICK_JS = "<script type='text/javascript'>window.onload = function(){" +
            "var $img = document.getElementsByTagName('img');" +
            "for(var p in  $img){" +
            "    if (typeof $img[p] === 'object') {" +
//            "        $img[p].style.width = '100%';" +
//            "        $img[p].style.height ='auto';" +
            "        $img[p].onclick = function(e){" +
            "            ImgClick(e.srcElement.src);" +
            "        };" +
            "    }" +
            "};" +

            "var $fon = document.getElementsByClassName('clickable');" +
            "for(var p in  $fon){" +
            "    if (typeof $fon[p] === 'object') {" +
            "        $fon[p].onclick = function(e){" +
            "            textClick(this.getAttribute('extra'));" +
            "        };" +
            "    }" +
            "};" +

//            "var $as = document.getElementsByTagName('a');" +
//            "for(var a in  $as){" +
//            "    if (typeof $as[a] === 'object') {" +
//            "        $as[a].onclick = function(e){" +
//            "            textClick(this.getAttribute('href'));" +
//            "        };" +
//            "    }" +
//            "};" +

            "};" +
            "function ImgClick(src) {" +
            "    var message = {" +
            "        'imgUrl' : src," +
            "    };" +
            "   window.imageOnclick.openImage(src);" +
            "};" +

            "function textClick(src) {" +
            "    var message = {" +
            "        'imgUrl' : src," +
            "    };" +
            "   window.textOnclick.openText(src);" +
            "};" +

            "</script>";
}
