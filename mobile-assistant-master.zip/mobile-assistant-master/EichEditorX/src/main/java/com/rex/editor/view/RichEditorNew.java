package com.rex.editor.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.webkit.WebChromeClient;

import com.rex.editor.common.CommonJs;
import com.rex.editor.common.FilesUtils;
import com.rex.editor.common.Utils;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import static com.rex.editor.common.FilesUtils.getVideoThumbnail;

/**
 * @author Rex on 2019/6/20.
 */
public class RichEditorNew extends RichEditor {
    private OnTextChangeNewListener mTextChangeListener;
    private OnConsoleMessageListener mOnConsoleMessageListener;
    /**
     * 用于在ontextchange中执行操作标识避免循环
     */
    private boolean isUnableTextChange = false;
    private boolean isNeedSetNewLineAfter = false;
    //视频缩略图
    private boolean isNeedAutoPosterUrl = true;
    public final static String FILE_TAG = "/rich_editor";
    public OnClickImageTagListener mOnClickImageTagListener;
    public OnClickTextListener onClickTextListener;
    private static final int MAX_WIDTH = 300;

    public void setOnClickImageTagListener(OnClickImageTagListener onClickImageTagListener) {
        this.mOnClickImageTagListener = onClickImageTagListener;
    }

    public void setOnClickTextListener(OnClickTextListener onClickTextListener) {
        this.onClickTextListener = onClickTextListener;
    }

    public RichEditorNew(Context context) {
        super(context);
        initConfig();
    }

    @Override
    public void initView(Context context, AttributeSet attrs, int defStyleAttr) {
        super.initView(context, attrs, defStyleAttr);
        addJavascriptInterface(new JavascriptInterfaceImageOnclick(), "imageOnclick");
        addJavascriptInterface(new JavascriptInterfaceTextOnclick(), "textOnclick");
    }

    public RichEditorNew(Context context, AttributeSet attrs) {
        super(context, attrs);
        initConfig();
    }

    public RichEditorNew(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initConfig();
    }

    public boolean isNeedAutoPosterUrl() {
        return isNeedAutoPosterUrl;
    }

    public void setNeedAutoPosterUrl(boolean needAutoPosterUrl) {
        isNeedAutoPosterUrl = needAutoPosterUrl;
    }

    public void getCurrChooseParams() {
        exec("javascript:RE.getSelectedNode();");
    }

    public void loadRichEditorCode(String html) {
        loadDataWithBaseURL("file:///android_asset/",
                html + CommonJs.IMG_CLICK_JS, "text/html", "utf-8", null);
    }


    public interface OnTextChangeNewListener {
        void onTextChange(String text);
    }

    public interface OnConsoleMessageListener {
        void onTextChange(String message, int lineNumber, String sourceID);
    }


    public void setOnConsoleMessageListener(OnConsoleMessageListener listener) {
        this.mOnConsoleMessageListener = listener;
    }

    private void initConfig() {
        setOnTextChangeListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {

                if (isNeedSetNewLineAfter()) {
                    setNewLine();
                }
                if (isUnableTextChange) {
                    isUnableTextChange = false;
                } else {
                    if (mTextChangeListener != null) {
                        mTextChangeListener.onTextChange(text);
                    }
                }

            }
        });

        setWebChromeClient(new WebChromeClient() {
            @Override
            public void onConsoleMessage(String message, int lineNumber, String sourceID) {
                super.onConsoleMessage(message, lineNumber, sourceID);
                if (mOnConsoleMessageListener != null) {
                    mOnConsoleMessageListener.onTextChange(message, lineNumber, sourceID);
                }

            }
        });
    }

    public void insertImageGame(String url, String source, String id,String uid) {
        String style = "margin:0px; width:99%;";
        String extra = "gameId@" + id + "&&" + uid;
        insertHtml("<img class=\"clickable\" extra=\"" + extra + "\" style=\"" + style + "\" src=\"" + url + "\"><br><br>");
    }


    public void insertImage(String url, String source) {
        Bitmap bitmap = BitmapFactory.decodeFile(source);
        int width = bitmap.getWidth();
        if (width > MAX_WIDTH) {
            String style = "margin:0px; width:99%;";
            insertImage(url, null, style);
        } else {
            insertImage(url);
        }
    }


    public void insertImage(String url) {
        insertImage(url, null, null);
    }

    public void insertGambit(String content, String id) {
        insertGambit(content, null, id);
    }

    public void insertGambit(String content, String style, String extra) {
        if (style == null) {
            style = "color:#2AB76F;";
        }
        extra = "gambit" + content;
        insertHtml("<font >#<em class=\"clickable\" extra=\"" + extra + "\" style=\"" + style + "\">" + content + "</em>.</font>");
    }

    public void insertPoint(String content, String extra, String show_type) {
        String style = "color:#2AB76F;";
        content = "\"" + content + "\"";
        extra = "point" + extra + "," + show_type;
        insertHtml("<font ><em class=\"clickable\" extra=\"" + extra + "\" style=\"" + style + "\">" + content + "</em>.</font>");
    }

    public void insertGame(String imgUrl, String name, String size, String id, String uid, String desc) {

        if (desc.length() > 60) desc = desc.substring(0, 60) + "...";
        if (name.length() > 8) name = name.substring(0, 8);

        String style = "color:#F5F5F5; font-size:13px; background-color:#F5F5F5; width:100%; height:70px; border-radius:10px; display: flex;align-items:center; flex-direction:row;";
        String extra = "gameId@" + id + "&&" + uid;
        String imgStyle = "margin-left:10px; width:50px; height:50px; border-radius:7px";
        String divStyle = "white-space: nowrap;height:60px; flex-direction:column; display:flex;align-content: center; margin-left:15px";
        String div2Style = "width:100%; height:100%; display: flex; flex-direction:row;margin-left:15px;margin-top:25px;margin-right:15px;margin-bottom:15px";
        String emStyle = "font-size:14px; color:#2ab67f; width:60px; height:30px; background-color:#ffffff; border-radius:15px; margin-right:10px;line-height:30px;text-align: center";
        String emStyle1 = "font-size:11px; color:#2ab67f;";

        String nameStyle = "color:#333333; font-size:13px; flex: 1; line-height:30px";
        String sizeStyle = "color:#575757; font-size:11px; flex: 1";


        insertHtml("<div class=\"clickable\" extra=\"" + extra + "\" style=\"" + style + "\">" +
                "<img src=\"" + imgUrl + "\" style=\"" + imgStyle + "\" alt=\"图片\">" +
                "<div style=\"" + divStyle + "\"><div style=\"" + nameStyle + "\">" + name + "</div><div style=\"" + sizeStyle + "\">" + size + "</div></div>" +
                "<div style=\"" + div2Style + "\"><div style=\"" + emStyle1 + "\">" + desc + "</div></div>" +
                "</div><br>");
    }


    public void insertAite(String content, String id) {
        insertAite(content, null, id);
    }

    public void insertAite(String content, String style, String extra) {
        if (style == null) {
            style = "color:#2AB76F;";
        }
        extra = "uid" + extra;
        insertHtml("<font >@<em class=\"clickable\" extra=\"" + extra + "\" style=\"" + style + "\">" + content + "</em>.</font>");
    }

    public void insertAite2(String content, String extra) {
        String style = "color:#2AB76F;";
        extra = "uid" + extra;
        insertHtml("<font >@<em class=\"clickable\" extra=\"" + extra + "\" style=\"" + style + "\">" + content + "</em>.</font>");
    }

    public void insertUrl(String link, String title) {
        insertUrl(link, null, title);
    }

    public void insertUrl(String link, String style, String title) {
        if (style == null) {
            style = "color:#2ab67f; font-size:13px; background-color:#E9FDF3; padding:3px 8px ; line-height:20px;";
        }
        String extra = "url" + link;
        insertHtml("<em class=\"clickable\"  extra=\"" + extra + "\" style=\"" + style + "\">" + title + "</em>.");
    }


    public void insertImage(String url, String alt, String style) {
        if (alt == null) {
            alt = "图片链接失效";
        }
        if (style == null) {
            style = "margin:0px;max-width:auto;";
        }

        super.insertImage(url, alt, style);
    }

    public void insertHtml(String html) {
        exec("javascript:RE.prepareInsert();");
        exec("javascript:RE.insertHTML('" + html + "');");
    }


    public void setNewLine() {
        isNeedSetNewLineAfter = false;
        isUnableTextChange = true;
        exec("javascript:RE.prepareInsert();");
        exec("javascript:RE.insertHTML('<br></br>');");
    }

    public void setHint(String placeholder) {
        setPlaceholder(placeholder);
    }

    public void setHintColor(String placeholderColor) {
        exec("javascript:RE.setPlaceholderColor('" + placeholderColor + "');");
    }

    public void setNeedSetNewLineAfter(boolean needSetNewLineAfter) {
        isNeedSetNewLineAfter = needSetNewLineAfter;
    }

    public boolean isNeedSetNewLineAfter() {
        return isNeedSetNewLineAfter;
    }


    public void insertFileWithDown(String downloadUrl, String title) {
        if (TextUtils.isEmpty(downloadUrl)) {
            return;
        }

        String fileName;
        try {
            String[] split = downloadUrl.split("/");
            fileName = split[split.length - 1];
        } catch (Exception e) {
            fileName = "rich" + System.currentTimeMillis();
        }

        title += fileName;
        insertHtml("<a href=\"" + downloadUrl + "\" download=\"" + fileName + "\">" +
                title +
                "</a><br></br>");
    }

    public void insertAudio(String audioUrl) {
        insertAudio(audioUrl, "");
    }

    public void insertAudio(String audioUrl, String custom) {
        if (TextUtils.isEmpty(custom)) {
            custom =             //增加进度控制
                    "controls=\"controls\"" +
                            //宽高
                            "height=\"300\" " +
                            //样式
                            " style=\"margin-top:10px;max-width:100%;\"";
        }
        exec("javascript:RE.prepareInsert();");
        exec("javascript:RE.insertAudio('" + audioUrl + "', '" + custom + "');");
    }


    public void insertVideo(String videoUrl) {
//        insertVideo(videoUrl, "", "");
        insertVideo(videoUrl, 100, 0);
    }

    public void insertVideo(String url, int width, int height) {
        String w = width + "%";
        String h = height + "";
        if (height == 0) {
            h = "auto";
        }
        exec("javascript:RE.prepareInsert();");
        exec("javascript:RE.insertVideoWH('" + url + "', '" + w + "', '" + h + "');");
    }

    /**
     * @param videoUrl
     * @param customStyle
     * @param posterUrl   视频默认缩略图
     */
    public void insertVideo(String videoUrl, String customStyle, String posterUrl) {
        if (TextUtils.isEmpty(customStyle)) {
            customStyle =             //增加进度控制
//                    "controls=\"controls\"" + //已修改到video标签里面
                    //视频显示第一帧
//                            " initial-time=\"0.01\" " +//客户端无效
                    //宽高
                    "height=\"300\" " + "width=\"100%\" " +
                            //样式
                            " style=\"margin-top:10px;max-width:100%;\"";
        }
        Log.e("TAG", "insertVideo: ");
        if (TextUtils.isEmpty(posterUrl) && isNeedAutoPosterUrl) {
            Bitmap videoThumbnail = getVideoThumbnail(videoUrl);
            Log.e("TAG", "insertVideo: " + videoThumbnail);
            MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
            mediaMetadataRetriever.setDataSource(videoUrl, new HashMap<String, String>());
            Bitmap frameAtTime = mediaMetadataRetriever.getFrameAtTime();
            if (frameAtTime != null) {
                Log.e("TAG", "insertVideo: " + frameAtTime);
                String videoThumbnailUrl = FilesUtils.saveBitmap(frameAtTime);
                Log.e("TAG", "insertVideo: " + frameAtTime);
                if (!TextUtils.isEmpty(videoThumbnailUrl)) {
                    posterUrl = videoThumbnailUrl;
                }
            }

        }


        System.out.println("videoUrl = [" + videoUrl + "], custom = [" + customStyle + "]");
        System.out.println("videoUrl getAbsolutePath = [" + new File(videoUrl).getAbsolutePath() + "]");
        exec("javascript:RE.prepareInsert();");
        exec("javascript:RE.insertVideo('" + videoUrl + "', '" + customStyle + "', '" + posterUrl + "');");
    }


    // 获取html本地的地址 方便上传的时候转为在线的地址
    public List<String> getAllSrcAndHref() {
        return Utils.getHtmlSrcOrHrefList(getHtml());
    }

    public void clearLocalRichEditorCache() {
        FilesUtils.clearLocalRichEditorCache();
    }


    public class JavascriptInterfaceImageOnclick {

        @android.webkit.JavascriptInterface
        public void openImage(String imgUrl) {
            if (mOnClickImageTagListener != null && !TextUtils.isEmpty(imgUrl)) {
                mOnClickImageTagListener.onClick(imgUrl);
            }
        }
    }

    public class JavascriptInterfaceTextOnclick {
        @android.webkit.JavascriptInterface
        public void openText(String content) {
            if (onClickTextListener != null) {
                onClickTextListener.onClick(content);
            }
        }
    }
}
